export interface Room {
  id: number;
  name: string;
  slug: string;
  short_description: string;
  full_description: string;
  hero_image?: string;
  thumbnail_image?: string;
  base_price: number;
  is_active: boolean;
}

export interface Reservation {
  id: number;
  room_id: number;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  num_people: number;
  total_price: number;
  status: 'pending' | 'paid' | 'cancelled';
  created_at: string;
  expires_at: string;
}

export interface ReservationForm {
  room_id: number;
  date: string;
  time: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  num_people: number;
}

// Common type definitions for the application

export interface ApiResponse<T> {
  data: T;
  message?: string;
  status: number;
}

export interface ApiError {
  message: string;
  status: number;
  details?: any;
}

export interface PaginatedResponse<T> {
  results: T[];
  count: number;
  next: string | null;
  previous: string | null;
}

// Form validation types
export interface ValidationError {
  field: string;
  message: string;
}

export interface FormState {
  isValid: boolean;
  errors: ValidationError[];
  touched: Record<string, boolean>;
}

// UI component types
export interface LoadingState {
  isLoading: boolean;
  message?: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  duration?: number;
}

// Device and responsive types
export type Breakpoint = 'mobile' | 'tablet' | 'desktop' | 'wide';

export interface MediaQueries {
  mobile: string;
  tablet: string;
  desktop: string;
  wide: string;
}