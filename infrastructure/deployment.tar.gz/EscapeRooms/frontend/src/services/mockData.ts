import { Room } from '../contexts/RoomContext';

// Mock room data for development and testing
export const mockRooms: Room[] = [
  {
    id: 1,
    name: 'La Inquisición',
    slug: 'la-inquisicion',
    short_description: 'Una experiencia medieval llena de misterios y desafíos que te transportará a la época más oscura de la historia.',
    full_description: 'Sumérgete en los misterios de la Inquisición española. En este escape room ambientado en el siglo XV, deberás resolver enigmas históricos, descifrar códigos antiguos y escapar antes de que sea demasiado tarde. Una experiencia inmersiva que combina historia real con elementos de suspense y terror psicológico.',
    hero_image: '/images/inquisicion-hero.jpg',
    thumbnail_image: '/images/inquisicion-thumb.jpg',
    video_url: '/videos/inquisicion_audio.mp4',
    base_price: 30,
    is_active: true,
  },
  {
    id: 2,
    name: 'El Purgatorio',
    slug: 'el-purgatorio',
    short_description: 'Un viaje sobrenatural entre la vida y la muerte donde cada decisión cuenta.',
    full_description: 'Despierta en un lugar entre mundos, donde las almas perdidas buscan redención. En El Purgatorio, deberás enfrentar tus miedos más profundos y resolver acertijos que desafían la lógica. Solo aquellos con corazón puro y mente clara podrán encontrar el camino hacia la luz.',
    hero_image: '/images/purgatorio-hero.jpg',
    thumbnail_image: '/images/purgatorio-hero.jpg',
    video_url: '/videos/purgatorio_audio.mp4',
    base_price: 30,
    is_active: true,
  },

];

// Simulate API delay
export const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Mock API functions
export const mockRoomsApi = {
  getRooms: async (): Promise<Room[]> => {
    await delay(1000); // Simulate network delay
    return mockRooms.filter(room => room.is_active);
  },

  getRoom: async (id: number): Promise<Room> => {
    await delay(500);
    const room = mockRooms.find(room => room.id === id);
    if (!room) {
      throw new Error(`Room with id ${id} not found`);
    }
    return room;
  },

  getAvailability: async (roomId: number, date: string): Promise<string[]> => {
    await delay(800);
    
    // Get day of week for the date
    const dayOfWeek = new Date(date).getDay();
    
    // Define schedule based on day of week
    let allSlots: string[] = [];
    switch (dayOfWeek) {
      case 1: // Monday
      case 2: // Tuesday
      case 3: // Wednesday
      case 4: // Thursday
        allSlots = ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00'];
        break;
      case 5: // Friday
        allSlots = ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00'];
        break;
      case 6: // Saturday
        allSlots = ['10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00'];
        break;
      case 0: // Sunday
        allSlots = ['10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00'];
        break;
      default:
        allSlots = [];
    }
    
    // Simulate some slots being unavailable (randomly remove 20-30% of slots)
    const availableSlots = allSlots.filter(() => Math.random() > 0.25);
    
    return availableSlots;
  },
};