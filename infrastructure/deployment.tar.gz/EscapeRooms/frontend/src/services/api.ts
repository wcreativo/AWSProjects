import axios from 'axios';
import { Room } from '../contexts/RoomContext';
import { ReservationFormData } from '../contexts/ReservationContext';
import { mockRoomsApi } from './mockData';

// Helper function to generate local URLs when API returns null
const getLocalUrl = (slug: string, type: 'hero' | 'thumb' | 'video'): string => {
  const urlMap: Record<string, Record<string, string>> = {
    'la-inquisicion': {
      hero: '/images/inquisicion-hero.jpg',
      thumb: '/images/inquisicion-thumb.jpg',
      video: '/videos/inquisicion_audio.mp4',
    },
    'el-purgatorio': {
      hero: '/images/purgatorio-hero.jpg',
      thumb: '/images/purgatorio-hero.jpg',
      video: '/videos/purgatorio_audio.mp4',
    },

  };

  return urlMap[slug]?.[type] || (type === 'video' ? '' : '/images/logo.svg');
};

// Create axios instance with base configuration
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:8000/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for adding auth tokens
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for handling errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('authToken');
      // Redirect to login if needed
    }
    return Promise.reject(error);
  }
);

// Room API endpoints
export const roomsApi = {
  // Get all active rooms
  getRooms: async (): Promise<Room[]> => {
    // Always try API first if URL is configured
    if (process.env.REACT_APP_API_URL) {
      try {
        const response = await api.get('/rooms/');
        // Fix null URLs by using local fallbacks
        const rooms = response.data.map((room: Room) => ({
          ...room,
          hero_image: room.hero_image || getLocalUrl(room.slug, 'hero'),
          thumbnail_image: room.thumbnail_image || getLocalUrl(room.slug, 'thumb'),
          video_url: room.video_url || getLocalUrl(room.slug, 'video'),
        }));
        return rooms;
      } catch (error) {
        console.warn('API not available, falling back to mock data');
        return mockRoomsApi.getRooms();
      }
    }

    // Fallback to mock data if no API URL configured
    return mockRoomsApi.getRooms();
  },

  // Get room by ID
  getRoom: async (id: number): Promise<Room> => {
    // Always try API first if URL is configured
    if (process.env.REACT_APP_API_URL) {
      try {
        const response = await api.get(`/rooms/${id}/`);
        const room = response.data;
        // Fix null URLs by using local fallbacks
        return {
          ...room,
          hero_image: room.hero_image || getLocalUrl(room.slug, 'hero'),
          thumbnail_image: room.thumbnail_image || getLocalUrl(room.slug, 'thumb'),
          video_url: room.video_url || getLocalUrl(room.slug, 'video'),
        };
      } catch (error) {
        console.warn('API not available, falling back to mock data');
        return mockRoomsApi.getRoom(id);
      }
    }

    // Fallback to mock data if no API URL configured
    return mockRoomsApi.getRoom(id);
  },

  // Get available time slots for a room on a specific date
  getAvailability: async (roomId: number, date: string): Promise<string[]> => {
    // Always try API first if URL is configured
    if (process.env.REACT_APP_API_URL) {
      try {
        const response = await api.get(`/rooms/${roomId}/availability/`, {
          params: { date }
        });
        // Extract time strings from the API response
        return response.data.available_times.map((slot: any) =>
          slot.time.substring(0, 5) // Convert "HH:MM:SS" to "HH:MM"
        );
      } catch (error) {
        console.warn('API not available, falling back to mock data');
        return mockRoomsApi.getAvailability(roomId, date);
      }
    }

    // Fallback to mock data if no API URL configured
    return mockRoomsApi.getAvailability(roomId, date);
  },
};

// Reservation API endpoints
export const reservationsApi = {
  // Create a new reservation
  createReservation: async (data: Omit<ReservationFormData, 'totalPrice'>): Promise<any> => {
    const response = await api.post('/reservations/', {
      room_id: data.roomId,
      date: data.date,
      time: data.time,
      num_people: data.numPeople,
      customer_name: data.customerName,
      customer_email: data.customerEmail,
      customer_phone: data.customerPhone,
    });
    return response.data;
  },
};

// Admin API endpoints
export const adminApi = {
  // Login
  login: async (username: string, password: string): Promise<{ access_token: string; refresh_token: string }> => {
    const response = await api.post('/auth/login', {
      username,
      password,
    });
    return response.data;
  },

  // Get all reservations (admin only)
  getReservations: async (): Promise<any[]> => {
    const response = await api.get('/admin/reservations/');
    return response.data.reservations; // Extract reservations from paginated response
  },

  // Update reservation status (admin only)
  updateReservationStatus: async (id: number, status: string): Promise<any> => {
    const response = await api.patch(`/admin/reservations/${id}/`, {
      status,
    });
    return response.data;
  },

  // Get basic stats (admin only)
  getStats: async (): Promise<any> => {
    const response = await api.get('/admin/stats/');
    return response.data;
  },
};

export default api;