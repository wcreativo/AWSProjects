import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { DetailModal } from './DetailModal';
import { theme } from '../../styles/theme';
import { Room } from '../../contexts/RoomContext';

// Mock the Modal component
jest.mock('../common/Modal', () => ({
  Modal: ({ isOpen, onClose, title, children }: any) => (
    isOpen ? (
      <div data-testid="modal">
        <div data-testid="modal-title">{title}</div>
        <button data-testid="modal-close" onClick={onClose}>Close</button>
        <div data-testid="modal-content">{children}</div>
      </div>
    ) : null
  ),
}));

// Mock the Loading component
jest.mock('../common/Loading', () => ({
  Loading: ({ text }: { text: string }) => (
    <div data-testid="loading">{text}</div>
  ),
}));

const mockRoom: Room = {
  id: 1,
  name: 'La Inquisición',
  slug: 'la-inquisicion',
  short_description: 'Una experiencia medieval llena de misterio',
  full_description: 'Sumérgete en los oscuros secretos de la Inquisición española.\nResuelve acertijos históricos y escapa antes de que sea demasiado tarde.\n\nUna experiencia única que combina historia y diversión.',
  hero_image: '/images/inquisicion-hero.jpg',
  thumbnail_image: '/images/inquisicion-thumb.jpg',
  base_price: 30,
  is_active: true,
};

const renderWithTheme = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('DetailModal', () => {
  const mockOnClose = jest.fn();

  beforeEach(() => {
    mockOnClose.mockClear();
  });

  it('renders nothing when isOpen is false', () => {
    renderWithTheme(
      <DetailModal
        isOpen={false}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    expect(screen.queryByTestId('modal')).not.toBeInTheDocument();
  });

  it('renders modal when isOpen is true', () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    expect(screen.getByTestId('modal')).toBeInTheDocument();
    expect(screen.getByTestId('modal-title')).toHaveTextContent('La Inquisición');
  });

  it('displays room information correctly', () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    // Check that the room title appears in the content (not just the modal title)
    const roomTitles = screen.getAllByText('La Inquisición');
    expect(roomTitles.length).toBeGreaterThan(1); // Should appear in both modal title and content
    
    expect(screen.getByText('Sumérgete en los oscuros secretos de la Inquisición española.')).toBeInTheDocument();
    expect(screen.getByText('Resuelve acertijos históricos y escapa antes de que sea demasiado tarde.')).toBeInTheDocument();
    expect(screen.getByText('Una experiencia única que combina historia y diversión.')).toBeInTheDocument();
  });

  it('displays pricing information correctly', () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    expect(screen.getByText('Información de Precios')).toBeInTheDocument();
    expect(screen.getByText('1-3 personas:')).toBeInTheDocument();
    expect(screen.getByText('$30 por persona')).toBeInTheDocument();
    expect(screen.getByText('4+ personas:')).toBeInTheDocument();
    expect(screen.getByText('$25 por persona')).toBeInTheDocument();
  });

  it('displays default features', () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    expect(screen.getByText('Características')).toBeInTheDocument();
    expect(screen.getByText('Experiencia inmersiva de 60 minutos')).toBeInTheDocument();
    expect(screen.getByText('Hasta 6 personas por sesión')).toBeInTheDocument();
    expect(screen.getByText('Múltiples acertijos y desafíos')).toBeInTheDocument();
    expect(screen.getByText('Ambientación temática completa')).toBeInTheDocument();
    expect(screen.getByText('Supervisor disponible durante el juego')).toBeInTheDocument();
    expect(screen.getByText('Fotografía grupal incluida')).toBeInTheDocument();
  });

  it('renders room image with correct attributes', () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    const image = screen.getByRole('img');
    expect(image).toHaveAttribute('src', '/images/inquisicion-hero.jpg');
    expect(image).toHaveAttribute('alt', 'La Inquisición');
    expect(image).toHaveAttribute('loading', 'lazy');
  });

  it('shows loading state initially', () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    expect(screen.getByTestId('loading')).toBeInTheDocument();
    expect(screen.getByText('Cargando imagen...')).toBeInTheDocument();
  });

  it('handles image load event', async () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    const image = screen.getByRole('img');
    
    // Initially loading should be visible
    expect(screen.getByTestId('loading')).toBeInTheDocument();

    // Simulate image load
    fireEvent.load(image);

    // Loading should disappear
    await waitFor(() => {
      expect(screen.queryByTestId('loading')).not.toBeInTheDocument();
    });
  });

  it('handles image error', async () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    const image = screen.getByRole('img');
    
    // Simulate image error
    fireEvent.error(image);

    // Loading should disappear
    await waitFor(() => {
      expect(screen.queryByTestId('loading')).not.toBeInTheDocument();
    });
  });

  it('calls onClose when modal close is triggered', () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    fireEvent.click(screen.getByTestId('modal-close'));
    expect(mockOnClose).toHaveBeenCalledTimes(1);
  });

  it('handles null room gracefully', () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={null}
      />
    );

    expect(screen.getByText('No se pudo cargar la información del escape room.')).toBeInTheDocument();
  });

  it('falls back to short description when full description is not available', () => {
    const roomWithoutFullDescription = {
      ...mockRoom,
      full_description: '',
    };

    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={roomWithoutFullDescription}
      />
    );

    expect(screen.getByText('Una experiencia medieval llena de misterio')).toBeInTheDocument();
  });

  it('calculates discounted price correctly for 4+ people', () => {
    const roomWithHigherPrice = {
      ...mockRoom,
      base_price: 40,
    };

    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={roomWithHigherPrice}
      />
    );

    expect(screen.getByText('$40 por persona')).toBeInTheDocument();
    expect(screen.getByText('$33 por persona')).toBeInTheDocument(); // 40 * 0.83 = 33.2, rounded to 33
  });

  it('resets image loading state when room changes', () => {
    const { rerender } = renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    // Initially loading should be visible
    expect(screen.getByTestId('loading')).toBeInTheDocument();

    // Simulate image load
    const image = screen.getByRole('img');
    fireEvent.load(image);

    // Change room
    const newRoom = { ...mockRoom, id: 2, name: 'New Room' };
    rerender(
      <ThemeProvider theme={theme}>
        <DetailModal
          isOpen={true}
          onClose={mockOnClose}
          room={newRoom}
        />
      </ThemeProvider>
    );

    // Loading should be visible again
    expect(screen.getByTestId('loading')).toBeInTheDocument();
  });

  it('formats multi-line descriptions correctly', () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    // Check that each line of the description is in its own paragraph
    const paragraphs = screen.getAllByText(/Sumérgete|Resuelve|Una experiencia/);
    expect(paragraphs).toHaveLength(3);
  });

  it('has proper accessibility attributes', () => {
    renderWithTheme(
      <DetailModal
        isOpen={true}
        onClose={mockOnClose}
        room={mockRoom}
      />
    );

    const image = screen.getByRole('img');
    expect(image).toHaveAttribute('alt', 'La Inquisición');
  });
});