import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { Modal } from '../common/Modal';
import { Room } from '../../contexts/RoomContext';
import { Loading } from '../common/Loading';

interface DetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  room: Room | null;
}

const DetailContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.lg};
  padding: ${props => props.theme.spacing.md};
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    padding: ${props => props.theme.spacing.lg};
  }
  
  @media (min-width: ${props => props.theme.breakpoints.desktop}) {
    padding: ${props => props.theme.spacing.xl};
  }
`;

const ImageGallery = styled.div`
  position: relative;
  width: 100%;
  height: 250px;
  border-radius: 12px;
  overflow: hidden;
  background: ${props => props.theme.colors.background.secondary};
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    height: 300px;
  }
  
  @media (min-width: ${props => props.theme.breakpoints.desktop}) {
    height: 350px;
  }
`;

const GalleryImage = styled.img<{ $isLoading: boolean }>`
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
  transition: opacity ${props => props.theme.transitions.normal};
  opacity: ${props => props.$isLoading ? 0 : 1};
`;

const ImageLoadingContainer = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 2;
`;

const RoomInfo = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.md};
`;

const RoomTitle = styled.h2`
  font-size: ${props => props.theme.typography.fontSize.xl};
  font-weight: ${props => props.theme.typography.fontWeight.bold};
  color: ${props => props.theme.colors.text.primary};
  margin: 0;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    font-size: ${props => props.theme.typography.fontSize.xxl};
  }
`;

const RoomDescription = styled.div`
  color: ${props => props.theme.colors.text.secondary};
  line-height: ${props => props.theme.typography.lineHeight.relaxed};
  font-size: ${props => props.theme.typography.fontSize.md};
  
  p {
    margin: 0 0 ${props => props.theme.spacing.md} 0;
    
    &:last-child {
      margin-bottom: 0;
    }
  }
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    font-size: ${props => props.theme.typography.fontSize.lg};
  }
`;

const PriceInfo = styled.div`
  background: ${props => props.theme.colors.background.secondary};
  padding: ${props => props.theme.spacing.lg};
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.1);
`;

const PriceTitle = styled.h3`
  font-size: ${props => props.theme.typography.fontSize.lg};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: ${props => props.theme.colors.text.primary};
  margin: 0 0 ${props => props.theme.spacing.sm} 0;
`;

const PriceDetails = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.xs};
  font-size: ${props => props.theme.typography.fontSize.sm};
  color: ${props => props.theme.colors.text.secondary};
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    font-size: ${props => props.theme.typography.fontSize.md};
  }
`;

const PriceRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const Features = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.md};
`;

const FeaturesTitle = styled.h3`
  font-size: ${props => props.theme.typography.fontSize.lg};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: ${props => props.theme.colors.text.primary};
  margin: 0;
`;

const FeaturesList = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.sm};
`;

const FeatureItem = styled.li`
  display: flex;
  align-items: center;
  gap: ${props => props.theme.spacing.sm};
  font-size: ${props => props.theme.typography.fontSize.md};
  color: ${props => props.theme.colors.text.secondary};
  
  &::before {
    content: '✓';
    color: ${props => props.theme.colors.success};
    font-weight: bold;
    font-size: ${props => props.theme.typography.fontSize.lg};
  }
`;

const ImportantNotes = styled.div`
  background: rgba(227, 40, 39, 0.1);
  border: 1px solid rgba(227, 40, 39, 0.3);
  border-radius: 12px;
  padding: ${props => props.theme.spacing.lg};
`;

const NotesTitle = styled.h3`
  font-size: ${props => props.theme.typography.fontSize.lg};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: ${props => props.theme.colors.primary.main};
  margin: 0 0 ${props => props.theme.spacing.md} 0;
  display: flex;
  align-items: center;
  gap: ${props => props.theme.spacing.sm};
  
  &::before {
    content: '⚠️';
    font-size: ${props => props.theme.typography.fontSize.lg};
  }
`;

const NotesList = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.sm};
`;

const NoteItem = styled.li`
  display: flex;
  align-items: flex-start;
  gap: ${props => props.theme.spacing.sm};
  font-size: ${props => props.theme.typography.fontSize.md};
  color: ${props => props.theme.colors.text.secondary};
  line-height: ${props => props.theme.typography.lineHeight.relaxed};
  
  &::before {
    content: '•';
    color: ${props => props.theme.colors.primary.main};
    font-weight: bold;
    font-size: ${props => props.theme.typography.fontSize.lg};
    margin-top: -2px;
    flex-shrink: 0;
  }
`;

const ErrorMessage = styled.div`
  text-align: center;
  padding: ${props => props.theme.spacing.xl} ${props => props.theme.spacing.md};
  color: ${props => props.theme.colors.text.secondary};
  font-size: ${props => props.theme.typography.fontSize.md};
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    padding: ${props => props.theme.spacing.xl} ${props => props.theme.spacing.lg};
  }
  
  @media (min-width: ${props => props.theme.breakpoints.desktop}) {
    padding: ${props => props.theme.spacing.xl};
  }
`;

export const DetailModal: React.FC<DetailModalProps> = ({
  isOpen,
  onClose,
  room,
}) => {
  const [imageLoading, setImageLoading] = useState(true);
  const [imageError, setImageError] = useState(false);

  // Reset image loading state when room changes
  useEffect(() => {
    if (room && isOpen) {
      setImageLoading(true);
      setImageError(false);
    }
  }, [room?.id, isOpen]);

  const handleImageLoad = () => {
    setImageLoading(false);
  };

  const handleImageError = () => {
    setImageLoading(false);
    setImageError(true);
  };

  // Format description with line breaks
  const formatDescription = (description: string) => {
    return description.split('\n').map((paragraph, index) => (
      <p key={index}>{paragraph}</p>
    ));
  };

  // Default features for escape rooms
  const getDefaultFeatures = () => [
    'Experiencia inmersiva de 60 minutos',
    'Hasta 6 personas por sesión',
    'Múltiples acertijos y desafíos',
    'Ambientación temática completa',
    'Supervisor disponible durante el juego',
    'Fotografía grupal incluida'
  ];

  if (!room) {
    return (
      <Modal isOpen={isOpen} onClose={onClose} title="Detalle del Escape Room">
        <ErrorMessage>
          No se pudo cargar la información del escape room.
        </ErrorMessage>
      </Modal>
    );
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={room.name}>
      <DetailContent>
        <ImageGallery>
          {!imageError && (
            <GalleryImage
              src={room.hero_image}
              alt={room.name}
              $isLoading={imageLoading}
              onLoad={handleImageLoad}
              onError={handleImageError}
              loading="lazy"
            />
          )}
          
          {imageLoading && (
            <ImageLoadingContainer>
              <Loading text="Cargando imagen..." />
            </ImageLoadingContainer>
          )}
        </ImageGallery>

        <RoomInfo>
          <RoomTitle>{room.name}</RoomTitle>
          <RoomDescription>
            {room.full_description ? 
              formatDescription(room.full_description) : 
              formatDescription(room.short_description)
            }
          </RoomDescription>
        </RoomInfo>

        <PriceInfo>
          <PriceTitle>Información de Precios</PriceTitle>
          <PriceDetails>
            <PriceRow>
              <span>1-3 personas:</span>
              <strong>${room.base_price} por persona</strong>
            </PriceRow>
            <PriceRow>
              <span>4+ personas:</span>
              <strong>${Math.round(room.base_price * 0.83)} por persona</strong>
            </PriceRow>
          </PriceDetails>
        </PriceInfo>

        <Features>
          <FeaturesTitle>Características</FeaturesTitle>
          <FeaturesList>
            {getDefaultFeatures().map((feature, index) => (
              <FeatureItem key={index}>{feature}</FeatureItem>
            ))}
          </FeaturesList>
        </Features>

        <ImportantNotes>
          <NotesTitle>Observaciones Importantes</NotesTitle>
          <NotesList>
            <NoteItem>
              Deben estar 15 minutos antes de la hora reservada para gestionar el pago.
            </NoteItem>
            <NoteItem>
              Niños de 8 a 14 años de edad deben estar acompañados de un adulto responsable.
            </NoteItem>
            <NoteItem>
              Asegúrate de que el grupo entero puede a esa hora ya que la hora no se puede cambiar una vez sea reservada.
            </NoteItem>
          </NotesList>
        </ImportantNotes>
      </DetailContent>
    </Modal>
  );
};