import React, { useState, useMemo } from 'react';
import styled from 'styled-components';
import { Button, Loading } from '../../common';
import { useAdmin } from '../../../contexts/AdminContext';

const Container = styled.div`
  padding: 1.5rem;

  @media (max-width: 768px) {
    padding: 1rem;
  }
`;

const ControlsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 1.5rem;

  @media (max-width: 768px) {
    gap: 0.75rem;
    margin-bottom: 1rem;
  }
`;

const SearchContainer = styled.div`
  display: flex;
  gap: 1rem;
  align-items: center;
  flex-wrap: wrap;

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: stretch;
    gap: 0.75rem;
  }
`;

const SearchInput = styled.input`
  flex: 1;
  min-width: 200px;
  padding: 0.75rem 1rem;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 0.875rem;
  background: white;

  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
  }

  @media (max-width: 768px) {
    min-height: 44px;
    font-size: 1rem;
    min-width: unset;
  }
`;

const FiltersContainer = styled.div`
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;

  @media (max-width: 768px) {
    gap: 0.75rem;
  }
`;

const MobileFiltersContainer = styled.div`
  display: none;

  @media (max-width: 768px) {
    display: flex;
    gap: 0.75rem;
    align-items: center;
  }
`;

const DesktopFiltersContainer = styled.div`
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;

  @media (max-width: 768px) {
    display: none;
  }
`;

const FilterDropdown = styled.select`
  flex: 1;
  padding: 0.75rem 1rem;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 1rem;
  background: white;
  min-height: 44px;

  &:focus {
    outline: none;
    border-color: ${props => props.theme.colors.primary};
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
  }
`;

const FilterButton = styled(Button).withConfig({
  shouldForwardProp: (prop) => !['active'].includes(prop),
})<{ active?: boolean }>`
  min-height: 36px;
  font-size: 0.875rem;
  padding: 0.5rem 1rem;
  background: ${props => props.active ? props.theme.colors.primary : 'transparent'};
  color: ${props => props.active ? 'white' : '#4b5563'};
  border: 1px solid ${props => props.active ? props.theme.colors.primary : '#d1d5db'};

  &:hover {
    background: ${props => props.active ? props.theme.colors.primary : '#f3f4f6'};
    color: ${props => props.active ? 'white' : '#374151'};
  }

  @media (max-width: 768px) {
    min-height: 44px;
    font-size: 1rem;
    flex: 1;
  }
`;

const ReservationsGrid = styled.div`
  display: none;

  @media (min-width: 769px) {
    display: block;
  }
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  background: white;
  border-radius: 8px;
  overflow: hidden;
`;

const TableHeader = styled.thead`
  background: #f9fafb;
`;

const TableRow = styled.tr`
  border-bottom: 1px solid #e5e7eb;

  &:last-child {
    border-bottom: none;
  }
`;

const TableHeaderCell = styled.th`
  padding: 0.75rem;
  text-align: left;
  font-weight: 600;
  color: #374151;
  font-size: 0.875rem;
`;

const TableCell = styled.td`
  padding: 0.75rem;
  font-size: 0.875rem;
  color: #6b7280;
`;

const ReservationCards = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;

  @media (min-width: 769px) {
    display: none;
  }
`;

const ReservationCard = styled.div`
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 1rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
`;

const CardHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 0.75rem;
  gap: 1rem;
`;

const CardTitle = styled.h3`
  font-size: 1rem;
  font-weight: 600;
  color: #1a1a1a;
  margin: 0;
`;

const CardDetails = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.5rem;
  margin-bottom: 1rem;
  font-size: 0.875rem;
`;

const CardLabel = styled.span`
  color: #6b7280;
  font-weight: 500;
`;

const CardValue = styled.span`
  color: #1a1a1a;
`;

const StatusBadge = styled.span<{ status: string }>`
  display: inline-block;
  padding: 0.25rem 0.75rem;
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  
  ${props => {
    switch (props.status) {
      case 'pending':
        return `
          background: #fef3c7;
          color: #92400e;
        `;
      case 'paid':
        return `
          background: #d1fae5;
          color: #065f46;
        `;
      case 'cancelled':
        return `
          background: #fee2e2;
          color: #991b1b;
        `;
      default:
        return `
          background: #f3f4f6;
          color: #374151;
        `;
    }
  }}
`;

const ActionButton = styled(Button)`
  min-height: 32px;
  font-size: 0.75rem;
  padding: 0.25rem 0.75rem;

  @media (max-width: 768px) {
    min-height: 44px;
    font-size: 0.875rem;
    padding: 0.5rem 1rem;
    width: 100%;
  }
`;

const ClearButton = styled(ActionButton)`
  color: #dc2626;
  border-color: #dc2626;
  
  &:hover {
    color: #b91c1c;
    border-color: #b91c1c;
    background-color: #fef2f2;
  }
`;

const EmptyState = styled.div`
  text-align: center;
  padding: 3rem 1rem;
  color: #6b7280;
`;

const LoadingContainer = styled.div`
  display: flex;
  justify-content: center;
  padding: 2rem;
`;

const PaginationContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid #e5e7eb;
  flex-wrap: wrap;
  gap: 1rem;

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: stretch;
    gap: 0.75rem;
  }
`;

const PaginationInfo = styled.div`
  font-size: 0.875rem;
  color: #6b7280;

  @media (max-width: 768px) {
    text-align: center;
  }
`;

const PaginationControls = styled.div`
  display: flex;
  gap: 0.5rem;
  align-items: center;

  @media (max-width: 768px) {
    justify-content: center;
  }
`;

const PaginationButton = styled(Button)`
  min-height: 36px;
  min-width: 36px;
  padding: 0.5rem;
  font-size: 0.875rem;
  color: ${props => props.variant === 'primary' ? 'white' : 'red'};

  @media (max-width: 768px) {
    min-height: 44px;
    min-width: 44px;
  }
`;

const PageSizeSelector = styled.select`
  padding: 0.5rem;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 0.875rem;
  background: white;

  @media (max-width: 768px) {
    min-height: 44px;
    font-size: 1rem;
  }
`;

type FilterStatus = 'all' | 'pending' | 'paid' | 'cancelled';

const statusLabels: Record<string, string> = {
  pending: 'Pendiente',
  paid: 'Pagada',
  cancelled: 'Cancelada',
};

const ITEMS_PER_PAGE_OPTIONS = [10, 25, 50, 100];

export const ReservationsList: React.FC = () => {
  const { state, updateReservationStatus } = useAdmin();
  const [filter, setFilter] = useState<FilterStatus>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [updatingIds, setUpdatingIds] = useState<Set<number>>(new Set());

  // Filter and search reservations
  const filteredAndSearchedReservations = useMemo(() => {
    let filtered = state.reservations;

    // Apply status filter
    if (filter !== 'all') {
      filtered = filtered.filter(reservation => reservation.status === filter);
    }

    // Apply search filter
    if (searchTerm.trim()) {
      const searchLower = searchTerm.toLowerCase().trim();
      filtered = filtered.filter(reservation =>
        reservation.customer_name.toLowerCase().includes(searchLower) ||
        reservation.customer_email.toLowerCase().includes(searchLower) ||
        reservation.customer_phone.includes(searchTerm.trim()) ||
        reservation.room_name.toLowerCase().includes(searchLower)
      );
    }

    return filtered;
  }, [state.reservations, filter, searchTerm]);

  // Paginate results
  const paginatedReservations = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filteredAndSearchedReservations.slice(startIndex, endIndex);
  }, [filteredAndSearchedReservations, currentPage, itemsPerPage]);

  // Calculate pagination info
  const totalItems = filteredAndSearchedReservations.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const startItem = totalItems === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1;
  const endItem = Math.min(currentPage * itemsPerPage, totalItems);

  // Reset to first page when filters change
  React.useEffect(() => {
    setCurrentPage(1);
  }, [filter, searchTerm, itemsPerPage]);

  const handleStatusUpdate = async (id: number, status: string) => {
    setUpdatingIds(prev => new Set(prev).add(id));
    try {
      await updateReservationStatus(id, status);
    } catch (error) {
      // Error is handled by context
    } finally {
      setUpdatingIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(id);
        return newSet;
      });
    }
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleItemsPerPageChange = (newItemsPerPage: number) => {
    setItemsPerPage(newItemsPerPage);
  };

  const clearSearch = () => {
    setSearchTerm('');
  };

  const formatDate = (dateString: string) => {
    try {
      // Parse date as YYYY-MM-DD without timezone conversion
      const [year, month, day] = dateString.split('-').map(Number);
      if (year && month && day) {
        // Create date in local timezone to avoid UTC conversion issues
        const parsedDate = new Date(year, month - 1, day);
        return parsedDate.toLocaleDateString('es-ES', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
        });
      }
      return dateString; // Return original string if parsing fails
    } catch (error) {
      console.error('Error formatting date:', dateString, error);
      return dateString; // Return original string if formatting fails
    }
  };

  const formatTime = (timeString: string) => {
    try {
      // Handle time format HH:MM:SS or HH:MM
      const timeParts = timeString.split(':');
      if (timeParts.length >= 2) {
        const hours = parseInt(timeParts[0], 10);
        const minutes = parseInt(timeParts[1], 10);
        
        if (!isNaN(hours) && !isNaN(minutes)) {
          // Create a date object with the time
          const date = new Date();
          date.setHours(hours, minutes, 0, 0);
          return date.toLocaleTimeString('es-ES', {
            hour: '2-digit',
            minute: '2-digit',
          });
        }
      }
      return timeString; // Return original string if parsing fails
    } catch (error) {
      console.error('Error formatting time:', timeString, error);
      return timeString; // Return original string if formatting fails
    }
  };

  if (state.loading && state.reservations.length === 0) {
    return (
      <LoadingContainer>
        <Loading />
      </LoadingContainer>
    );
  }

  return (
    <Container>
      <ControlsContainer>
        <SearchContainer>
          <SearchInput
            type="text"
            placeholder="Buscar por nombre, email, teléfono o room..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm && (
            <ClearButton
              variant="secondary"
              onClick={clearSearch}
            >
              Limpiar
            </ClearButton>
          )}
          <PageSizeSelector
            value={itemsPerPage}
            onChange={(e) => handleItemsPerPageChange(Number(e.target.value))}
          >
            {ITEMS_PER_PAGE_OPTIONS.map(size => (
              <option key={size} value={size}>
                {size} por página
              </option>
            ))}
          </PageSizeSelector>
        </SearchContainer>

        {/* Desktop Filters */}
        <DesktopFiltersContainer>
          <FilterButton
            active={filter === 'all'}
            onClick={() => setFilter('all')}
          >
            Todas ({state.reservations.length})
          </FilterButton>
          <FilterButton
            active={filter === 'pending'}
            onClick={() => setFilter('pending')}
          >
            Pendientes ({state.reservations.filter(r => r.status === 'pending').length})
          </FilterButton>
          <FilterButton
            active={filter === 'paid'}
            onClick={() => setFilter('paid')}
          >
            Pagadas ({state.reservations.filter(r => r.status === 'paid').length})
          </FilterButton>
          <FilterButton
            active={filter === 'cancelled'}
            onClick={() => setFilter('cancelled')}
          >
            Canceladas ({state.reservations.filter(r => r.status === 'cancelled').length})
          </FilterButton>
        </DesktopFiltersContainer>

        {/* Mobile Filters */}
        <MobileFiltersContainer>
          <FilterButton
            active={filter === 'all'}
            onClick={() => setFilter('all')}
          >
            Todas ({state.reservations.length})
          </FilterButton>
          <FilterDropdown
            value={filter === 'all' ? '' : filter}
            onChange={(e) => setFilter(e.target.value as FilterStatus || 'all')}
          >
            <option value="">Filtrar por estado</option>
            <option value="pending">
              Pendientes ({state.reservations.filter(r => r.status === 'pending').length})
            </option>
            <option value="paid">
              Pagadas ({state.reservations.filter(r => r.status === 'paid').length})
            </option>
            <option value="cancelled">
              Canceladas ({state.reservations.filter(r => r.status === 'cancelled').length})
            </option>
          </FilterDropdown>
        </MobileFiltersContainer>
      </ControlsContainer>

      {paginatedReservations.length === 0 ? (
        <EmptyState>
          {searchTerm ? (
            <>
              No se encontraron reservas que coincidan con "{searchTerm}"
              <br />
              <ClearButton
                variant="secondary"
                onClick={clearSearch}
              >
                Limpiar búsqueda
              </ClearButton>
            </>
          ) : filter === 'all' ? (
            'No hay reservas disponibles'
          ) : (
            `No hay reservas ${filter === 'pending' ? 'pendientes' : filter === 'paid' ? 'pagadas' : 'canceladas'}`
          )}
        </EmptyState>
      ) : (
        <>
          {/* Desktop Table View */}
          <ReservationsGrid>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHeaderCell>Cliente</TableHeaderCell>
                  <TableHeaderCell>Room</TableHeaderCell>
                  <TableHeaderCell>Fecha/Hora</TableHeaderCell>
                  <TableHeaderCell>Personas</TableHeaderCell>
                  <TableHeaderCell>Total</TableHeaderCell>
                  <TableHeaderCell>Estado</TableHeaderCell>
                  <TableHeaderCell>Acciones</TableHeaderCell>
                </TableRow>
              </TableHeader>
              <tbody>
                {paginatedReservations.map((reservation) => (
                  <TableRow key={reservation.id}>
                    <TableCell>
                      <div>
                        <div style={{ fontWeight: 600, color: '#1a1a1a' }}>
                          {reservation.customer_name}
                        </div>
                        <div style={{ fontSize: '0.75rem' }}>
                          {reservation.customer_email}
                        </div>
                        <div style={{ fontSize: '0.75rem' }}>
                          {reservation.customer_phone}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{reservation.room_name}</TableCell>
                    <TableCell>
                      <div>{formatDate(reservation.date)}</div>
                      <div style={{ fontSize: '0.75rem' }}>
                        {formatTime(reservation.time)}
                      </div>
                    </TableCell>
                    <TableCell>{reservation.num_people}</TableCell>
                    <TableCell>${reservation.total_price}</TableCell>
                    <TableCell>
                      <StatusBadge status={reservation.status}>
                        {statusLabels[reservation.status]}
                      </StatusBadge>
                    </TableCell>
                    <TableCell>
                      {reservation.status === 'pending' && (
                        <ActionButton
                          variant="primary"
                          onClick={() => handleStatusUpdate(reservation.id, 'paid')}
                          disabled={updatingIds.has(reservation.id)}
                        >
                          {updatingIds.has(reservation.id) ? (
                            <Loading size="small" />
                          ) : (
                            'Marcar Pagada'
                          )}
                        </ActionButton>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </tbody>
            </Table>
          </ReservationsGrid>

          {/* Mobile Cards View */}
          <ReservationCards>
            {paginatedReservations.map((reservation) => (
              <ReservationCard key={reservation.id}>
                <CardHeader>
                  <CardTitle>{reservation.customer_name}</CardTitle>
                  <StatusBadge status={reservation.status}>
                    {statusLabels[reservation.status]}
                  </StatusBadge>
                </CardHeader>
                
                <CardDetails>
                  <CardLabel>Room:</CardLabel>
                  <CardValue>{reservation.room_name}</CardValue>
                  
                  <CardLabel>Email:</CardLabel>
                  <CardValue>{reservation.customer_email}</CardValue>
                  
                  <CardLabel>Teléfono:</CardLabel>
                  <CardValue>{reservation.customer_phone}</CardValue>
                  
                  <CardLabel>Fecha:</CardLabel>
                  <CardValue>{formatDate(reservation.date)}</CardValue>
                  
                  <CardLabel>Hora:</CardLabel>
                  <CardValue>{formatTime(reservation.time)}</CardValue>
                  
                  <CardLabel>Personas:</CardLabel>
                  <CardValue>{reservation.num_people}</CardValue>
                  
                  <CardLabel>Total:</CardLabel>
                  <CardValue>${reservation.total_price}</CardValue>
                </CardDetails>

                {reservation.status === 'pending' && (
                  <ActionButton
                    variant="primary"
                    onClick={() => handleStatusUpdate(reservation.id, 'paid')}
                    disabled={updatingIds.has(reservation.id)}
                  >
                    {updatingIds.has(reservation.id) ? (
                      <Loading size="small" />
                    ) : (
                      'Marcar como Pagada'
                    )}
                  </ActionButton>
                )}
              </ReservationCard>
            ))}
          </ReservationCards>

          {/* Pagination */}
          {totalPages > 1 && (
            <PaginationContainer>
              <PaginationInfo>
                Mostrando {startItem}-{endItem} de {totalItems} reservas
              </PaginationInfo>
              
              <PaginationControls>
                <PaginationButton
                  variant="secondary"
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  ‹
                </PaginationButton>
                
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let pageNumber: number;
                  if (totalPages <= 5) {
                    pageNumber = i + 1;
                  } else if (currentPage <= 3) {
                    pageNumber = i + 1;
                  } else if (currentPage >= totalPages - 2) {
                    pageNumber = totalPages - 4 + i;
                  } else {
                    pageNumber = currentPage - 2 + i;
                  }
                  
                  return (
                    <PaginationButton
                      key={pageNumber}
                      variant={currentPage === pageNumber ? 'primary' : 'secondary'}
                      onClick={() => handlePageChange(pageNumber)}
                    >
                      {pageNumber}
                    </PaginationButton>
                  );
                })}
                
                <PaginationButton
                  variant="secondary"
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  ›
                </PaginationButton>
              </PaginationControls>
            </PaginationContainer>
          )}
        </>
      )}
    </Container>
  );
};