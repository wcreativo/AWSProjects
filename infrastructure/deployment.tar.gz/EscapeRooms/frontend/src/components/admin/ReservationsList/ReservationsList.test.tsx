import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { ReservationsList } from './ReservationsList';
import { theme } from '../../../styles';

// Mock the useAdmin hook
const mockUseAdmin = jest.fn();
jest.mock('../../../contexts/AdminContext', () => ({
  useAdmin: () => mockUseAdmin(),
}));

const renderWithProviders = (reservations: any[] = [], updateReservationStatus = jest.fn()) => {
  mockUseAdmin.mockReturnValue({
    state: {
      user: { username: 'testuser', isAuthenticated: true },
      reservations,
      loading: false,
      error: null,
    },
    login: jest.fn(),
    logout: jest.fn(),
    loadReservations: jest.fn(),
    updateReservationStatus,
    clearError: jest.fn(),
  });

  return render(
    <ThemeProvider theme={theme}>
      <ReservationsList />
    </ThemeProvider>
  );
};

const mockReservations = [
  {
    id: 1,
    room_name: 'Escape Room Alpha',
    customer_name: 'John Doe',
    customer_email: 'john@example.com',
    customer_phone: '123456789',
    date: '2024-01-01',
    time: '14:00',
    num_people: 2,
    total_price: 60,
    status: 'pending' as const,
    created_at: '2024-01-01T12:00:00Z',
  },
  {
    id: 2,
    room_name: 'Mystery Chamber',
    customer_name: 'Jane Smith',
    customer_email: 'jane@example.com',
    customer_phone: '987654321',
    date: '2024-01-02',
    time: '16:00',
    num_people: 4,
    total_price: 100,
    status: 'paid' as const,
    created_at: '2024-01-02T14:00:00Z',
  },
  {
    id: 3,
    room_name: 'Horror House',
    customer_name: 'Bob Johnson',
    customer_email: 'bob@example.com',
    customer_phone: '555666777',
    date: '2024-01-03',
    time: '18:00',
    num_people: 3,
    total_price: 90,
    status: 'cancelled' as const,
    created_at: '2024-01-03T16:00:00Z',
  },
  {
    id: 4,
    room_name: 'Adventure Quest',
    customer_name: 'Alice Brown',
    customer_email: 'alice@example.com',
    customer_phone: '111222333',
    date: '2024-01-04',
    time: '20:00',
    num_people: 5,
    total_price: 125,
    status: 'pending' as const,
    created_at: '2024-01-04T18:00:00Z',
  },
  {
    id: 5,
    room_name: 'Puzzle Palace',
    customer_name: 'Charlie Wilson',
    customer_email: 'charlie@example.com',
    customer_phone: '444555666',
    date: '2024-01-05',
    time: '15:00',
    num_people: 2,
    total_price: 60,
    status: 'paid' as const,
    created_at: '2024-01-05T13:00:00Z',
  },
];

// Create more reservations for pagination testing
const createManyReservations = (count: number) => {
  return Array.from({ length: count }, (_, i) => {
    const statusOptions = ['pending', 'paid', 'cancelled'] as const;
    return {
      id: i + 1,
      room_name: `Room ${i + 1}`,
      customer_name: `Customer ${i + 1}`,
      customer_email: `customer${i + 1}@example.com`,
      customer_phone: `${1000000000 + i}`,
      date: '2024-01-01',
      time: '14:00',
      num_people: 2,
      total_price: 60,
      status: statusOptions[i % 3],
      created_at: '2024-01-01T12:00:00Z',
    };
  });
};

describe('ReservationsList', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render search input and filters', async () => {
    renderWithProviders(mockReservations);
    
    await waitFor(() => {
      expect(screen.getByPlaceholderText(/buscar por nombre, email, teléfono o room/i)).toBeInTheDocument();
      expect(screen.getByText('Todas (5)')).toBeInTheDocument();
      expect(screen.getByText('Pendientes (2)')).toBeInTheDocument();
      expect(screen.getByText('Pagadas (2)')).toBeInTheDocument();
      expect(screen.getByText('Canceladas (1)')).toBeInTheDocument();
    });
  });

  it('should filter reservations by search term', async () => {
    renderWithProviders(mockReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2); // Desktop and mobile views
      expect(screen.getAllByText('Jane Smith')).toHaveLength(2);
    });

    // Search by customer name
    const searchInput = screen.getByPlaceholderText(/buscar por nombre, email, teléfono o room/i);
    fireEvent.change(searchInput, { target: { value: 'John' } });

    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2); // Still shows in both views
      expect(screen.queryByText('Jane Smith')).not.toBeInTheDocument();
    });
  });

  it('should filter reservations by email', async () => {
    renderWithProviders(mockReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2);
    });

    const searchInput = screen.getByPlaceholderText(/buscar por nombre, email, teléfono o room/i);
    fireEvent.change(searchInput, { target: { value: 'jane@example.com' } });

    await waitFor(() => {
      expect(screen.getAllByText('Jane Smith')).toHaveLength(2);
      expect(screen.queryByText('John Doe')).not.toBeInTheDocument();
    });
  });

  it('should filter reservations by phone', async () => {
    renderWithProviders(mockReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2);
    });

    const searchInput = screen.getByPlaceholderText(/buscar por nombre, email, teléfono o room/i);
    fireEvent.change(searchInput, { target: { value: '987654321' } });

    await waitFor(() => {
      expect(screen.getAllByText('Jane Smith')).toHaveLength(2);
      expect(screen.queryByText('John Doe')).not.toBeInTheDocument();
    });
  });

  it('should filter reservations by room name', async () => {
    renderWithProviders(mockReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2);
    });

    const searchInput = screen.getByPlaceholderText(/buscar por nombre, email, teléfono o room/i);
    fireEvent.change(searchInput, { target: { value: 'Mystery Chamber' } });

    await waitFor(() => {
      expect(screen.getAllByText('Jane Smith')).toHaveLength(2);
      expect(screen.queryByText('John Doe')).not.toBeInTheDocument();
    });
  });

  it('should clear search when clear button is clicked', async () => {
    renderWithProviders(mockReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2);
    });

    const searchInput = screen.getByPlaceholderText(/buscar por nombre, email, teléfono o room/i);
    fireEvent.change(searchInput, { target: { value: 'John' } });

    await waitFor(() => {
      expect(screen.queryByText('Jane Smith')).not.toBeInTheDocument();
    });

    const clearButton = screen.getByText('Limpiar');
    fireEvent.click(clearButton);

    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2);
      expect(screen.getAllByText('Jane Smith')).toHaveLength(2);
      expect(searchInput).toHaveValue('');
    });
  });

  it('should show empty state when search returns no results', async () => {
    renderWithProviders(mockReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2);
    });

    const searchInput = screen.getByPlaceholderText(/buscar por nombre, email, teléfono o room/i);
    fireEvent.change(searchInput, { target: { value: 'nonexistent' } });

    await waitFor(() => {
      expect(screen.getByText(/no se encontraron reservas que coincidan con "nonexistent"/i)).toBeInTheDocument();
      expect(screen.getByText('Limpiar búsqueda')).toBeInTheDocument();
    });
  });

  it('should filter by status', async () => {
    renderWithProviders(mockReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2);
      expect(screen.getAllByText('Jane Smith')).toHaveLength(2);
    });

    // Filter by pending
    const pendingButton = screen.getByText('Pendientes (2)');
    fireEvent.click(pendingButton);

    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2);
      expect(screen.getAllByText('Alice Brown')).toHaveLength(2);
      expect(screen.queryByText('Jane Smith')).not.toBeInTheDocument();
    });
  });

  it('should handle pagination with many reservations', async () => {
    const manyReservations = createManyReservations(25);
    renderWithProviders(manyReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('Customer 1')).toHaveLength(2);
      expect(screen.getAllByText('Customer 10')).toHaveLength(2);
      expect(screen.queryByText('Customer 11')).not.toBeInTheDocument();
    });

    // Check pagination info
    expect(screen.getByText('Mostrando 1-10 de 25 reservas')).toBeInTheDocument();

    // Go to next page
    const nextButton = screen.getByText('›');
    fireEvent.click(nextButton);

    await waitFor(() => {
      expect(screen.getAllByText('Customer 11')).toHaveLength(2);
      expect(screen.getAllByText('Customer 20')).toHaveLength(2);
      expect(screen.queryByText('Customer 10')).not.toBeInTheDocument();
    });

    expect(screen.getByText('Mostrando 11-20 de 25 reservas')).toBeInTheDocument();
  });

  it('should change items per page', async () => {
    const manyReservations = createManyReservations(30);
    renderWithProviders(manyReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('Customer 1')).toHaveLength(2);
      expect(screen.getAllByText('Customer 10')).toHaveLength(2);
      expect(screen.queryByText('Customer 26')).not.toBeInTheDocument();
    });

    // Change to 25 per page
    const pageSizeSelector = screen.getByDisplayValue('10 por página');
    fireEvent.change(pageSizeSelector, { target: { value: '25' } });

    await waitFor(() => {
      expect(screen.getAllByText('Customer 1')).toHaveLength(2);
      expect(screen.getAllByText('Customer 25')).toHaveLength(2);
      expect(screen.queryByText('Customer 26')).not.toBeInTheDocument();
    });

    expect(screen.getByText('Mostrando 1-25 de 30 reservas')).toBeInTheDocument();
  });

  it('should reset to first page when search changes', async () => {
    const manyReservations = createManyReservations(25);
    renderWithProviders(manyReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('Customer 1')).toHaveLength(2);
    });

    // Go to page 2
    const nextButton = screen.getByText('›');
    fireEvent.click(nextButton);

    await waitFor(() => {
      expect(screen.getAllByText('Customer 11')).toHaveLength(2);
    });

    // Search for something
    const searchInput = screen.getByPlaceholderText(/buscar por nombre, email, teléfono o room/i);
    fireEvent.change(searchInput, { target: { value: 'Customer 1' } });

    // Should be back on page 1 with filtered results
    await waitFor(() => {
      expect(screen.getAllByText('Customer 1')).toHaveLength(2);
      expect(screen.getAllByText('Customer 10')).toHaveLength(2);
      expect(screen.queryByText('Customer 2')).not.toBeInTheDocument(); // Customer 2 doesn't match "Customer 1"
    });
  });

  it('should update reservation status', async () => {
    const mockUpdateReservationStatus = jest.fn();
    renderWithProviders(mockReservations, mockUpdateReservationStatus);
    
    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2); // Desktop and mobile views
    });

    // Find and click the "Marcar Pagada" button for John Doe's reservation
    const markPaidButtons = screen.getAllByText(/marcar.*pagada/i);
    fireEvent.click(markPaidButtons[0]);

    await waitFor(() => {
      expect(mockUpdateReservationStatus).toHaveBeenCalledWith(1, 'paid');
    });
  });

  it('should show pagination controls only when needed', async () => {
    renderWithProviders(mockReservations.slice(0, 5));
    
    await waitFor(() => {
      expect(screen.getAllByText('John Doe')).toHaveLength(2); // Desktop and mobile views
    });

    // Should not show pagination for 5 items with 10 per page
    expect(screen.queryByText('Mostrando')).not.toBeInTheDocument();
    expect(screen.queryByText('›')).not.toBeInTheDocument();
  });

  it('should handle pagination navigation correctly', async () => {
    const manyReservations = createManyReservations(50);
    renderWithProviders(manyReservations);
    
    await waitFor(() => {
      expect(screen.getAllByText('Customer 1')).toHaveLength(2); // Desktop and mobile views
    });

    // Should show page numbers - use more specific selectors
    const allButtons = screen.getAllByRole('button');
    const pageButtons = allButtons.filter(button => 
      ['1', '2', '3', '4', '5'].includes(button.textContent || '')
    );
    expect(pageButtons).toHaveLength(5); // Should have 5 page buttons for 50 items

    // Previous button should be disabled on first page
    const prevButton = screen.getByText('‹');
    expect(prevButton).toBeDisabled();

    // Click page 3
    const page3Button = allButtons.find(button => button.textContent === '3');
    fireEvent.click(page3Button!);

    await waitFor(() => {
      expect(screen.getAllByText('Customer 21')).toHaveLength(2);
      expect(screen.getAllByText('Customer 30')).toHaveLength(2);
    });

    // Go to last page
    const page5Button = allButtons.find(button => button.textContent === '5');
    fireEvent.click(page5Button!);

    await waitFor(() => {
      expect(screen.getAllByText('Customer 41')).toHaveLength(2);
      expect(screen.getAllByText('Customer 50')).toHaveLength(2);
    });

    // Next button should be disabled on last page
    const nextButton = screen.getByText('›');
    expect(nextButton).toBeDisabled();
  });
});