import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { AdminProvider } from '../../contexts/AdminContext';
import { LoginForm } from '../admin/LoginForm';
import { AdminDashboard } from '../admin/AdminDashboard';
import { AdminLayout } from '../admin/AdminLayout';
import { ProtectedRoute } from '../common/ProtectedRoute';
import { theme } from '../../styles';
import { adminApi } from '../../services/api';

// Mock the API
jest.mock('../../services/api', () => ({
  adminApi: {
    login: jest.fn(),
    getReservations: jest.fn(),
    updateReservationStatus: jest.fn(),
  },
}));

const mockAdminApi = adminApi as jest.Mocked<typeof adminApi>;

const renderAdminFlow = () => {
  return render(
    <ThemeProvider theme={theme}>
      <AdminProvider>
        <ProtectedRoute>
          <AdminLayout>
            <AdminDashboard />
          </AdminLayout>
        </ProtectedRoute>
      </AdminProvider>
    </ThemeProvider>
  );
};

const mockReservations = [
  {
    id: 1,
    room_name: 'Escape Room 1',
    customer_name: 'John Doe',
    customer_email: 'john@example.com',
    customer_phone: '123456789',
    date: '2024-01-01',
    time: '14:00',
    num_people: 2,
    total_price: 60,
    status: 'pending' as const,
    created_at: '2024-01-01T12:00:00Z',
  },
  {
    id: 2,
    room_name: 'Escape Room 2',
    customer_name: 'Jane Smith',
    customer_email: 'jane@example.com',
    customer_phone: '987654321',
    date: '2024-01-02',
    time: '16:00',
    num_people: 4,
    total_price: 100,
    status: 'paid' as const,
    created_at: '2024-01-02T14:00:00Z',
  },
];

describe('Admin Authentication Integration', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  it('should show login form when not authenticated', () => {
    renderAdminFlow();
    
    expect(screen.getByText('Panel Administrativo')).toBeInTheDocument();
    expect(screen.getByLabelText('Usuario')).toBeInTheDocument();
    expect(screen.getByLabelText('Contraseña')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Iniciar Sesión' })).toBeInTheDocument();
  });

  it('should complete full authentication flow', async () => {
    mockAdminApi.login.mockResolvedValue({
      access_token: 'access-token',
      refresh_token: 'refresh-token',
    });
    mockAdminApi.getReservations.mockResolvedValue(mockReservations);

    renderAdminFlow();
    
    // Fill login form
    const usernameInput = screen.getByLabelText('Usuario');
    const passwordInput = screen.getByLabelText('Contraseña');
    const loginButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    
    fireEvent.change(usernameInput, { target: { value: 'admin' } });
    fireEvent.change(passwordInput, { target: { value: 'password' } });
    fireEvent.click(loginButton);
    
    // Wait for login to complete and dashboard to load
    await waitFor(() => {
      expect(screen.getByText('Panel Administrativo')).toBeInTheDocument(); // Header title
      expect(screen.getByText('Bienvenido, admin')).toBeInTheDocument();
    });

    // Check that dashboard content is loaded
    await waitFor(() => {
      expect(screen.getByText('Total Reservas')).toBeInTheDocument();
    });
    
    // Check that we have the correct total count by looking for the parent stat card
    const totalReservasLabel = screen.getByText('Total Reservas');
    const statCard = totalReservasLabel.parentElement;
    expect(statCard).toHaveTextContent('2');
    expect(statCard).toHaveTextContent('Total Reservas');

    // Verify API calls
    expect(mockAdminApi.login).toHaveBeenCalledWith('admin', 'password');
    expect(mockAdminApi.getReservations).toHaveBeenCalled();
  });

  it('should handle login failure gracefully', async () => {
    mockAdminApi.login.mockRejectedValue({
      response: { status: 401 },
    });

    renderAdminFlow();
    
    const usernameInput = screen.getByLabelText('Usuario');
    const passwordInput = screen.getByLabelText('Contraseña');
    const loginButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    
    fireEvent.change(usernameInput, { target: { value: 'admin' } });
    fireEvent.change(passwordInput, { target: { value: 'wrong-password' } });
    fireEvent.click(loginButton);
    
    await waitFor(() => {
      expect(screen.getByText('Usuario o contraseña incorrectos')).toBeInTheDocument();
    });

    // Should still be on login form
    expect(screen.getByLabelText('Usuario')).toBeInTheDocument();
    expect(screen.getByLabelText('Contraseña')).toBeInTheDocument();
  });

  it('should logout and return to login form', async () => {
    mockAdminApi.login.mockResolvedValue({
      access_token: 'access-token',
      refresh_token: 'refresh-token',
    });
    mockAdminApi.getReservations.mockResolvedValue(mockReservations);

    renderAdminFlow();
    
    // Login first
    const usernameInput = screen.getByLabelText('Usuario');
    const passwordInput = screen.getByLabelText('Contraseña');
    const loginButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    
    fireEvent.change(usernameInput, { target: { value: 'admin' } });
    fireEvent.change(passwordInput, { target: { value: 'password' } });
    fireEvent.click(loginButton);
    
    // Wait for dashboard to load
    await waitFor(() => {
      expect(screen.getByText('Bienvenido, admin')).toBeInTheDocument();
    });

    // Logout
    const logoutButton = screen.getByRole('button', { name: 'Cerrar Sesión' });
    fireEvent.click(logoutButton);
    
    // Should return to login form
    await waitFor(() => {
      expect(screen.getByLabelText('Usuario')).toBeInTheDocument();
      expect(screen.getByLabelText('Contraseña')).toBeInTheDocument();
    });

    // Check localStorage is cleared
    expect(localStorage.getItem('authToken')).toBeNull();
    expect(localStorage.getItem('adminUsername')).toBeNull();
  });

  it('should restore session from localStorage', async () => {
    // Set up existing session
    localStorage.setItem('authToken', 'existing-token');
    localStorage.setItem('adminUsername', 'admin');
    
    mockAdminApi.getReservations.mockResolvedValue(mockReservations);

    renderAdminFlow();
    
    // Should skip login and go directly to dashboard
    await waitFor(() => {
      expect(screen.getByText('Bienvenido, admin')).toBeInTheDocument();
    });

    expect(screen.queryByLabelText('Usuario')).not.toBeInTheDocument();
    expect(mockAdminApi.getReservations).toHaveBeenCalled();
  });

  it('should update reservation status from dashboard', async () => {
    localStorage.setItem('authToken', 'existing-token');
    localStorage.setItem('adminUsername', 'admin');
    
    mockAdminApi.getReservations.mockResolvedValue(mockReservations);
    mockAdminApi.updateReservationStatus.mockResolvedValue({});

    renderAdminFlow();
    
    // Wait for dashboard to load
    await waitFor(() => {
      expect(screen.getByText('Bienvenido, admin')).toBeInTheDocument();
    });

    // Wait for reservations to load and find a "Marcar Pagada" button
    await waitFor(() => {
      const markPaidButtons = screen.getAllByText(/Marcar.*Pagada/);
      expect(markPaidButtons.length).toBeGreaterThan(0);
    });

    // Click the first "Marcar Pagada" button
    const markPaidButton = screen.getAllByText(/Marcar.*Pagada/)[0];
    fireEvent.click(markPaidButton);
    
    await waitFor(() => {
      expect(mockAdminApi.updateReservationStatus).toHaveBeenCalledWith(1, 'paid');
    });
  });
});