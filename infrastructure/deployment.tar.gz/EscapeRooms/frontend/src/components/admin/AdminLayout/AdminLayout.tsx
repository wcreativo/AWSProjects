import React from 'react';
import styled from 'styled-components';
import { Button } from '../../common';
import { useAdmin } from '../../../contexts/AdminContext';

const LayoutContainer = styled.div`
  min-height: 100vh;
  background: #f8fafc;
`;

const Header = styled.header`
  background: white;
  border-bottom: 1px solid #e5e7eb;
  padding: 1rem;
  position: sticky;
  top: 0;
  z-index: 100;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
`;

const HeaderContent = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;

  @media (max-width: 768px) {
    flex-direction: column;
    gap: 0.75rem;
  }
`;

const Title = styled.h1`
  font-size: 1.5rem;
  font-weight: 700;
  color: #1a1a1a;
  margin: 0;

  @media (max-width: 768px) {
    font-size: 1.25rem;
    text-align: center;
  }
`;

const UserInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;

  @media (max-width: 768px) {
    flex-direction: column;
    gap: 0.5rem;
    text-align: center;
  }
`;

const Username = styled.span`
  font-size: 0.875rem;
  color: #6b7280;
  font-weight: 500;

  @media (max-width: 768px) {
    font-size: 0.8rem;
  }
`;

const LogoutButton = styled(Button)`
  min-height: 36px;
  font-size: 0.875rem;
  padding: 0.5rem 1rem;
  background: #dc2626 !important;
  color: white !important;
  border: 1px solid #dc2626 !important;

  &:hover:not(:disabled) {
    background: #b91c1c !important;
    border-color: #b91c1c !important;
  }

  &:active {
    background: #991b1b !important;
  }

  @media (max-width: 768px) {
    min-height: 44px;
    font-size: 1rem;
    padding: 0.75rem 1.5rem;
  }
`;

const Main = styled.main`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem 1rem;

  @media (max-width: 768px) {
    padding: 1rem;
  }
`;

interface AdminLayoutProps {
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const { state, logout } = useAdmin();

  const handleLogout = () => {
    logout();
  };

  return (
    <LayoutContainer>
      <Header>
        <HeaderContent>
          <Title>Panel Administrativo</Title>
          <UserInfo>
            <Username>
              Bienvenido, {state.user?.username}
            </Username>
            <LogoutButton
              variant="secondary"
              onClick={handleLogout}
            >
              Cerrar Sesión
            </LogoutButton>
          </UserInfo>
        </HeaderContent>
      </Header>
      <Main>
        {children}
      </Main>
    </LayoutContainer>
  );
};