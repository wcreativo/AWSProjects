import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { AdminDashboard } from './AdminDashboard';
import { AdminProvider } from '../../../contexts/AdminContext';
import { theme } from '../../../styles';
import { adminApi } from '../../../services/api';

// Mock the API
jest.mock('../../../services/api', () => ({
  adminApi: {
    getReservations: jest.fn(),
  },
}));

const mockAdminApi = adminApi as jest.Mocked<typeof adminApi>;

// Mock the ReservationsList component
jest.mock('../ReservationsList', () => ({
  ReservationsList: () => <div data-testid="reservations-list">Reservations List</div>,
}));

const renderWithProviders = () => {
  return render(
    <ThemeProvider theme={theme}>
      <AdminProvider>
        <AdminDashboard />
      </AdminProvider>
    </ThemeProvider>
  );
};

const mockReservations = [
  {
    id: 1,
    room_name: 'Test Room 1',
    customer_name: 'John Doe',
    customer_email: 'john@example.com',
    customer_phone: '123456789',
    date: '2024-01-01',
    time: '14:00',
    num_people: 2,
    total_price: 60,
    status: 'pending' as const,
    created_at: '2024-01-01T12:00:00Z',
  },
  {
    id: 2,
    room_name: 'Test Room 2',
    customer_name: 'Jane Smith',
    customer_email: 'jane@example.com',
    customer_phone: '987654321',
    date: '2024-01-02',
    time: '16:00',
    num_people: 4,
    total_price: 100,
    status: 'paid' as const,
    created_at: '2024-01-02T14:00:00Z',
  },
  {
    id: 3,
    room_name: 'Test Room 3',
    customer_name: 'Bob Johnson',
    customer_email: 'bob@example.com',
    customer_phone: '555666777',
    date: '2024-01-03',
    time: '18:00',
    num_people: 3,
    total_price: 90,
    status: 'cancelled' as const,
    created_at: '2024-01-03T16:00:00Z',
  },
];

describe('AdminDashboard', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should show loading state initially', () => {
    mockAdminApi.getReservations.mockImplementation(() => new Promise(() => {})); // Never resolves
    
    renderWithProviders();
    
    expect(screen.getByTestId('dashboard-loading')).toBeInTheDocument();
  });

  it('should load and display reservations statistics', async () => {
    mockAdminApi.getReservations.mockResolvedValue(mockReservations);
    
    renderWithProviders();
    
    await waitFor(() => {
      expect(screen.getByText('3')).toBeInTheDocument(); // Total
      expect(screen.getByText('Total Reservas')).toBeInTheDocument();
    });

    // Check for the labels to ensure we're looking at the right stats
    expect(screen.getByText('Pendientes')).toBeInTheDocument();
    expect(screen.getByText('Pagadas')).toBeInTheDocument();
    expect(screen.getByText('Canceladas')).toBeInTheDocument();
    
    // Check that all stat cards are present by checking their container structure
    const statCards = screen.getAllByText(/^(Total Reservas|Pendientes|Pagadas|Canceladas)$/);
    expect(statCards).toHaveLength(4);
  });

  it('should display error message when loading fails', async () => {
    mockAdminApi.getReservations.mockRejectedValue({
      response: { data: { detail: 'Failed to load reservations' } },
    });
    
    renderWithProviders();
    
    await waitFor(() => {
      expect(screen.getByText('No se pudieron cargar las reservas')).toBeInTheDocument();
    });
  });

  it('should render reservations list component', async () => {
    mockAdminApi.getReservations.mockResolvedValue(mockReservations);
    
    renderWithProviders();
    
    await waitFor(() => {
      expect(screen.getByTestId('reservations-list')).toBeInTheDocument();
    });
  });

  it('should display reservations section header', async () => {
    mockAdminApi.getReservations.mockResolvedValue(mockReservations);
    
    renderWithProviders();
    
    await waitFor(() => {
      expect(screen.getByText('Reservas')).toBeInTheDocument();
    });
  });

  it('should calculate statistics correctly with empty reservations', async () => {
    mockAdminApi.getReservations.mockResolvedValue([]);
    
    renderWithProviders();
    
    await waitFor(() => {
      // All stats should be 0
      const statValues = screen.getAllByText('0');
      expect(statValues).toHaveLength(4); // Total, Pending, Paid, Cancelled
    });
  });

  it('should call loadReservations on mount', async () => {
    mockAdminApi.getReservations.mockResolvedValue(mockReservations);
    
    renderWithProviders();
    
    await waitFor(() => {
      expect(mockAdminApi.getReservations).toHaveBeenCalledTimes(1);
    });
  });
});