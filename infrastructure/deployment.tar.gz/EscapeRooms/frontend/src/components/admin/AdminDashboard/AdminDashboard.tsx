import React, { useEffect } from 'react';
import styled from 'styled-components';
import { Loading } from '../../common';
import { useAdmin } from '../../../contexts/AdminContext';
import { ReservationsList } from '../ReservationsList';

const DashboardContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 2rem;
`;

const StatsSection = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const StatCard = styled.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #e5e7eb;

  @media (max-width: 768px) {
    padding: 1rem;
  }
`;

const StatValue = styled.div`
  font-size: 2rem;
  font-weight: 700;
  color: #1a1a1a;
  margin-bottom: 0.5rem;

  @media (max-width: 768px) {
    font-size: 1.75rem;
  }
`;

const StatLabel = styled.div`
  font-size: 0.875rem;
  color: #6b7280;
  font-weight: 500;
`;

const ReservationsSection = styled.div`
  background: white;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #e5e7eb;
  overflow: hidden;
`;

const SectionHeader = styled.div`
  padding: 1.5rem;
  border-bottom: 1px solid #e5e7eb;
  background: #f9fafb;

  @media (max-width: 768px) {
    padding: 1rem;
  }
`;

const SectionTitle = styled.h2`
  font-size: 1.25rem;
  font-weight: 700;
  color: #1a1a1a;
  margin: 0;

  @media (max-width: 768px) {
    font-size: 1.125rem;
  }
`;

const ErrorMessage = styled.div`
  background: #fef2f2;
  border: 1px solid #fecaca;
  color: #dc2626;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
`;

const LoadingContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 200px;
`;

export const AdminDashboard: React.FC = () => {
  const { state, loadReservations, clearError } = useAdmin();

  useEffect(() => {
    loadReservations();
  }, [loadReservations]);

  const stats = React.useMemo(() => {
    // Ensure reservations is always an array
    const reservations = Array.isArray(state.reservations) ? state.reservations : [];
    
    const total = reservations.length;
    const pending = reservations.filter(r => r.status === 'pending').length;
    const paid = reservations.filter(r => r.status === 'paid').length;
    const cancelled = reservations.filter(r => r.status === 'cancelled').length;

    return { total, pending, paid, cancelled };
  }, [state.reservations]);

  if (state.loading && (!state.reservations || state.reservations.length === 0)) {
    return (
      <LoadingContainer data-testid="dashboard-loading">
        <Loading />
      </LoadingContainer>
    );
  }

  return (
    <DashboardContainer>
      {state.error && (
        <ErrorMessage>
          {state.error}
          <button 
            onClick={clearError}
            style={{ 
              marginLeft: '1rem', 
              background: 'none', 
              border: 'none', 
              color: 'inherit', 
              textDecoration: 'underline',
              cursor: 'pointer'
            }}
          >
            Cerrar
          </button>
        </ErrorMessage>
      )}

      <StatsSection>
        <StatCard>
          <StatValue>{stats.total}</StatValue>
          <StatLabel>Total Reservas</StatLabel>
        </StatCard>
        <StatCard>
          <StatValue>{stats.pending}</StatValue>
          <StatLabel>Pendientes</StatLabel>
        </StatCard>
        <StatCard>
          <StatValue>{stats.paid}</StatValue>
          <StatLabel>Pagadas</StatLabel>
        </StatCard>
        <StatCard>
          <StatValue>{stats.cancelled}</StatValue>
          <StatLabel>Canceladas</StatLabel>
        </StatCard>
      </StatsSection>

      <ReservationsSection>
        <SectionHeader>
          <SectionTitle>Reservas</SectionTitle>
        </SectionHeader>
        <ReservationsList />
      </ReservationsSection>
    </DashboardContainer>
  );
};