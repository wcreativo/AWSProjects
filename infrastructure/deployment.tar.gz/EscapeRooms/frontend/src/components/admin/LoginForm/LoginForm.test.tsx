import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { LoginForm } from './LoginForm';
import { AdminProvider } from '../../../contexts/AdminContext';
import { theme } from '../../../styles';
import { adminApi } from '../../../services/api';

// Mock the API
jest.mock('../../../services/api', () => ({
  adminApi: {
    login: jest.fn(),
  },
}));

const mockAdminApi = adminApi as jest.Mocked<typeof adminApi>;

const renderWithProviders = (props = {}) => {
  return render(
    <ThemeProvider theme={theme}>
      <AdminProvider>
        <LoginForm {...props} />
      </AdminProvider>
    </ThemeProvider>
  );
};

describe('LoginForm', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  it('should render login form', () => {
    renderWithProviders();
    
    expect(screen.getByText('Panel Administrativo')).toBeInTheDocument();
    expect(screen.getByLabelText('Usuario')).toBeInTheDocument();
    expect(screen.getByLabelText('Contraseña')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Iniciar Sesión' })).toBeInTheDocument();
  });

  it('should disable submit button when fields are empty', () => {
    renderWithProviders();
    
    const submitButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    expect(submitButton).toBeDisabled();
  });

  it('should enable submit button when fields are filled', () => {
    renderWithProviders();
    
    const usernameInput = screen.getByLabelText('Usuario');
    const passwordInput = screen.getByLabelText('Contraseña');
    const submitButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    
    fireEvent.change(usernameInput, { target: { value: 'admin' } });
    fireEvent.change(passwordInput, { target: { value: 'password' } });
    
    expect(submitButton).not.toBeDisabled();
  });

  it('should handle successful login', async () => {
    const mockOnLoginSuccess = jest.fn();
    mockAdminApi.login.mockResolvedValue({
      access_token: 'access-token',
      refresh_token: 'refresh-token',
    });

    renderWithProviders({ onLoginSuccess: mockOnLoginSuccess });
    
    const usernameInput = screen.getByLabelText('Usuario');
    const passwordInput = screen.getByLabelText('Contraseña');
    const submitButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    
    fireEvent.change(usernameInput, { target: { value: 'admin' } });
    fireEvent.change(passwordInput, { target: { value: 'password' } });
    fireEvent.click(submitButton);
    
    await waitFor(() => {
      expect(mockOnLoginSuccess).toHaveBeenCalled();
    });
  });

  it('should display error message on login failure', async () => {
    mockAdminApi.login.mockRejectedValue({
      response: { status: 401 },
    });

    renderWithProviders();
    
    const usernameInput = screen.getByLabelText('Usuario');
    const passwordInput = screen.getByLabelText('Contraseña');
    const submitButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    
    fireEvent.change(usernameInput, { target: { value: 'admin' } });
    fireEvent.change(passwordInput, { target: { value: 'wrong-password' } });
    fireEvent.click(submitButton);
    
    await waitFor(() => {
      expect(screen.getByText('Usuario o contraseña incorrectos')).toBeInTheDocument();
    });
  });

  it('should clear error when user starts typing', async () => {
    mockAdminApi.login.mockRejectedValue({
      response: { status: 401 },
    });

    renderWithProviders();
    
    const usernameInput = screen.getByLabelText('Usuario');
    const passwordInput = screen.getByLabelText('Contraseña');
    const submitButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    
    // First, trigger an error
    fireEvent.change(usernameInput, { target: { value: 'admin' } });
    fireEvent.change(passwordInput, { target: { value: 'wrong-password' } });
    fireEvent.click(submitButton);
    
    await waitFor(() => {
      expect(screen.getByText('Usuario o contraseña incorrectos')).toBeInTheDocument();
    });

    // Then type in the username field to clear the error
    fireEvent.change(usernameInput, { target: { value: 'admin2' } });
    
    expect(screen.queryByText('Usuario o contraseña incorrectos')).not.toBeInTheDocument();
  });

  it('should show loading state during login', async () => {
    let resolveLogin: ((value: { access_token: string; refresh_token: string }) => void) | undefined;
    const loginPromise = new Promise<{ access_token: string; refresh_token: string }>((resolve) => {
      resolveLogin = resolve;
    });
    mockAdminApi.login.mockReturnValue(loginPromise);

    renderWithProviders();
    
    const usernameInput = screen.getByLabelText('Usuario');
    const passwordInput = screen.getByLabelText('Contraseña');
    const submitButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    
    fireEvent.change(usernameInput, { target: { value: 'admin' } });
    fireEvent.change(passwordInput, { target: { value: 'password' } });
    fireEvent.click(submitButton);
    
    // Should show loading state
    expect(submitButton).toBeDisabled();
    expect(usernameInput).toBeDisabled();
    expect(passwordInput).toBeDisabled();
    
    // Resolve the promise
    if (resolveLogin) {
      resolveLogin({
        access_token: 'access-token',
        refresh_token: 'refresh-token',
      });
    }
    
    await waitFor(() => {
      expect(submitButton).not.toBeDisabled();
    });
  });

  it('should prevent form submission with empty fields', () => {
    renderWithProviders();
    
    const submitButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    
    // Button should be disabled with empty fields
    expect(submitButton).toBeDisabled();
    
    // Try to click the disabled button
    fireEvent.click(submitButton);
    
    expect(mockAdminApi.login).not.toHaveBeenCalled();
  });

  it('should trim whitespace from username', async () => {
    mockAdminApi.login.mockResolvedValue({
      access_token: 'access-token',
      refresh_token: 'refresh-token',
    });

    renderWithProviders();
    
    const usernameInput = screen.getByLabelText('Usuario');
    const passwordInput = screen.getByLabelText('Contraseña');
    const submitButton = screen.getByRole('button', { name: 'Iniciar Sesión' });
    
    fireEvent.change(usernameInput, { target: { value: '  admin  ' } });
    fireEvent.change(passwordInput, { target: { value: 'password' } });
    fireEvent.click(submitButton);
    
    await waitFor(() => {
      expect(mockAdminApi.login).toHaveBeenCalledWith('admin', 'password');
    });
  });
});