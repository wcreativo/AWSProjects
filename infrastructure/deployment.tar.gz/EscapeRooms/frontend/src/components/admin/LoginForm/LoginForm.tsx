import React, { useState } from 'react';
import styled from 'styled-components';
import { Button, Loading } from '../../common';
import { useAdmin } from '../../../contexts/AdminContext';
import { Layout } from '../../layout/Layout';

const LoginContainer = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1rem;
  padding-top: 120px; /* Space for header */
  background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
`;

const LoginCard = styled.div`
  width: 100%;
  max-width: 320px;
  background: rgba(255, 255, 255, 0.92);
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255, 255, 255, 0.15);

  @media (max-width: 768px) {
    margin: 1rem;
    padding: 1.25rem;
    max-width: 300px;
  }
`;



const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
`;

const InputGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const Label = styled.label`
  font-size: 0.875rem;
  font-weight: 600;
  color: #374151;
`;

const Input = styled.input`
  min-height: 40px;
  padding: 0.625rem 0.875rem;
  border: 1px solid #e5e7eb;
  border-radius: 6px;
  font-size: 0.875rem;
  transition: all 0.2s ease;
  background: white;

  &:focus {
    outline: none;
    border-color: #007aff;
    box-shadow: 0 0 0 2px rgba(0, 122, 255, 0.08);
  }

  &:disabled {
    background: #f9fafb;
    color: #9ca3af;
    cursor: not-allowed;
  }

  @media (max-width: 768px) {
    font-size: 16px; /* Prevents zoom on iOS */
  }
`;

const ErrorMessage = styled.div`
  background: #fef2f2;
  border: 1px solid #fecaca;
  color: #dc2626;
  padding: 0.75rem 1rem;
  border-radius: 8px;
  font-size: 0.875rem;
  margin-bottom: 1rem;
`;

const LoginButton = styled(Button)`
  min-height: 40px;
  font-size: 0.875rem;
  font-weight: 500;
  margin-top: 0.25rem;
`;

interface LoginFormProps {
  onLoginSuccess?: () => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { state, login, clearError } = useAdmin();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();

    if (!username.trim() || !password.trim()) {
      return;
    }

    try {
      await login(username.trim(), password);
      onLoginSuccess?.();
    } catch (error) {
      // Error is handled by the context
    }
  };

  const handleInputChange = () => {
    if (state.error) {
      clearError();
    }
  };

  return (
    <Layout>
      <LoginContainer>
        <LoginCard>
          {state.error && (
            <ErrorMessage>
              {state.error}
            </ErrorMessage>
          )}

          <Form onSubmit={handleSubmit}>
            <InputGroup>
              <Label htmlFor="username">Usuario</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                  handleInputChange();
                }}
                disabled={state.loading}
                required
                autoComplete="username"
                placeholder="Ingresa tu usuario"
              />
            </InputGroup>

            <InputGroup>
              <Label htmlFor="password">Contraseña</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  handleInputChange();
                }}
                disabled={state.loading}
                required
                autoComplete="current-password"
                placeholder="Ingresa tu contraseña"
              />
            </InputGroup>

            <LoginButton
              type="submit"
              variant="primary"
              disabled={state.loading || !username.trim() || !password.trim()}
            >
              {state.loading ? <Loading size="small" /> : 'Iniciar Sesión'}
            </LoginButton>
          </Form>
        </LoginCard>
      </LoginContainer>
    </Layout>
  );
};