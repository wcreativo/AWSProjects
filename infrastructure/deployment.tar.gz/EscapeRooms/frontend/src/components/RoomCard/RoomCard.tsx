import React from 'react';
import styled from 'styled-components';
import { Room } from '../../contexts/RoomContext';

interface RoomCardProps {
  room: Room;
  isSelected?: boolean;
  onClick: (room: Room) => void;
}

const CardContainer = styled.div.withConfig({
  shouldForwardProp: (prop) => prop !== 'isSelected',
})<{ isSelected: boolean }>`
  position: relative;
  width: 280px;
  height: 160px;
  border-radius: ${props => props.theme.borderRadius.lg};
  overflow: hidden;
  cursor: pointer;
  transition: ${props => props.theme.transitions.normal};
  flex-shrink: 0;
  
  /* Mobile-first: touch-friendly sizing */
  min-width: 280px;
  
  /* Selection state */
  border: 2px solid ${props => 
    props.isSelected 
      ? props.theme.colors.secondary.main 
      : 'transparent'
  };
  
  /* Hover and touch effects */
  &:hover {
    transform: scale(1.05);
    box-shadow: ${props => props.theme.shadows.lg};
  }
  
  &:active {
    transform: scale(0.98);
  }
  
  /* Focus for accessibility */
  &:focus-visible {
    outline: 2px solid ${props => props.theme.colors.primary.main};
    outline-offset: 2px;
  }
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    width: 320px;
    height: 180px;
    min-width: 320px;
  }
  
  @media (min-width: ${props => props.theme.breakpoints.desktop}) {
    width: 300px;
    height: 170px;
    min-width: 300px;
  }
`;

const CardImage = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: ${props => props.theme.transitions.normal};
  
  ${CardContainer}:hover & {
    transform: scale(1.1);
  }
`;

const CardOverlay = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(
    transparent 0%,
    rgba(0, 0, 0, 0.3) 30%,
    rgba(0, 0, 0, 0.8) 100%
  );
  padding: ${props => props.theme.spacing.lg} ${props => props.theme.spacing.md};
  color: ${props => props.theme.colors.text.primary};
`;

const CardTitle = styled.h3`
  font-family: ${props => props.theme.typography.fontFamily.heading};
  font-size: 1.25rem;
  font-weight: 400;
  margin: 0 0 ${props => props.theme.spacing.xs} 0;
  line-height: 1.2;
  letter-spacing: 0.01em;
  text-transform: uppercase;
`;

const CardDescription = styled.p`
  font-family: ${props => props.theme.typography.fontFamily.primary};
  font-size: ${props => props.theme.typography.fontSize.sm};
  font-weight: 400;
  color: ${props => props.theme.colors.text.secondary};
  margin: 0 0 ${props => props.theme.spacing.sm} 0;
  line-height: 1.5;
  letter-spacing: -0.01em;
  
  /* Truncate text for mobile */
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
`;

const CardPrice = styled.div`
  font-family: ${props => props.theme.typography.fontFamily.primary};
  font-size: ${props => props.theme.typography.fontSize.sm};
  font-weight: ${props => props.theme.typography.fontWeight.medium};
  color: ${props => props.theme.colors.secondary.main};
  letter-spacing: -0.01em;
`;

const SelectionIndicator = styled.div.withConfig({
  shouldForwardProp: (prop) => prop !== 'isSelected',
})<{ isSelected: boolean }>`
  position: absolute;
  top: ${props => props.theme.spacing.md};
  right: ${props => props.theme.spacing.md};
  width: 24px;
  height: 24px;
  border-radius: ${props => props.theme.borderRadius.round};
  background: ${props => 
    props.isSelected 
      ? props.theme.colors.secondary.main 
      : 'rgba(255, 255, 255, 0.3)'
  };
  border: 2px solid ${props => 
    props.isSelected 
      ? props.theme.colors.secondary.main 
      : 'rgba(255, 255, 255, 0.5)'
  };
  display: flex;
  align-items: center;
  justify-content: center;
  transition: ${props => props.theme.transitions.fast};
  
  &::after {
    content: '✓';
    color: ${props => props.theme.colors.background.primary};
    font-size: 12px;
    font-weight: ${props => props.theme.typography.fontWeight.bold};
    opacity: ${props => props.isSelected ? 1 : 0};
    transition: ${props => props.theme.transitions.fast};
  }
`;

export const RoomCard: React.FC<RoomCardProps> = ({ 
  room, 
  isSelected = false, 
  onClick 
}) => {
  const handleClick = () => {
    onClick(room);
  };

  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onClick(room);
    }
  };

  return (
    <CardContainer
      isSelected={isSelected}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
      tabIndex={0}
      role="button"
      aria-label={`Seleccionar ${room.name}`}
      aria-pressed={isSelected}
    >
      <CardImage
        src={room.thumbnail_image}
        alt={room.name}
        loading="lazy"
      />
      
      <SelectionIndicator isSelected={isSelected} />
      
      <CardOverlay>
        <CardTitle>{room.name}</CardTitle>
        <CardDescription>{room.short_description}</CardDescription>
        <CardPrice>Desde ${room.base_price}</CardPrice>
      </CardOverlay>
    </CardContainer>
  );
};