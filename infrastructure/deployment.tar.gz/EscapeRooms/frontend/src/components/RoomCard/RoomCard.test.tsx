import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { theme } from '../../styles/theme';
import { RoomCard } from './RoomCard';
import { Room } from '../../contexts/RoomContext';

const mockRoom: Room = {
  id: 1,
  name: 'La Inquisición',
  slug: 'la-inquisicion',
  short_description: 'Una experiencia medieval llena de misterios y desafíos que te transportará a la época más oscura de la historia.',
  full_description: 'Descripción completa del room...',
  hero_image: '/images/inquisicion-hero.jpg',
  thumbnail_image: '/images/inquisicion-thumb.jpg',
  base_price: 30,
  is_active: true,
};

const renderWithTheme = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('RoomCard', () => {
  const mockOnClick = jest.fn();

  beforeEach(() => {
    mockOnClick.mockClear();
  });

  it('renders room information correctly', () => {
    renderWithTheme(
      <RoomCard room={mockRoom} onClick={mockOnClick} />
    );

    expect(screen.getByText('La Inquisición')).toBeInTheDocument();
    expect(screen.getByText(/Una experiencia medieval/)).toBeInTheDocument();
    expect(screen.getByText('Desde $30')).toBeInTheDocument();
    
    const image = screen.getByAltText('La Inquisición');
    expect(image).toBeInTheDocument();
    expect(image).toHaveAttribute('src', '/images/inquisicion-thumb.jpg');
  });

  it('shows selection state correctly', () => {
    const { rerender } = renderWithTheme(
      <RoomCard room={mockRoom} isSelected={false} onClick={mockOnClick} />
    );

    const card = screen.getByRole('button');
    expect(card).toHaveAttribute('aria-pressed', 'false');

    rerender(
      <ThemeProvider theme={theme}>
        <RoomCard room={mockRoom} isSelected={true} onClick={mockOnClick} />
      </ThemeProvider>
    );

    expect(card).toHaveAttribute('aria-pressed', 'true');
  });

  it('calls onClick when clicked', () => {
    renderWithTheme(
      <RoomCard room={mockRoom} onClick={mockOnClick} />
    );

    const card = screen.getByRole('button');
    fireEvent.click(card);

    expect(mockOnClick).toHaveBeenCalledTimes(1);
    expect(mockOnClick).toHaveBeenCalledWith(mockRoom);
  });

  it('calls onClick when Enter key is pressed', () => {
    renderWithTheme(
      <RoomCard room={mockRoom} onClick={mockOnClick} />
    );

    const card = screen.getByRole('button');
    fireEvent.keyDown(card, { key: 'Enter' });

    expect(mockOnClick).toHaveBeenCalledTimes(1);
    expect(mockOnClick).toHaveBeenCalledWith(mockRoom);
  });

  it('calls onClick when Space key is pressed', () => {
    renderWithTheme(
      <RoomCard room={mockRoom} onClick={mockOnClick} />
    );

    const card = screen.getByRole('button');
    fireEvent.keyDown(card, { key: ' ' });

    expect(mockOnClick).toHaveBeenCalledTimes(1);
    expect(mockOnClick).toHaveBeenCalledWith(mockRoom);
  });

  it('does not call onClick for other keys', () => {
    renderWithTheme(
      <RoomCard room={mockRoom} onClick={mockOnClick} />
    );

    const card = screen.getByRole('button');
    fireEvent.keyDown(card, { key: 'Tab' });
    fireEvent.keyDown(card, { key: 'Escape' });

    expect(mockOnClick).not.toHaveBeenCalled();
  });

  it('has proper accessibility attributes', () => {
    renderWithTheme(
      <RoomCard room={mockRoom} isSelected={true} onClick={mockOnClick} />
    );

    const card = screen.getByRole('button');
    expect(card).toHaveAttribute('aria-label', 'Seleccionar La Inquisición');
    expect(card).toHaveAttribute('aria-pressed', 'true');
    expect(card).toHaveAttribute('tabIndex', '0');
  });

  it('handles image loading with lazy loading', () => {
    renderWithTheme(
      <RoomCard room={mockRoom} onClick={mockOnClick} />
    );

    const image = screen.getByAltText('La Inquisición');
    expect(image).toHaveAttribute('loading', 'lazy');
  });

  it('truncates long descriptions appropriately', () => {
    const roomWithLongDescription: Room = {
      ...mockRoom,
      short_description: 'Esta es una descripción muy larga que debería ser truncada en el componente para mantener un diseño consistente y evitar que el texto se desborde en las tarjetas de los escape rooms.',
    };

    renderWithTheme(
      <RoomCard room={roomWithLongDescription} onClick={mockOnClick} />
    );

    // The text should be present but truncated via CSS
    expect(screen.getByText(/Esta es una descripción muy larga/)).toBeInTheDocument();
  });

  it('formats price correctly', () => {
    const roomWithDifferentPrice: Room = {
      ...mockRoom,
      base_price: 45,
    };

    renderWithTheme(
      <RoomCard room={roomWithDifferentPrice} onClick={mockOnClick} />
    );

    expect(screen.getByText('Desde $45')).toBeInTheDocument();
  });
});