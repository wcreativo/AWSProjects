import React from 'react';
import styled from 'styled-components';
import { RoomCard } from '../RoomCard';
import { useRoom } from '../../contexts/RoomContext';
import { Loading } from '../common/Loading';

const SectionContainer = styled.section`
  padding: ${props => props.theme.spacing.xl} 0;
  background: ${props => props.theme.colors.background.primary};
`;

const SectionHeader = styled.div`
  padding: 0 ${props => props.theme.spacing.md};
  margin-bottom: ${props => props.theme.spacing.lg};
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    padding: 0 ${props => props.theme.spacing.xl};
  }
`;

const SectionTitle = styled.h2`
  font-family: ${props => props.theme.typography.fontFamily.heading};
  font-size: 2.5rem;
  font-weight: 400;
  color: #c3865b;
  margin: 0 0 ${props => props.theme.spacing.sm} 0;
  line-height: 1.2;
  text-transform: uppercase;
  letter-spacing: 0.02em;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    font-size: 3rem;
  }
`;

const SectionSubtitle = styled.p`
  font-family: ${props => props.theme.typography.fontFamily.primary};
  font-size: ${props => props.theme.typography.fontSize.md};
  font-weight: 400;
  color: ${props => props.theme.colors.text.secondary};
  margin: 0;
  line-height: 1.6;
  letter-spacing: -0.01em;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    font-size: ${props => props.theme.typography.fontSize.lg};
  }
`;

const CardsContainer = styled.div`
  /* Mobile: horizontal scroll */
  display: flex;
  gap: ${props => props.theme.spacing.md};
  padding: 0 ${props => props.theme.spacing.md};
  overflow-x: auto;
  scroll-behavior: smooth;
  
  /* Hide scrollbar but keep functionality */
  scrollbar-width: none;
  -ms-overflow-style: none;
  &::-webkit-scrollbar {
    display: none;
  }
  
  /* Tablet: still horizontal scroll but with more padding */
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    padding: 0 ${props => props.theme.spacing.xl};
    gap: ${props => props.theme.spacing.lg};
  }
  
  /* Desktop: grid layout */
  @media (min-width: ${props => props.theme.breakpoints.desktop}) {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: ${props => props.theme.spacing.lg};
    overflow-x: visible;
    padding: 0 ${props => props.theme.spacing.xl};
    max-width: 1200px;
    margin: 0 auto;
  }
`;

const EmptyState = styled.div`
  text-align: center;
  padding: ${props => props.theme.spacing.xxl};
  color: ${props => props.theme.colors.text.secondary};
  
  h3 {
    font-size: ${props => props.theme.typography.fontSize.lg};
    margin-bottom: ${props => props.theme.spacing.md};
    color: ${props => props.theme.colors.text.primary};
  }
  
  p {
    font-size: ${props => props.theme.typography.fontSize.md};
    line-height: ${props => props.theme.typography.lineHeight.normal};
  }
`;

const ErrorState = styled(EmptyState)`
  color: ${props => props.theme.colors.error};
  
  h3 {
    color: ${props => props.theme.colors.error};
  }
`;

export const RoomCardsSection: React.FC = () => {
  const { state, setActiveRoom } = useRoom();
  const { rooms, activeRoom, loading, error } = state;

  const handleRoomSelect = (room: typeof activeRoom) => {
    if (room) {
      setActiveRoom(room);
    }
  };

  if (loading) {
    return (
      <SectionContainer>
        <SectionHeader>
          <SectionTitle>Nuestros Escape Rooms</SectionTitle>
          <SectionSubtitle>Descubre todas nuestras experiencias disponibles</SectionSubtitle>
        </SectionHeader>
        <Loading text="Cargando escape rooms..." />
      </SectionContainer>
    );
  }

  if (error) {
    return (
      <SectionContainer>
        <SectionHeader>
          <SectionTitle>Nuestros Escape Rooms</SectionTitle>
          <SectionSubtitle>Descubre todas nuestras experiencias disponibles</SectionSubtitle>
        </SectionHeader>
        <ErrorState>
          <h3>Error al cargar los escape rooms</h3>
          <p>{error}</p>
        </ErrorState>
      </SectionContainer>
    );
  }

  if (rooms.length === 0) {
    return (
      <SectionContainer>
        <SectionHeader>
          <SectionTitle>Nuestros Escape Rooms</SectionTitle>
          <SectionSubtitle>Descubre todas nuestras experiencias disponibles</SectionSubtitle>
        </SectionHeader>
        <EmptyState>
          <h3>No hay escape rooms disponibles</h3>
          <p>Actualmente no tenemos escape rooms activos. Vuelve pronto para nuevas experiencias.</p>
        </EmptyState>
      </SectionContainer>
    );
  }

  return (
    <SectionContainer>
      <SectionHeader>
        <SectionTitle>Nuestros Escape Rooms</SectionTitle>
        <SectionSubtitle>
          Selecciona un escape room para ver más detalles y hacer tu reserva
        </SectionSubtitle>
      </SectionHeader>
      
      <CardsContainer>
        {rooms.map((room) => (
          <RoomCard
            key={room.id}
            room={room}
            isSelected={activeRoom?.id === room.id}
            onClick={handleRoomSelect}
          />
        ))}
      </CardsContainer>
    </SectionContainer>
  );
};