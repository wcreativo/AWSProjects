import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { theme } from '../../styles/theme';
import { RoomCardsSection } from './RoomCardsSection';
import { RoomProvider, Room } from '../../contexts/RoomContext';

const mockRooms: Room[] = [
  {
    id: 1,
    name: 'La Inquisición',
    slug: 'la-inquisicion',
    short_description: 'Una experiencia medieval llena de misterios.',
    full_description: 'Descripción completa...',
    hero_image: '/images/inquisicion-hero.jpg',
    thumbnail_image: '/images/inquisicion-thumb.jpg',
    base_price: 30,
    is_active: true,
  },
  {
    id: 2,
    name: 'El Purgatorio',
    slug: 'el-purgatorio',
    short_description: 'Un viaje sobrenatural entre la vida y la muerte.',
    full_description: 'Descripción completa...',
    hero_image: '/images/purgatorio-hero.jpg',
    thumbnail_image: '/images/purgatorio-thumb.jpg',
    base_price: 30,
    is_active: true,
  },
  {
    id: 3,
    name: 'La Mansión Abandonada',
    slug: 'la-mansion-abandonada',
    short_description: 'Explora los secretos ocultos de una mansión victoriana.',
    full_description: 'Descripción completa...',
    hero_image: '/images/mansion-hero.jpg',
    thumbnail_image: '/images/mansion-thumb.jpg',
    base_price: 30,
    is_active: true,
  },
];

// Mock the useRoom hook
const mockSetActiveRoom = jest.fn();
const mockUseRoom = {
  state: {
    rooms: mockRooms,
    activeRoom: mockRooms[0] as Room | null,
    loading: false,
    error: null as string | null,
  },
  setActiveRoom: mockSetActiveRoom,
  setRooms: jest.fn(),
  setLoading: jest.fn(),
  setError: jest.fn(),
};

jest.mock('../../contexts/RoomContext', () => ({
  ...jest.requireActual('../../contexts/RoomContext'),
  useRoom: () => mockUseRoom,
}));

const renderWithProviders = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      <RoomProvider>
        {component}
      </RoomProvider>
    </ThemeProvider>
  );
};

describe('RoomCardsSection', () => {
  beforeEach(() => {
    mockSetActiveRoom.mockClear();
    // Reset mock state
    mockUseRoom.state = {
      rooms: mockRooms,
      activeRoom: mockRooms[0] as Room | null,
      loading: false,
      error: null as string | null,
    };
  });

  it('renders section header correctly', () => {
    renderWithProviders(<RoomCardsSection />);

    expect(screen.getByText('Nuestros Escape Rooms')).toBeInTheDocument();
    expect(screen.getByText(/Selecciona un escape room para ver más detalles/)).toBeInTheDocument();
  });

  it('renders all room cards', () => {
    renderWithProviders(<RoomCardsSection />);

    expect(screen.getByText('La Inquisición')).toBeInTheDocument();
    expect(screen.getByText('El Purgatorio')).toBeInTheDocument();
    expect(screen.getByText('La Mansión Abandonada')).toBeInTheDocument();
  });

  it('shows selected state for active room', () => {
    renderWithProviders(<RoomCardsSection />);

    const firstCard = screen.getByLabelText('Seleccionar La Inquisición');
    expect(firstCard).toHaveAttribute('aria-pressed', 'true');

    const secondCard = screen.getByLabelText('Seleccionar El Purgatorio');
    expect(secondCard).toHaveAttribute('aria-pressed', 'false');
  });

  it('calls setActiveRoom when a card is clicked', () => {
    renderWithProviders(<RoomCardsSection />);

    const secondCard = screen.getByLabelText('Seleccionar El Purgatorio');
    fireEvent.click(secondCard);

    expect(mockSetActiveRoom).toHaveBeenCalledTimes(1);
    expect(mockSetActiveRoom).toHaveBeenCalledWith(mockRooms[1]);
  });

  it('shows loading state', () => {
    mockUseRoom.state = {
      ...mockUseRoom.state,
      loading: true,
    };

    renderWithProviders(<RoomCardsSection />);

    expect(screen.getByText('Cargando escape rooms...')).toBeInTheDocument();
    expect(screen.getByText('Nuestros Escape Rooms')).toBeInTheDocument();
  });

  it('shows error state', () => {
    mockUseRoom.state = {
      ...mockUseRoom.state,
      loading: false,
      error: 'Error al conectar con el servidor' as string | null,
    };

    renderWithProviders(<RoomCardsSection />);

    expect(screen.getByText('Error al cargar los escape rooms')).toBeInTheDocument();
    expect(screen.getByText('Error al conectar con el servidor')).toBeInTheDocument();
  });

  it('shows empty state when no rooms available', () => {
    mockUseRoom.state = {
      ...mockUseRoom.state,
      rooms: [],
      activeRoom: null as Room | null,
    };

    renderWithProviders(<RoomCardsSection />);

    expect(screen.getByText('No hay escape rooms disponibles')).toBeInTheDocument();
    expect(screen.getByText(/Actualmente no tenemos escape rooms activos/)).toBeInTheDocument();
  });

  it('handles keyboard navigation on cards', () => {
    renderWithProviders(<RoomCardsSection />);

    const secondCard = screen.getByLabelText('Seleccionar El Purgatorio');
    fireEvent.keyDown(secondCard, { key: 'Enter' });

    expect(mockSetActiveRoom).toHaveBeenCalledTimes(1);
    expect(mockSetActiveRoom).toHaveBeenCalledWith(mockRooms[1]);
  });

  it('renders cards in correct order', () => {
    renderWithProviders(<RoomCardsSection />);

    const cards = screen.getAllByRole('button');
    expect(cards).toHaveLength(3);
    
    // Check that cards are in the expected order
    expect(cards[0]).toHaveAttribute('aria-label', 'Seleccionar La Inquisición');
    expect(cards[1]).toHaveAttribute('aria-label', 'Seleccionar El Purgatorio');
    expect(cards[2]).toHaveAttribute('aria-label', 'Seleccionar La Mansión Abandonada');
  });

  it('maintains selection state after re-render', () => {
    const { rerender } = renderWithProviders(<RoomCardsSection />);

    // Change active room
    mockUseRoom.state = {
      ...mockUseRoom.state,
      activeRoom: mockRooms[1],
    };

    rerender(
      <ThemeProvider theme={theme}>
        <RoomProvider>
          <RoomCardsSection />
        </RoomProvider>
      </ThemeProvider>
    );

    const firstCard = screen.getByLabelText('Seleccionar La Inquisición');
    const secondCard = screen.getByLabelText('Seleccionar El Purgatorio');

    expect(firstCard).toHaveAttribute('aria-pressed', 'false');
    expect(secondCard).toHaveAttribute('aria-pressed', 'true');
  });
});