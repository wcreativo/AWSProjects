import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { theme } from '../styles/theme';
import { HomePage } from './HomePage';
import { RoomProvider, Room } from '../contexts/RoomContext';
import { ReservationProvider } from '../contexts/ReservationContext';
import { ToastProvider } from '../contexts/ToastContext';

const mockRooms: Room[] = [
  {
    id: 1,
    name: 'La Inquisición',
    slug: 'la-inquisicion',
    short_description: 'Una experiencia medieval llena de misterios.',
    full_description: 'Descripción completa de La Inquisición...',
    hero_image: '/images/inquisicion-hero.jpg',
    thumbnail_image: '/images/inquisicion-thumb.jpg',
    base_price: 30,
    is_active: true,
  },
  {
    id: 2,
    name: 'El Purgatorio',
    slug: 'el-purgatorio',
    short_description: 'Un viaje sobrenatural entre la vida y la muerte.',
    full_description: 'Descripción completa de El Purgatorio...',
    hero_image: '/images/purgatorio-hero.jpg',
    thumbnail_image: '/images/purgatorio-thumb.jpg',
    base_price: 30,
    is_active: true,
  },
];

// Mock the useRooms hook
const mockUseRooms = jest.fn();
jest.mock('../hooks/useRooms', () => ({
  useRooms: () => mockUseRooms(),
}));

// Mock the useRoom hook to provide test data
const mockSetActiveRoom = jest.fn();
const mockUseRoom = {
  state: {
    rooms: mockRooms,
    activeRoom: mockRooms[0] as Room | null,
    loading: false,
    error: null as string | null,
  },
  setActiveRoom: mockSetActiveRoom,
  setRooms: jest.fn(),
  setLoading: jest.fn(),
  setError: jest.fn(),
};

jest.mock('../contexts/RoomContext', () => ({
  ...jest.requireActual('../contexts/RoomContext'),
  useRoom: () => mockUseRoom,
}));

const renderWithProviders = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      <ToastProvider>
        <RoomProvider>
          <ReservationProvider>
            {component}
          </ReservationProvider>
        </RoomProvider>
      </ToastProvider>
    </ThemeProvider>
  );
};

describe('Room Cards and Hero Integration Tests', () => {
  beforeEach(() => {
    mockUseRooms.mockClear();
    mockSetActiveRoom.mockClear();
    // Reset mock state
    mockUseRoom.state = {
      rooms: mockRooms,
      activeRoom: mockRooms[0] as Room | null,
      loading: false,
      error: null as string | null,
    };
  });

  it('renders HomePage with hero section', () => {
    renderWithProviders(<HomePage />);

    // Check that main sections are present
    expect(screen.getByRole('main')).toBeInTheDocument();
    
    // Hero section should be present
    expect(screen.getByText(/Reservar/)).toBeInTheDocument();
    expect(screen.getByText(/Detalle/)).toBeInTheDocument();
    
    // Contact section should be present
    expect(screen.getByText('Contacto')).toBeInTheDocument();
  });

  it('displays hero section with initial active room', () => {
    renderWithProviders(<HomePage />);

    // Hero should show the first room (active room)
    expect(screen.getAllByText('La Inquisición').length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText(/Una experiencia medieval/).length).toBeGreaterThanOrEqual(1);

    // Navigation controls should be present for multiple rooms
    expect(screen.getByLabelText('Sala anterior')).toBeInTheDocument();
    expect(screen.getByLabelText('Siguiente sala')).toBeInTheDocument();
  });

  it('updates hero when navigation buttons are used', async () => {
    renderWithProviders(<HomePage />);

    // Initially, first room should be active
    expect(screen.getAllByText('La Inquisición').length).toBeGreaterThanOrEqual(1);

    // Click next button to go to second room
    const nextButton = screen.getByLabelText('Siguiente sala');
    fireEvent.click(nextButton);

    // Verify that setActiveRoom was called with the correct room
    expect(mockSetActiveRoom).toHaveBeenCalledTimes(1);
    expect(mockSetActiveRoom).toHaveBeenCalledWith(mockRooms[1]);
  });

  it('maintains active room state in hero navigation', () => {
    // Start with second room as active
    mockUseRoom.state = {
      ...mockUseRoom.state,
      activeRoom: mockRooms[1],
    };

    renderWithProviders(<HomePage />);

    // Hero should show the second room
    expect(screen.getAllByText('El Purgatorio').length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText(/Un viaje sobrenatural/).length).toBeGreaterThanOrEqual(1);
  });

  it('handles navigation for hero controls', () => {
    renderWithProviders(<HomePage />);

    const nextButton = screen.getByLabelText('Siguiente sala');
    const prevButton = screen.getByLabelText('Sala anterior');

    // Use click to navigate
    fireEvent.click(nextButton);
    expect(mockSetActiveRoom).toHaveBeenCalledTimes(1);
    expect(mockSetActiveRoom).toHaveBeenCalledWith(mockRooms[1]);

    // Test previous button
    mockSetActiveRoom.mockClear();
    fireEvent.click(prevButton);
    expect(mockSetActiveRoom).toHaveBeenCalledTimes(1);
  });

  it('handles modal state changes from hero buttons', () => {
    renderWithProviders(<HomePage />);

    const reserveButton = screen.getByText(/Reservar/);
    const detailButton = screen.getByText(/Detalle/);

    // Test reserve button
    fireEvent.click(reserveButton);
    // In development mode, we should see debug info
    if (process.env.NODE_ENV === 'development') {
      expect(screen.getByText(/Reservation Modal: Abierto/)).toBeInTheDocument();
    }

    // Test detail button
    fireEvent.click(detailButton);
    if (process.env.NODE_ENV === 'development') {
      expect(screen.getByText(/Detail Modal: Abierto/)).toBeInTheDocument();
    }
  });

  it('shows loading state in hero section', () => {
    mockUseRoom.state = {
      ...mockUseRoom.state,
      loading: true,
    };

    renderWithProviders(<HomePage />);

    // Hero should show loading
    expect(screen.getByText('Cargando escape rooms...')).toBeInTheDocument();
    
    // Hero buttons should NOT be present during loading
    expect(screen.queryByText(/Reservar/)).not.toBeInTheDocument();
    expect(screen.queryByText(/Detalle/)).not.toBeInTheDocument();
  });

  it('shows error state in hero section', () => {
    mockUseRoom.state = {
      ...mockUseRoom.state,
      loading: false,
      error: 'Error de conexión' as string | null,
    };

    renderWithProviders(<HomePage />);

    expect(screen.getByText('Error al cargar')).toBeInTheDocument();
    expect(screen.getByText('No se pudieron cargar los escape rooms. Por favor, intenta nuevamente.')).toBeInTheDocument();
  });

  it('handles empty rooms state gracefully', () => {
    mockUseRoom.state = {
      ...mockUseRoom.state,
      rooms: [],
      activeRoom: null as Room | null,
    };

    renderWithProviders(<HomePage />);

    // Hero section will show empty state
    expect(screen.getByText('No hay escape rooms disponibles')).toBeInTheDocument();
    expect(screen.getByText('Actualmente no hay escape rooms disponibles para reservar.')).toBeInTheDocument();
  });

  it('initializes rooms data on mount', () => {
    renderWithProviders(<HomePage />);
    
    expect(mockUseRooms).toHaveBeenCalledTimes(1);
  });

  it('handles multiple rapid navigation clicks correctly', () => {
    renderWithProviders(<HomePage />);

    const nextButton = screen.getByLabelText('Siguiente sala');
    const prevButton = screen.getByLabelText('Sala anterior');

    // Rapidly click navigation buttons
    fireEvent.click(nextButton);
    fireEvent.click(prevButton);
    fireEvent.click(nextButton);

    // Should have been called 3 times
    expect(mockSetActiveRoom).toHaveBeenCalledTimes(3);
    expect(mockSetActiveRoom).toHaveBeenNthCalledWith(1, mockRooms[1]);
    expect(mockSetActiveRoom).toHaveBeenNthCalledWith(2, mockRooms[1]); // Previous from index 1 wraps to last (index 1)
    expect(mockSetActiveRoom).toHaveBeenNthCalledWith(3, mockRooms[1]); // Next from index 0 goes to index 1
  });

  it('maintains accessibility features in hero navigation', () => {
    renderWithProviders(<HomePage />);

    // Check that navigation buttons have proper accessibility attributes
    const nextButton = screen.getByLabelText('Siguiente sala');
    const prevButton = screen.getByLabelText('Sala anterior');
    
    expect(nextButton).toBeInTheDocument();
    expect(prevButton).toBeInTheDocument();

    // Check that hero buttons are accessible
    const reserveButton = screen.getByText('Reservar');
    const detailButton = screen.getByText('Detalle');
    
    expect(reserveButton).toBeInTheDocument();
    expect(detailButton).toBeInTheDocument();

    // Check room indicators
    const indicators = screen.getAllByLabelText(/Ir a/);
    expect(indicators.length).toBe(2); // Should have 2 room indicators
  });
});