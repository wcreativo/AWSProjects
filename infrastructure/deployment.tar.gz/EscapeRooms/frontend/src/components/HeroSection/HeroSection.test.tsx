import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { HeroSection } from './HeroSection';
import { RoomProvider } from '../../contexts/RoomContext';
import { theme } from '../../styles/theme';

// Mock room data
const mockRoom = {
  id: 1,
  name: 'La Inquisición',
  slug: 'la-inquisicion',
  short_description: 'Una experiencia medieval llena de misterios y desafíos.',
  full_description: 'Descripción completa del escape room...',
  hero_image: '/images/inquisicion-hero.jpg',
  thumbnail_image: '/images/inquisicion-thumb.jpg',
  video_url: '/videos/inquisicion_audio.mp4',
  base_price: 30,
  is_active: true,
};

const mockRoomWithoutVideo = {
  id: 2,
  name: 'El Purgatorio',
  slug: 'el-purgatorio',
  short_description: 'Una experiencia sobrenatural.',
  full_description: 'Descripción completa del escape room...',
  hero_image: '/images/purgatorio-hero.jpg',
  thumbnail_image: '/images/purgatorio-thumb.jpg',
  base_price: 30,
  is_active: true,
};

// Mock the useRoom hook
jest.mock('../../contexts/RoomContext', () => ({
  useRoom: jest.fn(),
}));

const mockUseRoom = require('../../contexts/RoomContext').useRoom as jest.MockedFunction<any>;

const renderWithProviders = (
  component: React.ReactElement,
  mockState?: any
) => {
  const defaultMockState = {
    rooms: [mockRoom],
    activeRoom: mockRoom,
    loading: false,
    error: null,
  };

  mockUseRoom.mockReturnValue({
    state: mockState || defaultMockState,
    setRooms: jest.fn(),
    setActiveRoom: jest.fn(),
    setLoading: jest.fn(),
    setError: jest.fn(),
  });

  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('HeroSection', () => {
  const mockOnReserveClick = jest.fn();
  const mockOnDetailClick = jest.fn();
  const mockOnVideoClick = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders hero section with room information', () => {
    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />
    );

    expect(screen.getByText('La Inquisición')).toBeInTheDocument();
    expect(screen.getByText('Una experiencia medieval llena de misterios y desafíos.')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Reservar' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Detalle' })).toBeInTheDocument();
  });

  it('displays loading state', () => {
    const loadingState = {
      rooms: [],
      activeRoom: null,
      loading: true,
      error: null,
    };

    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />,
      loadingState
    );

    expect(screen.getByText('Cargando escape rooms...')).toBeInTheDocument();
  });

  it('displays error state', () => {
    const errorState = {
      rooms: [],
      activeRoom: null,
      loading: false,
      error: 'Error loading rooms',
    };

    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />,
      errorState
    );

    expect(screen.getByText('Error al cargar')).toBeInTheDocument();
    expect(screen.getByText('No se pudieron cargar los escape rooms. Por favor, intenta nuevamente.')).toBeInTheDocument();
  });

  it('displays no rooms available state', () => {
    const noRoomsState = {
      rooms: [],
      activeRoom: null,
      loading: false,
      error: null,
    };

    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />,
      noRoomsState
    );

    expect(screen.getByText('No hay escape rooms disponibles')).toBeInTheDocument();
    expect(screen.getByText('Actualmente no hay escape rooms disponibles para reservar.')).toBeInTheDocument();
  });

  it('calls onReserveClick when Reserve button is clicked', () => {
    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />
    );

    const reserveButton = screen.getByRole('button', { name: 'Reservar' });
    fireEvent.click(reserveButton);

    expect(mockOnReserveClick).toHaveBeenCalledTimes(1);
  });

  it('calls onDetailClick when Detail button is clicked', () => {
    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />
    );

    const detailButton = screen.getByRole('button', { name: 'Detalle' });
    fireEvent.click(detailButton);

    expect(mockOnDetailClick).toHaveBeenCalledTimes(1);
  });

  it('renders hero image with correct attributes', () => {
    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />
    );

    const heroImage = screen.getByAltText('La Inquisición');
    expect(heroImage).toHaveAttribute('src', '/images/inquisicion-hero.jpg');
    expect(heroImage).toHaveAttribute('loading', 'lazy');
  });

  it('shows loading indicator while image is loading', async () => {
    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />
    );

    // Initially should show image loading
    expect(screen.getByText('Cargando imagen...')).toBeInTheDocument();

    // Simulate image load
    const heroImage = screen.getByAltText('La Inquisición');
    fireEvent.load(heroImage);

    // Loading indicator should disappear
    await waitFor(() => {
      expect(screen.queryByText('Cargando imagen...')).not.toBeInTheDocument();
    });
  });

  it('handles image error gracefully', async () => {
    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />
    );

    const heroImage = screen.getByAltText('La Inquisición');
    fireEvent.error(heroImage);

    // Loading indicator should disappear
    await waitFor(() => {
      expect(screen.queryByText('Cargando imagen...')).not.toBeInTheDocument();
    });

    // Content should still be visible
    expect(screen.getByText('La Inquisición')).toBeInTheDocument();
  });

  it('has proper accessibility attributes', () => {
    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />
    );

    const reserveButton = screen.getByRole('button', { name: 'Reservar' });
    const detailButton = screen.getByRole('button', { name: 'Detalle' });

    expect(reserveButton).toBeInTheDocument();
    expect(detailButton).toBeInTheDocument();
    
    // Check that buttons are properly sized for touch targets
    expect(reserveButton).toHaveStyle('min-height: 32px'); // default size
    expect(detailButton).toHaveStyle('min-height: 32px'); // default size
  });

  it('shows video button when room has video_url', () => {
    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />
    );

    expect(screen.getByRole('button', { name: 'Ver Video' })).toBeInTheDocument();
  });

  it('does not show video button when room has no video_url', () => {
    const stateWithoutVideo = {
      rooms: [mockRoomWithoutVideo],
      activeRoom: mockRoomWithoutVideo,
      loading: false,
      error: null,
    };

    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />,
      stateWithoutVideo
    );

    expect(screen.queryByRole('button', { name: 'Ver Video' })).not.toBeInTheDocument();
  });

  it('calls onVideoClick when Video button is clicked', () => {
    renderWithProviders(
      <HeroSection
        onReserveClick={mockOnReserveClick}
        onDetailClick={mockOnDetailClick}
        onVideoClick={mockOnVideoClick}
      />
    );

    const videoButton = screen.getByRole('button', { name: 'Ver Video' });
    fireEvent.click(videoButton);

    expect(mockOnVideoClick).toHaveBeenCalledTimes(1);
  });
});