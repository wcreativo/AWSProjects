import React, { useState, useRef, useCallback, useEffect } from 'react';
import styled from 'styled-components';
import { Room } from '../../contexts/RoomContext';
import { Button } from '../common/Button';

interface TinderCardsProps {
  rooms: Room[];
  activeRoom: Room;
  onRoomChange: (room: Room) => void;
  onReserveClick: () => void;
  onDetailClick: () => void;
  onVideoClick: () => void;
}

const CardsContainer = styled.div`
  position: relative;
  width: 100%;
  height: 100vh;
  overflow: hidden;
  touch-action: pan-y;
  padding: ${props => props.theme.spacing.lg};
  padding-top: 80px; /* Space for header in mobile */
  display: flex;
  flex-direction: column;
`;

const SwipeArea = styled.div`
  position: relative;
  flex: 1;
  margin-bottom: ${props => props.theme.spacing.xs};
  min-height: 70vh; /* Make cards taller */
`;

const Card = styled.div<{
  $index: number;
  $isDragging: boolean;
  $dragX: number;
  $isActive: boolean;
}>`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border-radius: 20px;
  overflow: hidden;
  cursor: grab;
  user-select: none;
  will-change: transform;
  background: ${props => props.theme.colors.background.secondary};
  
  transform: ${props => {
    if (props.$isActive && props.$isDragging) {
      const rotation = Math.max(-8, Math.min(8, props.$dragX * 0.03));
      return `translateX(${props.$dragX}px) rotate(${rotation}deg)`;
    }
    if (props.$isActive) {
      return 'translateX(0) scale(1) rotate(0deg)';
    }
    // Cards behind the active one with subtle stacking effect
    const offset = props.$index * 12; // More horizontal offset to the right
    const scale = 1 - (props.$index * 0.02);
    return `translateX(${offset}px) scale(${scale}) translateZ(0)`;
  }};
  
  transition: ${props => props.$isDragging ? 'none' : 'all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)'};
  z-index: ${props => 10 - props.$index};
  opacity: ${props => props.$index > 2 ? 0 : 1 - (props.$index * 0.1)};
  
  &:active {
    cursor: grabbing;
  }
  
  /* Modern card shadow with subtle red glow */
  box-shadow: ${props => props.$isActive ?
    '0 20px 40px rgba(0, 0, 0, 0.15), 0 8px 16px rgba(0, 0, 0, 0.1), 0 0 20px rgba(227, 40, 39, 0.3)' :
    `0 ${8 + props.$index * 2}px ${20 + props.$index * 4}px rgba(0, 0, 0, 0.1), 0 0 15px rgba(227, 40, 39, 0.2)`
  };
`;

const CardImage = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
  border-radius: 20px;
`;

const CardImageOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(
    to top,
    rgba(0, 0, 0, 0.8) 0%,
    rgba(0, 0, 0, 0.4) 50%,
    rgba(0, 0, 0, 0.1) 100%
  );
  border-radius: 20px;
`;

const CardContent = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: ${props => props.theme.spacing.xl};
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  z-index: 3;
`;

const CardTitle = styled.h2`
  font-family: ${props => props.theme.typography.fontFamily.heading};
  font-size: 2.2rem;
  font-weight: 700;
  color: #c3865b;
  margin: 0 0 ${props => props.theme.spacing.sm} 0;
  line-height: 1.1;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  text-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
`;

const CardDescription = styled.p`
  font-family: ${props => props.theme.typography.fontFamily.primary};
  font-size: ${props => props.theme.typography.fontSize.md};
  font-weight: 400;
  color: ${props => props.theme.colors.text.primary};
  margin: 0;
  line-height: 1.5;
  letter-spacing: -0.01em;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-shadow: 0 1px 4px rgba(0, 0, 0, 0.7);
`;

const ButtonsContainer = styled.div`
  padding: ${props => props.theme.spacing.lg};
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.sm};
  background: ${props => props.theme.colors.background.primary};
`;


const DotsIndicator = styled.div`
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: ${props => props.theme.spacing.sm};
  z-index: 4;
  background: rgba(0, 0, 0, 0.3);
  padding: ${props => props.theme.spacing.sm} ${props => props.theme.spacing.md};
  border-radius: 25px;
  backdrop-filter: blur(10px);
`;

const Dot = styled.div<{ $isActive: boolean }>`
  width: ${props => props.$isActive ? '24px' : '8px'};
  height: 8px;
  border-radius: 4px;
  background: ${props => props.$isActive ?
    'linear-gradient(90deg, #c3865b, #e2a76f)' : 'rgba(255, 255, 255, 0.4)'};
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  cursor: pointer;
  
  &:hover {
    background: ${props => props.$isActive ?
    'linear-gradient(90deg, #c3865b, #e2a76f)' : 'rgba(255, 255, 255, 0.6)'};
  }
`;

export const TinderCards: React.FC<TinderCardsProps> = ({
  rooms,
  activeRoom,
  onRoomChange,
  onReserveClick,
  onDetailClick,
  onVideoClick,
}) => {
  const [dragX, setDragX] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const cardRef = useRef<HTMLDivElement>(null);

  const currentIndex = rooms.findIndex(room => room.id === activeRoom.id);

  // Reorder rooms so active room is first
  const orderedRooms = [
    activeRoom,
    ...rooms.filter(room => room.id !== activeRoom.id)
  ];

  // Pause auto-play on user interaction
  const handleUserInteraction = useCallback(() => {
    setIsAutoPlaying(false);
    // Resume auto-play after 5 seconds of no interaction
    setTimeout(() => {
      setIsAutoPlaying(true);
    }, 5000);
  }, []);

  // Auto-advance to next room
  const handleAutoNext = useCallback(() => {
    const nextIndex = (currentIndex + 1) % rooms.length;
    onRoomChange(rooms[nextIndex]);
  }, [currentIndex, rooms, onRoomChange]);

  // Auto-play functionality
  useEffect(() => {
    if (!isAutoPlaying || rooms.length <= 1 || isDragging) {
      return;
    }

    const interval = setInterval(() => {
      handleAutoNext();
    }, 4000); // Change slide every 4 seconds

    return () => clearInterval(interval);
  }, [isAutoPlaying, rooms.length, isDragging, handleAutoNext]);

  const handleStart = useCallback((clientX: number) => {
    setIsDragging(true);
    setStartX(clientX);
  }, []);

  const handleMove = useCallback((clientX: number) => {
    if (!isDragging) return;

    let deltaX = clientX - startX;

    // Apply rubber band effect for extreme swipes
    const maxSwipe = window.innerWidth * 0.8;
    if (Math.abs(deltaX) > maxSwipe) {
      const excess = Math.abs(deltaX) - maxSwipe;
      const dampening = Math.max(0.1, 1 - (excess / (window.innerWidth * 0.2)));
      deltaX = deltaX > 0 ?
        maxSwipe + (excess * dampening) :
        -maxSwipe - (excess * dampening);
    }

    setDragX(deltaX);
  }, [isDragging, startX]);

  const handleEnd = useCallback(() => {
    if (!isDragging) return;

    setIsDragging(false);

    const threshold = window.innerWidth * 0.25;

    if (Math.abs(dragX) > threshold) {
      // Add haptic feedback if available
      if ('vibrate' in navigator) {
        navigator.vibrate(50);
      }

      // Swipe detected - pause auto-play
      handleUserInteraction();

      const direction = dragX > 0 ? 'right' : 'left';

      if (direction === 'left') {
        // Next room
        const nextIndex = (currentIndex + 1) % rooms.length;
        onRoomChange(rooms[nextIndex]);
      } else {
        // Previous room
        const prevIndex = currentIndex === 0 ? rooms.length - 1 : currentIndex - 1;
        onRoomChange(rooms[prevIndex]);
      }
    }

    setDragX(0);
  }, [isDragging, dragX, currentIndex, rooms, onRoomChange, handleUserInteraction]);

  // Mouse events
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    handleStart(e.clientX);
  }, [handleStart]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    handleMove(e.clientX);
  }, [handleMove]);

  const handleMouseUp = useCallback(() => {
    handleEnd();
  }, [handleEnd]);

  // Touch events
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    handleStart(e.touches[0].clientX);
  }, [handleStart]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    handleMove(e.touches[0].clientX);
  }, [handleMove]);

  const handleTouchEnd = useCallback(() => {
    handleEnd();
  }, [handleEnd]);

  // Global mouse events
  useEffect(() => {
    if (!isDragging) return;

    const handleGlobalMouseMove = (e: MouseEvent) => {
      handleMove(e.clientX);
    };

    const handleGlobalMouseUp = () => {
      handleEnd();
    };

    document.addEventListener('mousemove', handleGlobalMouseMove);
    document.addEventListener('mouseup', handleGlobalMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleGlobalMouseMove);
      document.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [isDragging, handleMove, handleEnd]);

  return (
    <CardsContainer>
      <SwipeArea>
        {orderedRooms.slice(0, 3).map((room, index) => (
          <Card
            key={room.id}
            ref={index === 0 ? cardRef : undefined}
            $index={index}
            $isDragging={isDragging && index === 0}
            $dragX={index === 0 ? dragX : 0}
            $isActive={index === 0}
            onMouseDown={index === 0 ? handleMouseDown : undefined}
            onMouseMove={index === 0 ? handleMouseMove : undefined}
            onMouseUp={index === 0 ? handleMouseUp : undefined}
            onTouchStart={index === 0 ? handleTouchStart : undefined}
            onTouchMove={index === 0 ? handleTouchMove : undefined}
            onTouchEnd={index === 0 ? handleTouchEnd : undefined}
          >
            <CardImage
              src={room.hero_image}
              alt={room.name}
              draggable={false}
            />
            <CardImageOverlay />

            {index === 0 && (
              <CardContent>
                <CardTitle>{room.name}</CardTitle>
                <CardDescription>{room.short_description}</CardDescription>
              </CardContent>
            )}
          </Card>
        ))}

        {/* Dots indicator */}
        <DotsIndicator>
          {rooms.map((room) => (
            <Dot
              key={room.id}
              $isActive={room.id === activeRoom.id}
              onClick={() => {
                onRoomChange(room);
                handleUserInteraction();
              }}
            />
          ))}
        </DotsIndicator>
      </SwipeArea>

      {/* Buttons below swipe area */}
      <ButtonsContainer>
        <Button
          variant="primary"
          onClick={onReserveClick}
        >
          Reservar
        </Button>
        <Button
          variant="secondary"
          onClick={onDetailClick}
        >
          Detalle
        </Button>
        <Button
          variant="secondary"
          onClick={onVideoClick}
        >
          Ver Video
        </Button>
      </ButtonsContainer>
    </CardsContainer>
  );
};