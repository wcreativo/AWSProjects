import React, { useState, useEffect, useCallback, useMemo } from 'react';
import styled from 'styled-components';
import { useRoom } from '../../contexts/RoomContext';
import { Button } from '../common/Button';
import { Loading } from '../common/Loading';
import { TinderCards } from './TinderCards';

interface HeroSectionProps {
  onReserveClick: () => void;
  onDetailClick: () => void;
  onVideoClick: () => void;
}

const HeroContainer = styled.section`
  position: relative;
  height: 100vh;
  min-height: 500px;
  width: 100%;
  overflow: hidden;
  background: ${props => props.theme.colors.background.primary};
  
  /* Mobile: No flex, let TinderCards handle layout */
  @media (max-width: 767px) {
    display: block;
  }
  
  /* Desktop: Original flex layout */
  @media (min-width: 768px) {
    display: flex;
    align-items: flex-end;
    min-height: 600px;
  }
  
  @media (min-width: ${props => props.theme.breakpoints.desktop}) {
    min-height: 700px;
  }
`;

const HeroImage = styled.img<{ $isLoading: boolean }>`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
  transition: opacity ${props => props.theme.transitions.slow};
  opacity: ${props => props.$isLoading ? 0 : 1};
`;

const HeroOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(
    to top,
    rgba(0, 0, 0, 0.8) 0%,
    rgba(0, 0, 0, 0.4) 50%,
    rgba(0, 0, 0, 0.2) 100%
  );
`;

const HeroContent = styled.div`
  position: relative;
  z-index: 2;
  padding: ${props => props.theme.spacing.lg};
  width: 100%;
  max-width: 600px;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    padding: ${props => props.theme.spacing.xl};
    max-width: 700px;
  }
  
  @media (min-width: ${props => props.theme.breakpoints.desktop}) {
    padding: ${props => props.theme.spacing.xxl};
    max-width: 800px;
  }
`;

const HeroTitle = styled.h1`
  font-family: ${props => props.theme.typography.fontFamily.heading};
  font-size: 2.5rem;
  font-weight: 400;
  color: #c3865b;
  margin: 0 0 ${props => props.theme.spacing.md} 0;
  line-height: 1.1;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    font-size: 3.5rem;
  }
  
  @media (min-width: ${props => props.theme.breakpoints.desktop}) {
    font-size: 4.5rem;
  }
`;

const HeroDescription = styled.p`
  font-family: ${props => props.theme.typography.fontFamily.primary};
  font-size: ${props => props.theme.typography.fontSize.md};
  font-weight: 400;
  color: ${props => props.theme.colors.text.secondary};
  margin: 0 0 ${props => props.theme.spacing.xl} 0;
  line-height: 1.6;
  letter-spacing: -0.01em;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    font-size: ${props => props.theme.typography.fontSize.lg};
    margin-bottom: ${props => props.theme.spacing.xxl};
  }
  
  @media (min-width: ${props => props.theme.breakpoints.desktop}) {
    font-size: 1.125rem;
    max-width: 90%;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.sm};
  align-items: flex-start;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    flex-direction: row;
    gap: ${props => props.theme.spacing.md};
    align-items: center;
  }
`;

const LoadingContainer = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 3;
`;

const NavigationContainer = styled.div`
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  transform: translateY(-50%);
  display: flex;
  justify-content: space-between;
  padding: 0 ${props => props.theme.spacing.lg};
  z-index: 4;
  pointer-events: none;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    padding: 0 ${props => props.theme.spacing.xl};
  }
`;

const NavButton = styled.button`
  width: 50px;
  height: 50px;
  border-radius: 50%;
  border: 2px solid rgba(255, 255, 255, 0.3);
  background: rgba(0, 0, 0, 0.5);
  color: white;
  font-size: 1.5rem;
  cursor: pointer;
  transition: all ${props => props.theme.transitions.normal};
  pointer-events: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  backdrop-filter: blur(10px);
  
  &:hover:not(:disabled) {
    background: rgba(0, 0, 0, 0.7);
    border-color: rgba(255, 255, 255, 0.5);
    transform: scale(1.1);
  }
  
  &:disabled {
    opacity: 0.3;
    cursor: not-allowed;
  }
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    width: 60px;
    height: 60px;
    font-size: 1.75rem;
  }
`;

const RoomIndicators = styled.div`
  position: absolute;
  bottom: ${props => props.theme.spacing.xl};
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: ${props => props.theme.spacing.sm};
  z-index: 4;
`;

const Indicator = styled.button<{ $isActive: boolean }>`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: 2px solid rgba(255, 255, 255, 0.5);
  background: ${props => props.$isActive ? 'rgba(255, 255, 255, 0.8)' : 'transparent'};
  cursor: pointer;
  transition: all ${props => props.theme.transitions.normal};
  
  &:hover {
    background: rgba(255, 255, 255, 0.6);
    transform: scale(1.2);
  }
`;

export const HeroSection: React.FC<HeroSectionProps> = ({
  onReserveClick,
  onDetailClick,
  onVideoClick,
}) => {
  const { state, setActiveRoom } = useRoom();
  const { rooms, activeRoom, loading, error } = state;
  const [imageLoading, setImageLoading] = useState(true);
  const [imageError, setImageError] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  // Detect mobile screen size
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 767);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Reset image loading state when active room changes
  useEffect(() => {
    if (activeRoom) {
      setImageLoading(true);
      setImageError(false);
    }
  }, [activeRoom?.id]);

  const currentRoomIndex = useMemo(() =>
    rooms.findIndex(room => room.id === activeRoom?.id),
    [rooms, activeRoom?.id]
  );

  // Pause auto-play on user interaction
  const handleUserInteraction = useCallback(() => {
    setIsAutoPlaying(false);
    // Resume auto-play after 5 seconds of no interaction
    setTimeout(() => {
      setIsAutoPlaying(true);
    }, 5000);
  }, []);

  const handlePrevious = useCallback(() => {
    if (rooms.length > 0) {
      const prevIndex = currentRoomIndex > 0 ? currentRoomIndex - 1 : rooms.length - 1;
      setActiveRoom(rooms[prevIndex]);
      handleUserInteraction();
    }
  }, [rooms, currentRoomIndex, setActiveRoom, handleUserInteraction]);

  const handleNext = useCallback(() => {
    if (rooms.length > 0) {
      const nextIndex = currentRoomIndex < rooms.length - 1 ? currentRoomIndex + 1 : 0;
      setActiveRoom(rooms[nextIndex]);
    }
  }, [rooms, currentRoomIndex, setActiveRoom]);

  // Auto-play functionality
  useEffect(() => {
    if (!isAutoPlaying || rooms.length <= 1 || loading || isMobile) {
      return;
    }

    const interval = setInterval(() => {
      handleNext();
    }, 4000); // Change slide every 4 seconds

    return () => clearInterval(interval);
  }, [isAutoPlaying, rooms.length, loading, isMobile, handleNext]);

  const handleIndicatorClick = useCallback((roomIndex: number) => {
    if (rooms[roomIndex]) {
      setActiveRoom(rooms[roomIndex]);
      handleUserInteraction();
    }
  }, [rooms, setActiveRoom, handleUserInteraction]);

  const handleImageLoad = useCallback(() => {
    setImageLoading(false);
  }, []);

  const handleImageError = useCallback(() => {
    setImageLoading(false);
    setImageError(true);
  }, []);

  // Memoize room indicators to prevent unnecessary re-renders
  const roomIndicators = useMemo(() =>
    rooms.map((room, index) => (
      <Indicator
        key={room.id}
        $isActive={room.id === activeRoom?.id}
        onClick={() => handleIndicatorClick(index)}
        aria-label={`Ir a ${room.name}`}
      />
    )),
    [rooms, activeRoom?.id, handleIndicatorClick]
  );

  if (loading) {
    return (
      <HeroContainer>
        <LoadingContainer>
          <Loading text="Cargando escape rooms..." />
        </LoadingContainer>
      </HeroContainer>
    );
  }

  if (error) {
    return (
      <HeroContainer>
        <HeroContent>
          <HeroTitle>Error al cargar</HeroTitle>
          <HeroDescription>
            No se pudieron cargar los escape rooms. Por favor, intenta nuevamente.
          </HeroDescription>
        </HeroContent>
      </HeroContainer>
    );
  }



  // Debug: Log activeRoom data
  console.log('DEBUG - activeRoom:', activeRoom);
  if (activeRoom) {
    console.log('DEBUG - video_url:', activeRoom.video_url);
  }

  if (!activeRoom) {
    return (
      <HeroContainer>
        <HeroContent>
          <HeroTitle>No hay escape rooms disponibles</HeroTitle>
          <HeroDescription>
            Actualmente no hay escape rooms disponibles para reservar.
          </HeroDescription>
        </HeroContent>
      </HeroContainer>
    );
  }

  // Mobile: Use Tinder-style cards
  if (isMobile) {
    return (
      <HeroContainer>
        <TinderCards
          rooms={rooms}
          activeRoom={activeRoom}
          onRoomChange={setActiveRoom}
          onReserveClick={onReserveClick}
          onDetailClick={onDetailClick}
          onVideoClick={onVideoClick}
        />
      </HeroContainer>
    );
  }

  // Debug: Log activeRoom data
  console.log('DEBUG - activeRoom:', activeRoom);
  console.log('DEBUG - video_url:', activeRoom.video_url);

  // Desktop: Original design
  return (
    <HeroContainer>
      {!imageError && (
        <HeroImage
          src={activeRoom.hero_image}
          alt={activeRoom.name}
          $isLoading={imageLoading}
          onLoad={handleImageLoad}
          onError={handleImageError}
          loading="lazy"
        />
      )}

      <HeroOverlay />

      {imageLoading && (
        <LoadingContainer>
          <Loading text="Cargando imagen..." />
        </LoadingContainer>
      )}

      {/* Navigation Controls - Only show if there are multiple rooms */}
      {rooms.length > 1 && (
        <>
          <NavigationContainer>
            <NavButton
              onClick={() => {
                handlePrevious();
                handleUserInteraction();
              }}
              disabled={loading}
              aria-label="Sala anterior"
            >
              ‹
            </NavButton>
            <NavButton
              onClick={() => {
                handleNext();
                handleUserInteraction();
              }}
              disabled={loading}
              aria-label="Siguiente sala"
            >
              ›
            </NavButton>
          </NavigationContainer>

          <RoomIndicators>
            {roomIndicators}
          </RoomIndicators>
        </>
      )}

      <HeroContent>
        <HeroTitle>{activeRoom.name}</HeroTitle>
        <HeroDescription>{activeRoom.short_description}</HeroDescription>

        <ButtonGroup>
          <Button
            variant="primary"
            onClick={onReserveClick}
          >
            Reservar
          </Button>
          <Button
            variant="secondary"
            onClick={onDetailClick}
          >
            Detalle
          </Button>
          <Button
            variant="secondary"
            onClick={onVideoClick}
          >
            Ver Video
          </Button>
        </ButtonGroup>
      </HeroContent>
    </HeroContainer>
  );
};