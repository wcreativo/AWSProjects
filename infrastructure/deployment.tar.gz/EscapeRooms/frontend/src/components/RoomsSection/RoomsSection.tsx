import React from 'react';
import styled from 'styled-components';
import { useRoom } from '../../contexts/RoomContext';
import { Button } from '../common/Button';
import { Loading } from '../common/Loading';

interface RoomsSectionProps {
    onReserveClick: (roomId?: number) => void;
    onDetailClick: (roomId?: number) => void;
    onVideoClick: (roomId?: number) => void;
}

const RoomsContainer = styled.section`
  max-width: 1200px;
  margin: 0 auto;
  padding: 80px 20px ${props => props.theme.spacing.xxl} 20px;
  background: ${props => props.theme.colors.background.primary};
  
  @media (min-width: 1024px) {
    padding: 120px 40px ${props => props.theme.spacing.xxl} 40px;
  }
  
  h2 {
    font-family: ${props => props.theme.typography.fontFamily.heading};
    font-size: 2.5rem;
    font-weight: 400;
    color: #c3865b;
    margin-bottom: ${props => props.theme.spacing.xl};
    text-transform: uppercase;
    letter-spacing: 0.02em;
    text-align: center;
    
    @media (min-width: ${props => props.theme.breakpoints.tablet}) {
      font-size: 3rem;
    }
  }
`;

const RoomsGrid = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.xxl};
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    gap: ${props => props.theme.spacing.xxl};
  }
`;

const RoomCard = styled.div<{ $isReversed?: boolean }>`
  display: flex;
  flex-direction: column;
  background: ${props => props.theme.colors.background.secondary};
  border-radius: ${props => props.theme.borderRadius.xl};
  overflow: hidden;
  border: 1px solid rgba(255, 255, 255, 0.1);
  transition: all ${props => props.theme.transitions.normal};
  
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
    border-color: rgba(195, 134, 91, 0.3);
  }
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    flex-direction: ${props => props.$isReversed ? 'row-reverse' : 'row'};
    min-height: 400px;
  }
`;

const RoomImageContainer = styled.div`
  position: relative;
  width: 100%;
  height: 250px;
  overflow: hidden;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    width: 50%;
    height: auto;
  }
`;

const RoomImage = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
  transition: transform ${props => props.theme.transitions.slow};
  
  ${RoomCard}:hover & {
    transform: scale(1.05);
  }
`;

const RoomContent = styled.div`
  padding: ${props => props.theme.spacing.xl};
  display: flex;
  flex-direction: column;
  justify-content: center;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    width: 50%;
    padding: ${props => props.theme.spacing.xxl};
  }
`;

const RoomName = styled.h3`
  font-family: ${props => props.theme.typography.fontFamily.heading};
  font-size: 2rem;
  font-weight: 400;
  color: #c3865b;
  margin: 0 0 ${props => props.theme.spacing.md} 0;
  text-transform: uppercase;
  letter-spacing: 0.02em;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    font-size: 2.5rem;
  }
`;

const RoomDescription = styled.p`
  font-family: ${props => props.theme.typography.fontFamily.primary};
  font-size: ${props => props.theme.typography.fontSize.md};
  color: ${props => props.theme.colors.text.secondary};
  line-height: 1.6;
  margin: 0 0 ${props => props.theme.spacing.lg} 0;
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    font-size: ${props => props.theme.typography.fontSize.lg};
    margin-bottom: ${props => props.theme.spacing.xl};
  }
`;

const RoomDetails = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: ${props => props.theme.spacing.md};
  margin-bottom: ${props => props.theme.spacing.xl};
`;

const DetailItem = styled.div`
  display: flex;
  align-items: center;
  gap: ${props => props.theme.spacing.sm};
  padding: ${props => props.theme.spacing.sm} ${props => props.theme.spacing.md};
  background: rgba(195, 134, 91, 0.1);
  border-radius: ${props => props.theme.borderRadius.md};
  border: 1px solid rgba(195, 134, 91, 0.2);
`;

const DetailIcon = styled.span`
  font-size: 1.2rem;
`;

const DetailText = styled.span`
  font-family: ${props => props.theme.typography.fontFamily.primary};
  font-size: ${props => props.theme.typography.fontSize.sm};
  color: ${props => props.theme.colors.text.primary};
  font-weight: ${props => props.theme.typography.fontWeight.medium};
`;

const ButtonGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.md};
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    flex-direction: row;
  }
`;

const LoadingContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
`;

const ErrorContainer = styled.div`
  text-align: center;
  padding: ${props => props.theme.spacing.xxl};
  
  h3 {
    font-family: ${props => props.theme.typography.fontFamily.heading};
    font-size: 1.5rem;
    color: ${props => props.theme.colors.error};
    margin-bottom: ${props => props.theme.spacing.md};
  }
  
  p {
    font-family: ${props => props.theme.typography.fontFamily.primary};
    color: ${props => props.theme.colors.text.secondary};
  }
`;

export const RoomsSection: React.FC<RoomsSectionProps> = ({
    onReserveClick,
    onDetailClick,
    onVideoClick,
}) => {
    const { state, setActiveRoom } = useRoom();
    const { rooms, loading, error } = state;

    const handleRoomAction = (roomId: number, action: (roomId?: number) => void) => {
        const room = rooms.find(r => r.id === roomId);
        if (room) {
            setActiveRoom(room);
            action(roomId);
        }
    };

    if (loading) {
        return (
            <RoomsContainer>
                <LoadingContainer>
                    <Loading text="Cargando escape rooms..." />
                </LoadingContainer>
            </RoomsContainer>
        );
    }

    if (error) {
        return (
            <RoomsContainer>
                <ErrorContainer>
                    <h3>Error al cargar</h3>
                    <p>No se pudieron cargar los escape rooms. Por favor, intenta nuevamente.</p>
                </ErrorContainer>
            </RoomsContainer>
        );
    }

    if (!rooms || rooms.length === 0) {
        return (
            <RoomsContainer>
                <ErrorContainer>
                    <h3>No hay escape rooms disponibles</h3>
                    <p>Actualmente no hay escape rooms disponibles para reservar.</p>
                </ErrorContainer>
            </RoomsContainer>
        );
    }

    return (
        <RoomsContainer id="rooms">
            <RoomsGrid>
                {rooms.map((room, index) => (
                    <RoomCard key={room.id} $isReversed={index % 2 === 1}>
                        <RoomImageContainer>
                            <RoomImage
                                src={room.hero_image || room.thumbnail_image}
                                alt={room.name}
                                loading="lazy"
                            />
                        </RoomImageContainer>
                        <RoomContent>
                            <RoomName>{room.name}</RoomName>
                            <RoomDescription>{room.short_description}</RoomDescription>

                            <RoomDetails>
                                <DetailItem>
                                    <DetailIcon>👥</DetailIcon>
                                    <DetailText>2-7 personas</DetailText>
                                </DetailItem>
                                <DetailItem>
                                    <DetailIcon>⏱️</DetailIcon>
                                    <DetailText>60 minutos</DetailText>
                                </DetailItem>
                                <DetailItem>
                                    <DetailIcon>🎯</DetailIcon>
                                    <DetailText>Dificultad: Media</DetailText>
                                </DetailItem>
                            </RoomDetails>

                            <ButtonGroup>
                                <Button
                                    variant="primary"
                                    onClick={() => handleRoomAction(room.id, onReserveClick)}
                                >
                                    Reservar
                                </Button>
                                <Button
                                    variant="secondary"
                                    onClick={() => handleRoomAction(room.id, onDetailClick)}
                                >
                                    Ver Detalles
                                </Button>
                                {room.video_url && (
                                    <Button
                                        variant="secondary"
                                        onClick={() => handleRoomAction(room.id, onVideoClick)}
                                    >
                                        Ver Video
                                    </Button>
                                )}
                            </ButtonGroup>
                        </RoomContent>
                    </RoomCard>
                ))}
            </RoomsGrid>
        </RoomsContainer>
    );
};