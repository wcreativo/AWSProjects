import React from 'react';
import { render, screen } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { AdminPage } from './AdminPage';
import { AdminProvider } from '../../contexts/AdminContext';
import { theme } from '../../styles';

// Mock the admin components
jest.mock('../admin/AdminLayout', () => ({
  AdminLayout: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="admin-layout">{children}</div>
  ),
}));

jest.mock('../admin/AdminDashboard', () => ({
  AdminDashboard: () => <div data-testid="admin-dashboard">Admin Dashboard</div>,
}));

jest.mock('../common/ProtectedRoute', () => ({
  ProtectedRoute: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="protected-route">{children}</div>
  ),
}));

const renderWithProviders = () => {
  return render(
    <ThemeProvider theme={theme}>
      <AdminProvider>
        <AdminPage />
      </AdminProvider>
    </ThemeProvider>
  );
};

describe('AdminPage', () => {
  it('should render protected route with admin layout and dashboard', () => {
    renderWithProviders();
    
    expect(screen.getByTestId('protected-route')).toBeInTheDocument();
    expect(screen.getByTestId('admin-layout')).toBeInTheDocument();
    expect(screen.getByTestId('admin-dashboard')).toBeInTheDocument();
  });

  it('should have correct component hierarchy', () => {
    renderWithProviders();
    
    const protectedRoute = screen.getByTestId('protected-route');
    const adminLayout = screen.getByTestId('admin-layout');
    const adminDashboard = screen.getByTestId('admin-dashboard');
    
    expect(protectedRoute).toContainElement(adminLayout);
    expect(adminLayout).toContainElement(adminDashboard);
  });
});