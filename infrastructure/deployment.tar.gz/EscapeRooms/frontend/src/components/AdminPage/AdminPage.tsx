import React from 'react';
import { AdminLayout, AdminDashboard } from '../admin';
import { ProtectedRoute } from '../common';

export const AdminPage: React.FC = () => {
  return (
    <ProtectedRoute>
      <AdminLayout>
        <AdminDashboard />
      </AdminLayout>
    </ProtectedRoute>
  );
};