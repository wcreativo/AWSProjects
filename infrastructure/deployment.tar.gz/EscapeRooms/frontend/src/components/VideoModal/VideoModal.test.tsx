import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { VideoModal } from './VideoModal';
import { theme } from '../../styles/theme';

const renderWithTheme = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('VideoModal', () => {
  const mockOnClose = jest.fn();
  const mockVideoUrl = '/videos/test-video.mp4';
  const mockRoomName = 'Test Room';

  beforeEach(() => {
    jest.clearAllMocks();
    // Mock document.body.style
    Object.defineProperty(document.body, 'style', {
      value: { overflow: '' },
      writable: true,
    });
  });

  it('renders modal when isOpen is true', () => {
    renderWithTheme(
      <VideoModal
        isOpen={true}
        onClose={mockOnClose}
        videoUrl={mockVideoUrl}
        roomName={mockRoomName}
      />
    );

    expect(screen.getByText('Video - Test Room')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Cerrar video' })).toBeInTheDocument();
  });

  it('does not render modal when isOpen is false', () => {
    renderWithTheme(
      <VideoModal
        isOpen={false}
        onClose={mockOnClose}
        videoUrl={mockVideoUrl}
        roomName={mockRoomName}
      />
    );

    expect(screen.queryByText('Video - Test Room')).not.toBeInTheDocument();
  });

  it('renders video element with correct attributes', () => {
    renderWithTheme(
      <VideoModal
        isOpen={true}
        onClose={mockOnClose}
        videoUrl={mockVideoUrl}
        roomName={mockRoomName}
      />
    );

    const video = screen.getByLabelText('Video de Test Room');
    expect(video).toBeInTheDocument();
    expect(video).toHaveAttribute('src', mockVideoUrl);
    expect(video).toHaveAttribute('controls');
    expect(video).toHaveAttribute('preload', 'metadata');
  });

  it('calls onClose when close button is clicked', () => {
    renderWithTheme(
      <VideoModal
        isOpen={true}
        onClose={mockOnClose}
        videoUrl={mockVideoUrl}
        roomName={mockRoomName}
      />
    );

    const closeButton = screen.getByRole('button', { name: 'Cerrar video' });
    fireEvent.click(closeButton);

    expect(mockOnClose).toHaveBeenCalledTimes(1);
  });

  it('calls onClose when overlay is clicked', () => {
    renderWithTheme(
      <VideoModal
        isOpen={true}
        onClose={mockOnClose}
        videoUrl={mockVideoUrl}
        roomName={mockRoomName}
      />
    );

    // Click on the overlay (the modal background)
    const overlay = screen.getByText('Video - Test Room').closest('[role="dialog"]')?.parentElement;
    if (overlay) {
      fireEvent.click(overlay);
      expect(mockOnClose).toHaveBeenCalledTimes(1);
    }
  });

  it('handles escape key press', () => {
    renderWithTheme(
      <VideoModal
        isOpen={true}
        onClose={mockOnClose}
        videoUrl={mockVideoUrl}
        roomName={mockRoomName}
      />
    );

    fireEvent.keyDown(document, { key: 'Escape' });
    expect(mockOnClose).toHaveBeenCalledTimes(1);
  });

  it('sets body overflow to hidden when modal is open', () => {
    renderWithTheme(
      <VideoModal
        isOpen={true}
        onClose={mockOnClose}
        videoUrl={mockVideoUrl}
        roomName={mockRoomName}
      />
    );

    expect(document.body.style.overflow).toBe('hidden');
  });

  it('resets body overflow when modal is closed', () => {
    const { rerender } = renderWithTheme(
      <VideoModal
        isOpen={true}
        onClose={mockOnClose}
        videoUrl={mockVideoUrl}
        roomName={mockRoomName}
      />
    );

    expect(document.body.style.overflow).toBe('hidden');

    rerender(
      <ThemeProvider theme={theme}>
        <VideoModal
          isOpen={false}
          onClose={mockOnClose}
          videoUrl={mockVideoUrl}
          roomName={mockRoomName}
        />
      </ThemeProvider>
    );

    expect(document.body.style.overflow).toBe('unset');
  });
});