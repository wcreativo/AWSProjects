import React from 'react';
import styled from 'styled-components';

interface ModernMenuProps {
    isOpen: boolean;
    onClose: () => void;
    onNavigateToHome: () => void;
    onScrollToSection: (sectionId: string) => void;
    onNavigateToAdmin: () => void;
}

const MenuOverlay = styled.div.withConfig({
    shouldForwardProp: (prop) => !['isOpen'].includes(prop),
}) <{ isOpen: boolean }>`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.8);
  backdrop-filter: blur(20px);
  z-index: ${({ theme }) => theme.zIndex.modal};
  
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  
  /* Animación simple y rápida */
  opacity: ${props => props.isOpen ? 1 : 0};
  visibility: ${props => props.isOpen ? 'visible' : 'hidden'};
  transition: opacity 0.2s ease, visibility 0.2s ease;
  
  /* Asegurar que cubra toda la pantalla */
  margin: 0;
  padding: 0;
  box-sizing: border-box;
`;

const MenuContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  max-width: 600px;
  padding: ${({ theme }) => theme.spacing.xxl};
`;

const CloseButton = styled.button`
  position: absolute;
  top: 2rem;
  right: 2rem;
  width: 60px;
  height: 60px;
  background: rgba(255, 255, 255, 0.1);
  border: 2px solid rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  color: ${({ theme }) => theme.colors.text.primary};
  font-size: 2rem;
  font-weight: 300;
  cursor: pointer;
  backdrop-filter: blur(10px);
  
  display: flex;
  align-items: center;
  justify-content: center;
  
  transition: all 0.15s ease;
  
  &:hover {
    background: rgba(195, 134, 91, 0.2);
    border-color: rgba(195, 134, 91, 0.4);
    color: ${({ theme }) => theme.colors.primary.main};
    transform: scale(1.1);
  }
  
  &:active {
    transform: scale(0.95);
  }
  
  @media (max-width: 767px) {
    top: 1.5rem;
    right: 1.5rem;
    width: 55px;
    height: 55px;
    font-size: 1.8rem;
  }
`;

const MenuTitle = styled.h2`
  font-family: ${({ theme }) => theme.typography.fontFamily.heading};
  font-size: 3rem;
  font-weight: 300;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  text-align: center;
  margin: 0 0 3rem 0;
  color: ${({ theme }) => theme.colors.primary.main};
  
  @media (max-width: 767px) {
    font-size: 2.5rem;
    margin-bottom: 2rem;
  }
`;

const MenuItems = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.5rem;
  width: 100%;
  
  @media (max-width: 767px) {
    gap: 1.2rem;
  }
`;

const MenuItem = styled.button`
  background: rgba(255, 255, 255, 0.08);
  border: 2px solid rgba(255, 255, 255, 0.15);
  color: ${({ theme }) => theme.colors.text.primary};
  font-family: ${({ theme }) => theme.typography.fontFamily.heading};
  font-size: 1.4rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  
  padding: 1.2rem 3rem;
  border-radius: 30px;
  min-width: 300px;
  
  cursor: pointer;
  backdrop-filter: blur(15px);
  
  transition: all 0.15s ease;
  
  &:hover {
    background: rgba(195, 134, 91, 0.2);
    border-color: rgba(195, 134, 91, 0.5);
    color: ${({ theme }) => theme.colors.primary.main};
    transform: translateY(-2px) scale(1.02);
    box-shadow: 0 8px 20px rgba(195, 134, 91, 0.3);
  }
  
  &:active {
    transform: translateY(0) scale(1);
  }
  
  @media (max-width: 767px) {
    font-size: 1.2rem;
    padding: 1rem 2.5rem;
    min-width: 280px;
  }
`;

export const ModernMenu: React.FC<ModernMenuProps> = ({
    isOpen,
    onClose,
    onNavigateToHome,
    onScrollToSection,
    onNavigateToAdmin,
}) => {
    const menuItems = [
        { label: 'Inicio', action: onNavigateToHome },
        { label: 'Salas', action: () => onScrollToSection('rooms') },
        { label: 'FAQ', action: () => onScrollToSection('faq') },
        { label: 'Contacto', action: () => onScrollToSection('contact') },
        { label: 'Horarios', action: () => onScrollToSection('horarios') },
        { label: 'Admin', action: onNavigateToAdmin },
    ];

    return (
        <MenuOverlay isOpen={isOpen}>
            <CloseButton onClick={onClose}>×</CloseButton>

            <MenuContainer>
                <MenuTitle>
                    Menú
                </MenuTitle>

                <MenuItems>
                    {menuItems.map((item) => (
                        <MenuItem
                            key={item.label}
                            onClick={item.action}
                        >
                            {item.label}
                        </MenuItem>
                    ))}
                </MenuItems>
            </MenuContainer>
        </MenuOverlay>
    );
};