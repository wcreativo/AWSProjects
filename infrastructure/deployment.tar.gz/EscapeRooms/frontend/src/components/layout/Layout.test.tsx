import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { Layout } from './Layout';
import { theme } from '../../styles/theme';

const renderWithTheme = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('Layout Component', () => {
  it('renders children correctly', () => {
    renderWithTheme(
      <Layout>
        <div>Test content</div>
      </Layout>
    );
    
    expect(screen.getByText('Test content')).toBeInTheDocument();
  });

  it('shows navigation by default', () => {
    renderWithTheme(
      <Layout>
        <div>Content</div>
      </Layout>
    );
    
    expect(screen.getByAltText('Escape Rooms Logo')).toBeInTheDocument();
    expect(screen.getByText('Inicio')).toBeInTheDocument();
  });

  it('hides navigation when showNavigation is false', () => {
    renderWithTheme(
      <Layout showNavigation={false}>
        <div>Content</div>
      </Layout>
    );
    
    expect(screen.queryByText('Escape Rooms')).not.toBeInTheDocument();
  });

  it('renders footer with copyright', () => {
    renderWithTheme(
      <Layout>
        <div>Content</div>
      </Layout>
    );
    
    expect(screen.getByText(/© 2025 Escape Rooms/)).toBeInTheDocument();
  });

  it('toggles mobile menu when hamburger button is clicked', () => {
    renderWithTheme(
      <Layout>
        <div>Content</div>
      </Layout>
    );
    
    const menuButton = screen.getByRole('button');
    expect(menuButton).toBeInTheDocument();
    
    // Click to open menu
    fireEvent.click(menuButton);
    
    // Menu should be open (we can't easily test CSS transforms, but we can verify the button exists)
    expect(menuButton).toBeInTheDocument();
    
    // Click to close menu
    fireEvent.click(menuButton);
    expect(menuButton).toBeInTheDocument();
  });

  it('closes mobile menu when nav link is clicked', () => {
    renderWithTheme(
      <Layout>
        <div>Content</div>
      </Layout>
    );
    
    const menuButton = screen.getByRole('button');
    fireEvent.click(menuButton); // Open menu
    
    const homeLink = screen.getByText('Inicio');
    fireEvent.click(homeLink);
    
    // Menu should close (button should still exist)
    expect(menuButton).toBeInTheDocument();
  });

  it('renders all navigation links', () => {
    renderWithTheme(
      <Layout>
        <div>Content</div>
      </Layout>
    );
    
    expect(screen.getByText('Inicio')).toBeInTheDocument();
    expect(screen.getByText('Salas')).toBeInTheDocument();
    expect(screen.getByText('Contacto')).toBeInTheDocument();
    expect(screen.getByText('Admin')).toBeInTheDocument();
  });

  it('has proper navigation buttons', () => {
    renderWithTheme(
      <Layout>
        <div>Content</div>
      </Layout>
    );
    
    const homeButton = screen.getByText('Inicio');
    expect(homeButton).toBeInTheDocument();
    expect(homeButton.tagName).toBe('BUTTON');
    
    const roomsButton = screen.getByText('Salas');
    expect(roomsButton).toBeInTheDocument();
    expect(roomsButton.tagName).toBe('BUTTON');
  });

  it('applies correct padding when navigation is shown', () => {
    renderWithTheme(
      <Layout showNavigation={true}>
        <div>Content with nav</div>
      </Layout>
    );
    
    const content = screen.getByText('Content with nav');
    const mainElement = content.closest('main');
    expect(mainElement).toBeInTheDocument();
  });

  it('applies correct padding when navigation is hidden', () => {
    renderWithTheme(
      <Layout showNavigation={false}>
        <div>Content without nav</div>
      </Layout>
    );
    
    const content = screen.getByText('Content without nav');
    const mainElement = content.closest('main');
    expect(mainElement).toBeInTheDocument();
  });

  it('hamburger menu has proper accessibility', () => {
    renderWithTheme(
      <Layout>
        <div>Content</div>
      </Layout>
    );
    
    const menuButton = screen.getByRole('button');
    expect(menuButton).toHaveAttribute('type', 'button');
  });

  it('renders logo with correct text', () => {
    renderWithTheme(
      <Layout>
        <div>Content</div>
      </Layout>
    );
    
    const logo = screen.getByAltText('Escape Rooms Logo');
    expect(logo).toBeInTheDocument();
  });
});