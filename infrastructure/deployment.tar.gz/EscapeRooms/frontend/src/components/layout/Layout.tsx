import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { WhatsAppButton } from '../common';
import { ModernMenu } from './ModernMenu';

interface LayoutProps {
  children: React.ReactNode;
  showNavigation?: boolean;
}

const LayoutContainer = styled.div`
  min-height: 100vh;
  background: ${({ theme }) => theme.colors.background.primary};
  color: white;
  overflow-x: hidden;
`;

const Header = styled.header.withConfig({
  shouldForwardProp: (prop) => !['isVisible', 'isScrolled'].includes(prop),
}) <{ isVisible: boolean; isScrolled: boolean }>`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: ${({ theme }) => theme.zIndex.dropdown};
  background: ${props => props.isScrolled ? 'rgba(0, 0, 0, 0.8)' : 'transparent'};
  backdrop-filter: ${props => props.isScrolled ? 'blur(20px)' : 'none'};
  transition: all ${({ theme }) => theme.transitions.normal};
  transform: ${props => props.isVisible ? 'translateY(0)' : 'translateY(-100%)'};
  border-bottom: ${props => props.isScrolled ? '1px solid rgba(255, 255, 255, 0.1)' : '1px solid transparent'};
  
  @media (max-width: 767px) {
    padding: ${({ theme }) => theme.spacing.md} ${({ theme }) => theme.spacing.md};
  }
  
  @media (min-width: 768px) {
    padding: ${({ theme }) => theme.spacing.lg} ${({ theme }) => theme.spacing.xl};
  }
`;

const Nav = styled.nav`
  display: flex;
  align-items: center;
  justify-content: space-between;
  max-width: 1200px;
  margin: 0 auto;
`;

const RightSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.md};
`;

const PhoneNumber = styled.a`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing.xs};
  color: ${({ theme }) => theme.colors.text.primary};
  text-decoration: none;
  font-family: ${({ theme }) => theme.typography.fontFamily.primary};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  font-weight: 500;
  transition: all ${({ theme }) => theme.transitions.normal};
  padding: ${({ theme }) => theme.spacing.xs} ${({ theme }) => theme.spacing.sm};
  border-radius: 20px;
  
  &:hover {
    color: ${({ theme }) => theme.colors.primary.main};
    background: rgba(255, 255, 255, 0.1);
    transform: scale(1.05);
  }
  
  .phone-icon {
    font-size: ${({ theme }) => theme.typography.fontSize.md};
  }
  
  @media (max-width: 767px) {
    font-size: ${({ theme }) => theme.typography.fontSize.xs};
    gap: ${({ theme }) => theme.spacing.xs};
    padding: ${({ theme }) => theme.spacing.xs};
    
    .phone-icon {
      font-size: ${({ theme }) => theme.typography.fontSize.sm};
    }
  }
  
  @media (min-width: 768px) {
    font-size: ${({ theme }) => theme.typography.fontSize.sm};
  }
`;

const Logo = styled.div`
  display: flex;
  align-items: center;
  
  img {
    height: 60px;
    width: auto;
    transition: all ${({ theme }) => theme.transitions.normal};
    
    @media (max-width: 767px) {
      height: 50px;
    }
    
    @media (min-width: 768px) {
      height: 65px;
    }
    
    @media (min-width: 1024px) {
      height: 70px;
    }
  }
`;

const MenuButton = styled.button.withConfig({
  shouldForwardProp: (prop) => !['isOpen'].includes(prop),
}) <{ isOpen: boolean }>`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 44px;
  height: 44px;
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
  border-radius: 12px;
  transition: all ${({ theme }) => theme.transitions.normal};
  position: relative;
  
  &:hover {
    background: rgba(255, 255, 255, 0.15);
    transform: scale(1.05);
  }
  
  &:active {
    transform: scale(0.95);
  }
  
  /* Indicador sutil de menú disponible */
  &::before {
    content: '';
    position: absolute;
    top: -2px;
    right: -2px;
    width: 8px;
    height: 8px;
    background: ${({ theme }) => theme.colors.primary.main};
    border-radius: 50%;
    opacity: ${props => props.isOpen ? 0 : 0.7};
    transition: all ${({ theme }) => theme.transitions.normal};
    transform: scale(${props => props.isOpen ? 0 : 1});
  }
  
  span {
    display: block;
    width: 24px;
    height: 2.5px;
    background: ${({ theme }) => theme.colors.text.primary};
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    transform-origin: center;
    border-radius: 2px;
    
    &:not(:last-child) {
      margin-bottom: 4px;
    }
    
    ${props => props.isOpen && `
      &:nth-child(1) {
        transform: rotate(45deg) translate(3px, 3px);
        background: ${props.theme.colors.primary.main};
      }
      
      &:nth-child(2) {
        opacity: 0;
        transform: scale(0);
      }
      
      &:nth-child(3) {
        transform: rotate(-45deg) translate(3px, -3px);
        background: ${props.theme.colors.primary.main};
      }
    `}
  }
`;





const MainContent = styled.main.withConfig({
  shouldForwardProp: (prop) => !['hasHeader'].includes(prop),
}) <{ hasHeader: boolean }>`
  width: 100%;
  margin: 0 auto;
  padding: 0;
  /* No padding-top para que el header esté superpuesto */
`;

const Footer = styled.footer`
  margin-top: auto;
  padding: ${({ theme }) => theme.spacing.xl} ${({ theme }) => theme.spacing.md};
  text-align: center;
  color: ${({ theme }) => theme.colors.text.tertiary};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  
  @media (min-width: 768px) {
    padding: ${({ theme }) => theme.spacing.xl} ${({ theme }) => theme.spacing.lg};
  }
`;

export const Layout: React.FC<LayoutProps> = ({
  children,
  showNavigation = true
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Detectar scroll para activar el blur del header
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      setIsScrolled(scrollTop > 50); // Activar blur después de 50px de scroll
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Cerrar menú con tecla Escape y prevenir scroll
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isMenuOpen) {
        closeMenu();
      }
    };

    if (isMenuOpen) {
      document.addEventListener('keydown', handleKeyDown);
      // Prevenir scroll del body cuando el menú está abierto
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [isMenuOpen]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const scrollToSection = (sectionId: string) => {
    // Check if we're on the home page
    if (window.location.pathname === '/') {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      // Navigate to home page with hash
      window.location.href = `/#${sectionId}`;
    }
    closeMenu();
  };

  const navigateToHome = () => {
    window.location.href = '/';
    closeMenu();
  };

  const navigateToAdmin = () => {
    window.location.href = '/admin';
    closeMenu();
  };

  return (
    <LayoutContainer>
      {showNavigation && (
        <Header isVisible={true} isScrolled={isScrolled}>
          <Nav>
            <Logo>
              <a href="/" style={{ display: 'flex', alignItems: 'center' }}>
                <img src="/images/logo.svg" alt="Escape Rooms Logo" />
              </a>
            </Logo>
            <RightSection>
              <PhoneNumber href="tel:+50766160986">
                <span className="phone-icon">☎</span>
                <span>+507 6616-0986</span>
              </PhoneNumber>
              <MenuButton type="button" isOpen={isMenuOpen} onClick={toggleMenu}>
                <span />
                <span />
                <span />
              </MenuButton>
            </RightSection>

          </Nav>
        </Header>
      )}

      <MainContent hasHeader={showNavigation}>
        {children}
      </MainContent>

      <Footer>
        © 2025 Escape Rooms. Todos los derechos reservados.
      </Footer>
      
      <WhatsAppButton phoneNumber="+50766160986" />
      
      <ModernMenu
        isOpen={isMenuOpen}
        onClose={closeMenu}
        onNavigateToHome={navigateToHome}
        onScrollToSection={scrollToSection}
        onNavigateToAdmin={navigateToAdmin}
      />
    </LayoutContainer>
  );
};