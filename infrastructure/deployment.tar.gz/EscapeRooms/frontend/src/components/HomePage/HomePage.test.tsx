import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { HomePage } from './HomePage';
import { RoomProvider } from '../../contexts/RoomContext';
import { theme } from '../../styles/theme';
import { ReservationProvider } from '../../contexts/ReservationContext';
import { ToastProvider } from '../../contexts/ToastContext';

// Mock the useRooms hook
jest.mock('../../hooks/useRooms', () => ({
  useRooms: jest.fn(() => ({
    rooms: [],
    activeRoom: null,
    loading: false,
    error: null,
    refetch: jest.fn(),
  })),
}));

// Mock room data
const mockRoom = {
  id: 1,
  name: 'La Inquisición',
  slug: 'la-inquisicion',
  short_description: 'Una experiencia medieval llena de misterios y desafíos.',
  full_description: 'Descripción completa del escape room...',
  hero_image: '/images/inquisicion-hero.jpg',
  thumbnail_image: '/images/inquisicion-thumb.jpg',
  base_price: 30,
  is_active: true,
};

// Mock the RoomContext
jest.mock('../../contexts/RoomContext', () => ({
  useRoom: jest.fn(() => ({
    state: {
      rooms: [],
      activeRoom: null,
      loading: false,
      error: null,
    },
    setRooms: jest.fn(),
    setActiveRoom: jest.fn(),
    setLoading: jest.fn(),
    setError: jest.fn(),
  })),
}));

const mockUseRoom = require('../../contexts/RoomContext').useRoom as jest.MockedFunction<any>;

const renderWithProviders = (component: React.ReactElement) => {
  // Set up mock to return room data
  mockUseRoom.mockReturnValue({
    state: {
      rooms: [mockRoom],
      activeRoom: mockRoom,
      loading: false,
      error: null,
    },
    setRooms: jest.fn(),
    setActiveRoom: jest.fn(),
    setLoading: jest.fn(),
    setError: jest.fn(),
  });

  return render(
    <ThemeProvider theme={theme}>
      <ToastProvider>
        <ReservationProvider>
          {component}
        </ReservationProvider>
      </ToastProvider>
    </ThemeProvider>
  );
};

// Mock console.log to test button clicks
const consoleSpy = jest.spyOn(console, 'log').mockImplementation();

describe('HomePage', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    consoleSpy.mockClear();
  });

  afterAll(() => {
    consoleSpy.mockRestore();
  });

  it('renders HomePage with HeroSection', () => {
    renderWithProviders(<HomePage />);

    // Check that the room name appears (could be multiple instances due to modal)
    expect(screen.getAllByText('La Inquisición').length).toBeGreaterThan(0);
    expect(screen.getAllByText('Una experiencia medieval llena de misterios y desafíos.').length).toBeGreaterThan(0);
    expect(screen.getByRole('button', { name: 'Reservar' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Detalle' })).toBeInTheDocument();
  });

  it('renders hero section with room information', () => {
    renderWithProviders(<HomePage />);

    // Check that the hero section shows room information
    expect(screen.getAllByText('La Inquisición').length).toBeGreaterThan(0);
    expect(screen.getAllByText('Una experiencia medieval llena de misterios y desafíos.').length).toBeGreaterThan(0);
  });

  it('handles reserve button click', () => {
    renderWithProviders(<HomePage />);

    const reserveButton = screen.getByRole('button', { name: 'Reservar' });
    fireEvent.click(reserveButton);

    // Check that the reservation modal opens
    expect(screen.getByText('Reserva')).toBeInTheDocument();
  });

  it('handles detail button click', () => {
    renderWithProviders(<HomePage />);

    const detailButton = screen.getByRole('button', { name: 'Detalle' });
    fireEvent.click(detailButton);

    // Check that the detail modal opens (should show modal content)
    expect(screen.getByText('Información de Precios')).toBeInTheDocument();
    expect(screen.getByText('Características')).toBeInTheDocument();
  });

  it('renders contact section', () => {
    renderWithProviders(<HomePage />);

    expect(screen.getByText('Contacto')).toBeInTheDocument();
    expect(screen.getByText('¿Listo para vivir una experiencia única? ¡Contáctanos!')).toBeInTheDocument();
    expect(screen.getByText('Teléfono')).toBeInTheDocument();
  });

  it('updates modal states when buttons are clicked', () => {
    renderWithProviders(<HomePage />);

    // Initially modals should not be visible
    expect(screen.queryByText('Reserva')).not.toBeInTheDocument();
    expect(screen.queryByText('Información de Precios')).not.toBeInTheDocument();

    // Click reserve button
    const reserveButton = screen.getByRole('button', { name: 'Reservar' });
    fireEvent.click(reserveButton);

    // Should show reservation modal
    expect(screen.getByText('Reserva')).toBeInTheDocument();

    // Close reservation modal and click detail button
    fireEvent.click(screen.getByRole('button', { name: '×' }));
    
    const detailButton = screen.getByRole('button', { name: 'Detalle' });
    fireEvent.click(detailButton);

    // Should show detail modal
    expect(screen.getByText('Información de Precios')).toBeInTheDocument();
  });
});