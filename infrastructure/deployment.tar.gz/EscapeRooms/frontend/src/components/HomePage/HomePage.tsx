import React, { useState } from 'react';
import styled from 'styled-components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faInstagram, faTiktok } from '@fortawesome/free-brands-svg-icons';
import { RoomsSection } from '../RoomsSection';
import { DetailModal } from '../DetailModal';
import { ReservationModal } from '../ReservationModal';
import { VideoModal } from '../VideoModal';
import { useRooms } from '../../hooks/useRooms';
import { useRoom } from '../../contexts/RoomContext';

const HomeContainer = styled.main`
  min-height: 100vh;
  background: ${props => props.theme.colors.background.primary};
`;



const FAQSection = styled.section`
  max-width: 1200px;
  margin: 0 auto;
  padding: ${props => props.theme.spacing.xxl} 20px;
  background: ${props => props.theme.colors.background.primary};
  
  @media (min-width: 1024px) {
    padding: ${props => props.theme.spacing.xxl} 40px;
  }
  
  h2 {
    font-family: ${props => props.theme.typography.fontFamily.heading};
    font-size: 2.5rem;
    font-weight: 400;
    color: #c3865b;
    margin-bottom: ${props => props.theme.spacing.xl};
    text-transform: uppercase;
    letter-spacing: 0.02em;
    text-align: center;
    
    @media (min-width: ${props => props.theme.breakpoints.tablet}) {
      font-size: 3rem;
    }
  }
  
  .faq-container {
    display: flex;
    flex-direction: column;
    gap: ${props => props.theme.spacing.lg};
    max-width: 800px;
    margin: 0 auto;
  }
`;

const FAQItem = styled.div`
  background: ${props => props.theme.colors.background.secondary};
  border-radius: ${props => props.theme.borderRadius.lg};
  border: 1px solid rgba(255, 255, 255, 0.1);
  overflow: hidden;
  transition: all ${props => props.theme.transitions.normal};
  
  &:hover {
    border-color: rgba(195, 134, 91, 0.3);
    transform: translateY(-2px);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
  }
`;

const FAQQuestion = styled.button`
  width: 100%;
  padding: ${props => props.theme.spacing.lg};
  background: none;
  border: none;
  text-align: left;
  cursor: pointer;
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: all ${props => props.theme.transitions.normal};
  
  &:hover {
    background: rgba(195, 134, 91, 0.1);
  }
  
  h3 {
    font-family: ${props => props.theme.typography.fontFamily.heading};
    font-size: ${props => props.theme.typography.fontSize.xl};
    font-weight: 400;
    color: ${props => props.theme.colors.text.primary};
    margin: 0;
    text-transform: none;
    letter-spacing: -0.01em;
    line-height: 1.4;
    
    @media (min-width: ${props => props.theme.breakpoints.tablet}) {
      font-size: 1.5rem;
    }
  }
  
  .icon {
    font-size: 1.5rem;
    color: ${props => props.theme.colors.primary.main};
    transition: transform ${props => props.theme.transitions.normal};
    flex-shrink: 0;
    margin-left: ${props => props.theme.spacing.md};
    
    &.open {
      transform: rotate(45deg);
    }
  }
`;

const FAQAnswer = styled.div.withConfig({
  shouldForwardProp: (prop) => !['isOpen'].includes(prop),
}) <{ isOpen: boolean }>`
  max-height: ${props => props.isOpen ? '200px' : '0'};
  overflow: hidden;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  
  .answer-content {
    padding: ${props => props.theme.spacing.md} ${props => props.theme.spacing.lg} ${props => props.theme.spacing.lg};
    
    p {
      font-family: ${props => props.theme.typography.fontFamily.primary};
      font-size: ${props => props.theme.typography.fontSize.md};
      color: ${props => props.theme.colors.text.secondary};
      margin: 0;
      line-height: 1.6;
      letter-spacing: -0.01em;
      
      @media (min-width: ${props => props.theme.breakpoints.tablet}) {
        font-size: ${props => props.theme.typography.fontSize.lg};
      }
    }
  }
`;

const ContactSection = styled.section`
  max-width: 1200px;
  margin: 0 auto;
  padding: ${props => props.theme.spacing.xxl} 20px;
  text-align: center;
  background: ${props => props.theme.colors.background.primary};
  
  @media (min-width: 1024px) {
    padding: ${props => props.theme.spacing.xxl} 40px;
  }
  
  h2 {
    font-family: ${props => props.theme.typography.fontFamily.heading};
    font-size: 2.5rem;
    font-weight: 400;
    color: #c3865b;
    margin-bottom: ${props => props.theme.spacing.xl};
    text-transform: uppercase;
    letter-spacing: 0.02em;
    
    @media (min-width: ${props => props.theme.breakpoints.tablet}) {
      font-size: 3rem;
    }
  }
  
  p {
    font-family: ${props => props.theme.typography.fontFamily.primary};
    font-size: ${props => props.theme.typography.fontSize.lg};
    font-weight: 400;
    color: ${props => props.theme.colors.text.secondary};
    margin-bottom: ${props => props.theme.spacing.md};
    line-height: 1.6;
    letter-spacing: -0.01em;
  }
  
  .contact-info {
    display: grid;
    grid-template-columns: 1fr;
    gap: ${props => props.theme.spacing.lg};
    margin-top: ${props => props.theme.spacing.xl};
    
    @media (min-width: 768px) {
      grid-template-columns: repeat(3, 1fr);
    }
  }
  
  .contact-item {
    padding: ${props => props.theme.spacing.lg};
    background: ${props => props.theme.colors.background.secondary};
    border-radius: ${props => props.theme.borderRadius.lg};
    border: 1px solid rgba(255, 255, 255, 0.1);
    
    h3 {
      font-family: ${props => props.theme.typography.fontFamily.heading};
      color: ${props => props.theme.colors.primary.main};
      margin-bottom: ${props => props.theme.spacing.sm};
      text-transform: uppercase;
      letter-spacing: 0.01em;
      font-weight: 400;
    }
    
    p {
      margin: 0;
      font-family: ${props => props.theme.typography.fontFamily.primary};
      font-size: ${props => props.theme.typography.fontSize.md};
      color: ${props => props.theme.colors.text.secondary};
      letter-spacing: -0.01em;
    }
    
    .address-link {
      display: inline-block;
      margin: 0;
      font-family: ${props => props.theme.typography.fontFamily.primary};
      font-size: ${props => props.theme.typography.fontSize.md};
      color: ${props => props.theme.colors.text.secondary};
      letter-spacing: -0.01em;
      text-decoration: none;
      transition: all ${props => props.theme.transitions.normal};
      padding: ${props => props.theme.spacing.sm};
      border-radius: ${props => props.theme.borderRadius.md};
      position: relative;
      
      &:hover {
        color: ${props => props.theme.colors.primary.main};
        background: rgba(195, 134, 91, 0.1);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      }
      
      &::after {
        content: '📍';
        position: absolute;
        top: 50%;
        right: -25px;
        transform: translateY(-50%);
        opacity: 0;
        transition: all ${props => props.theme.transitions.normal};
      }
      
      &:hover::after {
        opacity: 1;
        right: -30px;
      }
    }
  }
`;

const HorariosSection = styled.section`
  max-width: 1200px;
  margin: 0 auto;
  padding: ${props => props.theme.spacing.xxl} 20px;
  text-align: center;
  background: ${props => props.theme.colors.background.primary};
  
  @media (min-width: 1024px) {
    padding: ${props => props.theme.spacing.xxl} 40px;
  }
  
  h2 {
    font-family: ${props => props.theme.typography.fontFamily.heading};
    font-size: 2.5rem;
    font-weight: 400;
    color: #c3865b;
    margin-bottom: ${props => props.theme.spacing.xl};
    text-transform: uppercase;
    letter-spacing: 0.02em;
    
    @media (min-width: ${props => props.theme.breakpoints.tablet}) {
      font-size: 3rem;
    }
  }
  
  p {
    font-family: ${props => props.theme.typography.fontFamily.primary};
    font-size: ${props => props.theme.typography.fontSize.lg};
    font-weight: 400;
    color: ${props => props.theme.colors.text.secondary};
    margin-bottom: ${props => props.theme.spacing.xl};
    line-height: 1.6;
    letter-spacing: -0.01em;
  }
  
  .horarios-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: ${props => props.theme.spacing.lg};
    max-width: 800px;
    margin: 0 auto;
    
    @media (min-width: 768px) {
      grid-template-columns: repeat(2, 1fr);
    }
    
    @media (min-width: 1024px) {
      grid-template-columns: repeat(4, 1fr);
    }
  }
  
  .horario-item {
    background: ${props => props.theme.colors.background.secondary};
    border-radius: ${props => props.theme.borderRadius.lg};
    border: 1px solid rgba(255, 255, 255, 0.1);
    padding: ${props => props.theme.spacing.xl};
    transition: all ${props => props.theme.transitions.normal};
    position: relative;
    overflow: hidden;
    
    &::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: linear-gradient(90deg, #c3865b, #e2a76f);
      transform: scaleX(0);
      transition: transform ${props => props.theme.transitions.normal};
    }
    
    &:hover {
      transform: translateY(-4px);
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.3);
      border-color: rgba(195, 134, 91, 0.3);
      
      &::before {
        transform: scaleX(1);
      }
    }
    
    .dias {
      font-family: ${props => props.theme.typography.fontFamily.heading};
      font-size: ${props => props.theme.typography.fontSize.lg};
      font-weight: 600;
      color: ${props => props.theme.colors.primary.main};
      margin-bottom: ${props => props.theme.spacing.sm};
      text-transform: uppercase;
      letter-spacing: 0.02em;
      
      @media (min-width: ${props => props.theme.breakpoints.tablet}) {
        font-size: ${props => props.theme.typography.fontSize.xl};
      }
    }
    
    .horas {
      font-family: ${props => props.theme.typography.fontFamily.primary};
      font-size: ${props => props.theme.typography.fontSize.md};
      font-weight: 500;
      color: ${props => props.theme.colors.text.primary};
      line-height: 1.4;
      
      @media (min-width: ${props => props.theme.breakpoints.tablet}) {
        font-size: ${props => props.theme.typography.fontSize.lg};
      }
    }
  }
`;

const SocialSection = styled.section`
  max-width: 1200px;
  margin: 0 auto;
  padding: ${props => props.theme.spacing.xxl} 20px;
  text-align: center;
  background: ${props => props.theme.colors.background.primary};
  
  @media (min-width: 1024px) {
    padding: ${props => props.theme.spacing.xxl} 40px;
  }
  
  h2 {
    font-family: ${props => props.theme.typography.fontFamily.heading};
    font-size: 2.5rem;
    font-weight: 400;
    color: #c3865b;
    margin-bottom: ${props => props.theme.spacing.xl};
    text-transform: uppercase;
    letter-spacing: 0.02em;
    
    @media (min-width: ${props => props.theme.breakpoints.tablet}) {
      font-size: 3rem;
    }
  }
  
  .social-links {
    display: flex;
    justify-content: center;
    gap: ${props => props.theme.spacing.xl};
    margin-top: ${props => props.theme.spacing.xl};
    
    @media (max-width: 767px) {
      gap: ${props => props.theme.spacing.lg};
    }
  }
`;

const SocialLink = styled.a`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: ${props => props.theme.colors.background.secondary};
  border: 2px solid rgba(255, 255, 255, 0.1);
  color: ${props => props.theme.colors.text.primary};
  text-decoration: none;
  transition: all ${props => props.theme.transitions.normal};
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border-radius: 50%;
    background: transparent;
    transition: all ${props => props.theme.transitions.normal};
    z-index: 1;
  }
  
  &:hover {
    transform: translateY(-4px) scale(1.1);
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
    border-color: rgba(195, 134, 91, 0.6);
    
    svg {
      transform: scale(1.2);
      z-index: 2;
      position: relative;
    }
  }
  
  &.instagram:hover {
    background: linear-gradient(45deg, #833ab4, #fd1d1d, #fcb045);
    color: white;
    border-color: #fd1d1d;
  }
  
  &.tiktok:hover {
    background: linear-gradient(45deg, #000000, #ff0050);
    color: white;
    border-color: #ff0050;
  }
  
  svg {
    font-size: 2rem;
    transition: transform ${props => props.theme.transitions.normal};
    
    @media (max-width: 767px) {
      font-size: 1.5rem;
    }
  }
  
  @media (max-width: 767px) {
    width: 60px;
    height: 60px;
  }
`;

const AvisoImportanteSection = styled.section`
  max-width: 1200px;
  margin: 0 auto;
  padding: ${props => props.theme.spacing.xxl} 20px;
  background: ${props => props.theme.colors.background.primary};
  
  @media (min-width: 1024px) {
    padding: ${props => props.theme.spacing.xxl} 40px;
  }
  
  h2 {
    font-family: ${props => props.theme.typography.fontFamily.heading};
    font-size: 2.5rem;
    font-weight: 400;
    color: #c3865b;
    margin-bottom: ${props => props.theme.spacing.xl};
    text-transform: uppercase;
    letter-spacing: 0.02em;
    text-align: center;
    
    @media (min-width: ${props => props.theme.breakpoints.tablet}) {
      font-size: 3rem;
    }
  }
  
  .aviso-container {
    max-width: 800px;
    margin: 0 auto;
    background: ${props => props.theme.colors.background.secondary};
    border-radius: ${props => props.theme.borderRadius.lg};
    border: 2px solid rgba(195, 134, 91, 0.3);
    padding: ${props => props.theme.spacing.xl};
    position: relative;
    overflow: hidden;
    
    &::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(90deg, #c3865b, #e2a76f);
    }
    
    .warning-icon {
      display: flex;
      justify-content: center;
      margin-bottom: ${props => props.theme.spacing.lg};
      font-size: 3rem;
      
      &::before {
        content: '⚠️';
      }
    }
    
    h3 {
      font-family: ${props => props.theme.typography.fontFamily.heading};
      font-size: ${props => props.theme.typography.fontSize.xl};
      font-weight: 600;
      color: ${props => props.theme.colors.primary.main};
      margin-bottom: ${props => props.theme.spacing.lg};
      text-align: center;
      text-transform: uppercase;
      letter-spacing: 0.01em;
      
      @media (min-width: ${props => props.theme.breakpoints.tablet}) {
        font-size: 1.5rem;
      }
    }
    
    .aviso-content {
      font-family: ${props => props.theme.typography.fontFamily.primary};
      font-size: ${props => props.theme.typography.fontSize.md};
      color: ${props => props.theme.colors.text.secondary};
      line-height: 1.7;
      letter-spacing: -0.01em;
      text-align: justify;
      
      @media (min-width: ${props => props.theme.breakpoints.tablet}) {
        font-size: ${props => props.theme.typography.fontSize.lg};
      }
      
      p {
        margin-bottom: ${props => props.theme.spacing.md};
        
        &:last-child {
          margin-bottom: 0;
        }
      }
      
      .highlight {
        color: ${props => props.theme.colors.primary.main};
        font-weight: 600;
      }
    }
  }
`;



export const HomePage: React.FC = () => {
  // Initialize rooms data
  useRooms();

  // Get room context for active room
  const { state } = useRoom();
  const { activeRoom } = state;

  // Modal states
  const [isReservationModalOpen, setIsReservationModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);

  // FAQ states
  const [openFAQIndex, setOpenFAQIndex] = useState<number | null>(null);

  const faqData = [
    {
      question: "¿Desde qué edad pueden hacerlo?",
      answer: "12 años en adelante."
    },
    {
      question: "¿Hay un mínimo de participantes?",
      answer: "Sí, dos hasta un máximo de 7 personas."
    },
    {
      question: "¿Qué es un Escape Room?",
      answer: "Un juego de aventura donde resuelves acertijos y enigmas para escapar de una habitación temática."
    }
  ];

  const handleReserveClick = (roomId?: number) => {
    setIsReservationModalOpen(true);
  };

  const handleReservationModalClose = () => {
    setIsReservationModalOpen(false);
  };

  const handleDetailClick = (roomId?: number) => {
    setIsDetailModalOpen(true);
  };

  const handleDetailModalClose = () => {
    setIsDetailModalOpen(false);
  };

  const handleVideoClick = (roomId?: number) => {
    setIsVideoModalOpen(true);
  };

  const handleVideoModalClose = () => {
    setIsVideoModalOpen(false);
  };

  const toggleFAQ = (index: number) => {
    setOpenFAQIndex(openFAQIndex === index ? null : index);
  };

  return (
    <HomeContainer>
      <section id="rooms">
        <RoomsSection
          onReserveClick={handleReserveClick}
          onDetailClick={handleDetailClick}
          onVideoClick={handleVideoClick}
        />
      </section>

      <FAQSection id="faq">
        <h2>Preguntas Frecuentes</h2>
        <div className="faq-container">
          {faqData.map((faq, index) => (
            <FAQItem key={index}>
              <FAQQuestion onClick={() => toggleFAQ(index)}>
                <h3>{faq.question}</h3>
                <span className={`icon ${openFAQIndex === index ? 'open' : ''}`}>+</span>
              </FAQQuestion>
              <FAQAnswer isOpen={openFAQIndex === index}>
                <div className="answer-content">
                  <p>{faq.answer}</p>
                </div>
              </FAQAnswer>
            </FAQItem>
          ))}
        </div>
      </FAQSection>

      <ContactSection id="contact">
        <h2>Contacto</h2>
        <p>¿Listo para vivir una experiencia única? ¡Contáctanos!</p>

        <div className="contact-info">
          <div className="contact-item">
            <h3>Teléfono</h3>
            <p>+507 6616-0986</p>
          </div>
          <div className="contact-item">
            <h3>Email</h3>
            <p>escaperooms21pty@gmail.com</p>
          </div>
          <div className="contact-item">
            <h3>Dirección</h3>
            <a
              href="https://maps.google.com/?q=Towncenter+Costa+del+Este,+Torre+Norte,+Piso+M3,+Kart+21,+Panama"
              target="_blank"
              rel="noopener noreferrer"
              className="address-link"
            >
              Town Center Costa del Este<br />Torre Norte, Piso M3<br />En Kart 21
            </a>
          </div>
        </div>
      </ContactSection>

      <HorariosSection id="horarios">
        <h2>Horarios</h2>
        <p>Estamos abiertos para que vivas la aventura</p>

        <div className="horarios-grid">
          <div className="horario-item">
            <div className="dias">Lunes - Jueves</div>
            <div className="horas">12:00 PM - 9:00 PM</div>
          </div>
          <div className="horario-item">
            <div className="dias">Viernes</div>
            <div className="horas">12:00 PM - 10:00 PM</div>
          </div>
          <div className="horario-item">
            <div className="dias">Sábado</div>
            <div className="horas">10:00 AM - 10:00 PM</div>
          </div>
          <div className="horario-item">
            <div className="dias">Domingo</div>
            <div className="horas">10:00 AM - 9:00 PM</div>
          </div>
        </div>
      </HorariosSection>

      <SocialSection id="social">
        <h2>Síguenos en nuestras redes</h2>
        <div className="social-links">
          <SocialLink
            href="https://www.instagram.com/escaperooms21?igsh=bTc2aGxzN2M2MHVw&utm_source=qr"
            target="_blank"
            rel="noopener noreferrer"
            className="instagram"
            aria-label="Síguenos en Instagram"
          >
            <FontAwesomeIcon icon={faInstagram} />
          </SocialLink>
          <SocialLink
            href="https://www.tiktok.com/@escaperooms21"
            target="_blank"
            rel="noopener noreferrer"
            className="tiktok"
            aria-label="Síguenos en TikTok"
          >
            <FontAwesomeIcon icon={faTiktok} />
          </SocialLink>
        </div>
      </SocialSection>

      <AvisoImportanteSection id="aviso-importante">
        <div className="aviso-container">
          <div className="warning-icon"></div>
          <h3>Aviso importante sobre tu seguridad</h3>
          <div className="aviso-content">
            <p>
              Queremos que disfrutes al máximo de tu experiencia en nuestro escape room.
              Sin embargo, te recordamos que se trata de una <span className="highlight">actividad inmersiva</span> que
              puede generar emociones intensas, tensión o sobresaltos.
            </p>
            <p>
              Por esta razón, <span className="highlight">no nos hacemos responsables</span> por posibles efectos
              relacionados con condiciones médicas preexistentes, incluyendo 
              problemas cardíacos, crisis nerviosas o situaciones similares que puedan presentarse
              durante la actividad.
            </p>
            <p>
              Si tienes antecedentes de salud que puedan verse afectados por este tipo de experiencias,
              te recomendamos <span className="highlight">consultar con tu médico</span> antes de participar.
              Tu bienestar es muy importante para nosotros.
            </p>
          </div>
        </div>
      </AvisoImportanteSection>

      <DetailModal
        isOpen={isDetailModalOpen}
        onClose={handleDetailModalClose}
        room={activeRoom}
      />

      <ReservationModal
        isOpen={isReservationModalOpen}
        onClose={handleReservationModalClose}
      />

      {activeRoom && (
        <VideoModal
          isOpen={isVideoModalOpen}
          onClose={handleVideoModalClose}
          videoUrl={activeRoom.video_url || "#"}
          roomName={activeRoom.name}
        />
      )}
    </HomeContainer>
  );
};