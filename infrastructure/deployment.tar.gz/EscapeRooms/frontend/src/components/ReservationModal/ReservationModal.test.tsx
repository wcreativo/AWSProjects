import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { ReservationModal } from './ReservationModal';
import { RoomProvider } from '../../contexts/RoomContext';
import { ReservationProvider } from '../../contexts/ReservationContext';
import { ToastProvider } from '../../contexts/ToastContext';
import { theme } from '../../styles/theme';

// Mock the API module to avoid axios import issues
jest.mock('../../services/api', () => ({
  roomsApi: {
    getAvailability: jest.fn().mockResolvedValue(['12:00', '13:00', '14:00']),
  },
  reservationsApi: {
    createReservation: jest.fn().mockResolvedValue({ id: 1, status: 'pending' }),
  },
}));

// Mock room data
const mockRoom = {
  id: 1,
  name: 'La Inquisición',
  slug: 'la-inquisicion',
  short_description: 'Una experiencia medieval llena de misterios',
  full_description: 'Descripción completa del escape room',
  hero_image: '/images/inquisicion-hero.jpg',
  thumbnail_image: '/images/inquisicion-thumb.jpg',
  base_price: 30,
  is_active: true,
};

// Test wrapper component
const TestWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <ThemeProvider theme={theme}>
    <ToastProvider>
      <RoomProvider>
        <ReservationProvider>
          {children}
        </ReservationProvider>
      </RoomProvider>
    </ToastProvider>
  </ThemeProvider>
);

// Mock the useRoom hook to return our mock data
jest.mock('../../contexts/RoomContext', () => ({
  ...jest.requireActual('../../contexts/RoomContext'),
  useRoom: () => ({
    state: {
      rooms: [mockRoom],
      activeRoom: mockRoom,
      loading: false,
      error: null,
    },
    setRooms: jest.fn(),
    setActiveRoom: jest.fn(),
    setLoading: jest.fn(),
    setError: jest.fn(),
  }),
}));

describe('ReservationModal', () => {
  const mockOnClose = jest.fn();

  beforeEach(() => {
    mockOnClose.mockClear();
  });

  it('renders modal when open', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    expect(screen.getByText('Reserva')).toBeInTheDocument();
    expect(screen.getByText('La Inquisición')).toBeInTheDocument();
    expect(screen.getByText('Una experiencia medieval llena de misterios')).toBeInTheDocument();
  });

  it('does not render when closed', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={false} onClose={mockOnClose} />
      </TestWrapper>
    );

    expect(screen.queryByText('Hacer Reserva')).not.toBeInTheDocument();
  });

  it('displays room information correctly', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    expect(screen.getByText('La Inquisición')).toBeInTheDocument();
    expect(screen.getByText('Una experiencia medieval llena de misterios')).toBeInTheDocument();
    expect(screen.getByAltText('La Inquisición')).toBeInTheDocument();
  });

  it('initializes with 1 person and correct price', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    expect(screen.getByText('1')).toBeInTheDocument(); // quantity display
    expect(screen.getByText('$30')).toBeInTheDocument(); // total price
  });

  it('updates quantity and price when using +/- buttons', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const plusButton = screen.getByText('+');
    const minusButton = screen.getByText('−');

    // Increase quantity
    fireEvent.click(plusButton);
    expect(screen.getByText('2')).toBeInTheDocument();
    expect(screen.getByText('$60')).toBeInTheDocument();

    // Increase to 4 people (price should change to $25 per person)
    fireEvent.click(plusButton);
    fireEvent.click(plusButton);
    expect(screen.getByText('4')).toBeInTheDocument();
    expect(screen.getByText('$100')).toBeInTheDocument(); // 4 * $25

    // Decrease quantity
    fireEvent.click(minusButton);
    expect(screen.getByText('3')).toBeInTheDocument();
    expect(screen.getByText('$90')).toBeInTheDocument(); // 3 * $30
  });

  it('disables minus button when quantity is 1', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const minusButton = screen.getByText('−');
    expect(minusButton).toBeDisabled();
  });

  it('disables plus button when quantity reaches 10', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const plusButton = screen.getByText('+');
    
    // Click plus button 9 times to reach 10
    for (let i = 0; i < 9; i++) {
      fireEvent.click(plusButton);
    }

    expect(screen.getByText('10')).toBeInTheDocument();
    expect(plusButton).toBeDisabled();
  });

  it('shows correct price per person for different quantities', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const plusButton = screen.getByText('+');

    // 1-3 people: $30 per person
    expect(screen.getByText('$30 c/u')).toBeInTheDocument();

    fireEvent.click(plusButton);
    expect(screen.getByText('$30 c/u')).toBeInTheDocument();

    fireEvent.click(plusButton);
    expect(screen.getByText('$30 c/u')).toBeInTheDocument();

    // 4+ people: $25 per person
    fireEvent.click(plusButton);
    expect(screen.getByText('$25 c/u')).toBeInTheDocument();
  });

  it('renders all form fields', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    expect(screen.getByLabelText('Nombre completo *')).toBeInTheDocument();
    expect(screen.getByLabelText('Email *')).toBeInTheDocument();
    expect(screen.getByLabelText('Teléfono *')).toBeInTheDocument();
  });

  it('validates required fields on submit', async () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const submitButton = screen.getByText('Reservar');
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText('El nombre es obligatorio')).toBeInTheDocument();
      expect(screen.getByText('El email es obligatorio')).toBeInTheDocument();
      expect(screen.getByText('El teléfono es obligatorio')).toBeInTheDocument();
      // Date and time validation errors should also appear
      expect(screen.getByText('Selecciona una fecha')).toBeInTheDocument();
    });
  });

  it('validates email format', async () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const emailInput = screen.getByLabelText('Email *');
    fireEvent.change(emailInput, { target: { value: 'invalid-email' } });
    fireEvent.blur(emailInput);

    await waitFor(() => {
      expect(screen.getByText('Ingresa un email válido')).toBeInTheDocument();
    });
  });

  it('validates phone format', async () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const phoneInput = screen.getByLabelText('Teléfono *');
    fireEvent.change(phoneInput, { target: { value: '123' } });
    fireEvent.blur(phoneInput);

    await waitFor(() => {
      expect(screen.getByText('Ingresa un teléfono válido')).toBeInTheDocument();
    });
  });

  it('validates name length', async () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const nameInput = screen.getByLabelText('Nombre completo *');
    fireEvent.change(nameInput, { target: { value: 'A' } });
    fireEvent.blur(nameInput);

    await waitFor(() => {
      expect(screen.getByText('El nombre debe tener al menos 2 caracteres')).toBeInTheDocument();
    });
  });

  it('clears validation errors when valid input is entered', async () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const emailInput = screen.getByLabelText('Email *');
    
    // Enter invalid email
    fireEvent.change(emailInput, { target: { value: 'invalid' } });
    fireEvent.blur(emailInput);

    await waitFor(() => {
      expect(screen.getByText('Ingresa un email válido')).toBeInTheDocument();
    });

    // Clear and enter valid email
    fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
    fireEvent.blur(emailInput);

    await waitFor(() => {
      expect(screen.queryByText('Ingresa un email válido')).not.toBeInTheDocument();
    });
  });

  it('displays payment instructions', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    expect(screen.getByText('Instrucciones de Pago')).toBeInTheDocument();
    expect(screen.getByText(/Debe hacer el depósito\/pago de su reserva/)).toBeInTheDocument();
  });

  it('calls onClose when cancel button is clicked', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const cancelButton = screen.getByText('Cancelar');
    fireEvent.click(cancelButton);

    expect(mockOnClose).toHaveBeenCalledTimes(1);
  });

  it('calls onClose when close button (×) is clicked', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const closeButton = screen.getByText('×');
    fireEvent.click(closeButton);

    expect(mockOnClose).toHaveBeenCalledTimes(1);
  });

  it('has proper input modes for mobile keyboards', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const emailInput = screen.getByLabelText('Email *');
    const phoneInput = screen.getByLabelText('Teléfono *');

    expect(emailInput).toHaveAttribute('type', 'email');
    expect(phoneInput).toHaveAttribute('type', 'tel');
  });

  it('updates form data correctly when inputs change', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const nameInput = screen.getByLabelText('Nombre completo *');
    const emailInput = screen.getByLabelText('Email *');
    const phoneInput = screen.getByLabelText('Teléfono *');

    fireEvent.change(nameInput, { target: { value: 'John Doe' } });
    fireEvent.change(emailInput, { target: { value: 'john@example.com' } });
    fireEvent.change(phoneInput, { target: { value: '+1234567890' } });

    expect(nameInput).toHaveValue('John Doe');
    expect(emailInput).toHaveValue('john@example.com');
    expect(phoneInput).toHaveValue('+1234567890');
  });

  it('prevents form submission with invalid data', () => {
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
    
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    const submitButton = screen.getByText('Reservar');
    fireEvent.click(submitButton);

    // Should not log submission with invalid data
    expect(consoleSpy).not.toHaveBeenCalledWith(expect.stringContaining('Submitting reservation'));
    
    consoleSpy.mockRestore();
  });

  it('renders date and time selection section', () => {
    render(
      <TestWrapper>
        <ReservationModal isOpen={true} onClose={mockOnClose} />
      </TestWrapper>
    );

    expect(screen.getByText('Selecciona fecha y horario')).toBeInTheDocument();
    expect(screen.getByText('Selecciona la fecha')).toBeInTheDocument();
    expect(screen.getByText('Selecciona el horario')).toBeInTheDocument();
    expect(screen.getByText('Primero selecciona una fecha para ver los horarios disponibles')).toBeInTheDocument();
  });
});