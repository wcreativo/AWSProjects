import React, { useState, useEffect, useCallback } from 'react';
import styled from 'styled-components';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { DateTimePicker } from '../common/DateTimePicker';
import { useRoom } from '../../contexts/RoomContext';
import { useReservation } from '../../contexts/ReservationContext';
import { useReservationSubmit } from '../../hooks/useReservationSubmit';

interface ReservationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ModalContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.lg};
  
  @media (max-width: 767px) {
    gap: ${props => props.theme.spacing.md};
  }
`;

const RoomInfo = styled.div`
  display: flex;
  gap: ${props => props.theme.spacing.md};
  padding: ${props => props.theme.spacing.md};
  background: ${props => props.theme.colors.background.secondary};
  border-radius: ${props => props.theme.borderRadius.lg};
  
  @media (max-width: 767px) {
    flex-direction: column;
    gap: ${props => props.theme.spacing.sm};
  }
`;

const RoomImage = styled.img`
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: ${props => props.theme.borderRadius.md};
  flex-shrink: 0;
  
  @media (max-width: 767px) {
    width: 100%;
    height: 120px;
  }
`;

const RoomDetails = styled.div`
  flex: 1;
`;

const RoomName = styled.h3`
  margin: 0 0 ${props => props.theme.spacing.xs} 0;
  font-size: ${props => props.theme.typography.fontSize.lg};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: ${props => props.theme.colors.text.primary};
`;

const RoomDescription = styled.p`
  margin: 0;
  font-size: ${props => props.theme.typography.fontSize.sm};
  color: ${props => props.theme.colors.text.secondary};
  line-height: ${props => props.theme.typography.lineHeight.normal};
`;

const PricingSection = styled.div`
  padding: ${props => props.theme.spacing.lg};
  background: ${props => props.theme.colors.background.secondary};
  border-radius: ${props => props.theme.borderRadius.lg};
`;

const PricingTitle = styled.h4`
  margin: 0 0 ${props => props.theme.spacing.md} 0;
  font-size: ${props => props.theme.typography.fontSize.md};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: ${props => props.theme.colors.text.primary};
`;

const QuantitySelector = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: ${props => props.theme.spacing.lg};
`;

const QuantityLabel = styled.span`
  font-size: ${props => props.theme.typography.fontSize.md};
  color: ${props => props.theme.colors.text.primary};
  font-weight: ${props => props.theme.typography.fontWeight.medium};
`;

const QuantityControls = styled.div`
  display: flex;
  align-items: center;
  gap: ${props => props.theme.spacing.md};
`;

const QuantityButton = styled.button`
  min-width: 44px;
  min-height: 44px;
  border: 2px solid ${props => props.theme.colors.primary.main};
  background: transparent;
  color: ${props => props.theme.colors.primary.main};
  border-radius: ${props => props.theme.borderRadius.md};
  font-size: ${props => props.theme.typography.fontSize.lg};
  font-weight: ${props => props.theme.typography.fontWeight.bold};
  cursor: pointer;
  transition: all ${props => props.theme.transitions.normal};
  display: flex;
  align-items: center;
  justify-content: center;
  
  &:hover:not(:disabled) {
    background: ${props => props.theme.colors.primary.main};
    color: white;
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  
  &:active {
    transform: scale(0.95);
  }
`;

const QuantityDisplay = styled.span`
  min-width: 40px;
  text-align: center;
  font-size: ${props => props.theme.typography.fontSize.lg};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: ${props => props.theme.colors.text.primary};
`;

const PriceBreakdown = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.sm};
  padding: ${props => props.theme.spacing.md};
  background: ${props => props.theme.colors.background.tertiary};
  border-radius: ${props => props.theme.borderRadius.md};
`;

const PriceRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const PriceLabel = styled.span`
  font-size: ${props => props.theme.typography.fontSize.sm};
  color: ${props => props.theme.colors.text.secondary};
`;

const PriceValue = styled.span`
  font-size: ${props => props.theme.typography.fontSize.sm};
  color: ${props => props.theme.colors.text.primary};
  font-weight: ${props => props.theme.typography.fontWeight.medium};
`;

const TotalPrice = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: ${props => props.theme.spacing.sm};
  border-top: 1px solid ${props => props.theme.colors.background.primary};
  margin-top: ${props => props.theme.spacing.sm};
`;

const TotalLabel = styled.span`
  font-size: ${props => props.theme.typography.fontSize.md};
  color: ${props => props.theme.colors.text.primary};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
`;

const TotalValue = styled.span`
  font-size: ${props => props.theme.typography.fontSize.xl};
  color: ${props => props.theme.colors.primary.main};
  font-weight: ${props => props.theme.typography.fontWeight.bold};
`;

const TaxNote = styled.p`
  font-size: ${props => props.theme.typography.fontSize.xs};
  color: ${props => props.theme.colors.text.tertiary};
  margin: ${props => props.theme.spacing.sm} 0 0 0;
  text-align: center;
  font-style: italic;
`;

const FormSection = styled.form`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.lg};
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.sm};
`;

const FormLabel = styled.label`
  font-size: ${props => props.theme.typography.fontSize.sm};
  color: ${props => props.theme.colors.text.primary};
  font-weight: ${props => props.theme.typography.fontWeight.medium};
`;

const FormInput = styled.input<{ $hasError?: boolean }>`
  min-height: 44px;
  padding: 12px 16px;
  border: 2px solid ${props => props.$hasError ? props.theme.colors.error : 'rgba(255, 255, 255, 0.2)'};
  background: ${props => props.theme.colors.background.tertiary};
  color: ${props => props.theme.colors.text.primary};
  border-radius: ${props => props.theme.borderRadius.md};
  font-size: ${props => props.theme.typography.fontSize.md};
  transition: all ${props => props.theme.transitions.normal};
  
  &::placeholder {
    color: ${props => props.theme.colors.text.tertiary};
  }
  
  &:focus {
    outline: none;
    border-color: ${props => props.$hasError ? props.theme.colors.error : props.theme.colors.primary.main};
    box-shadow: 0 0 0 3px ${props => props.$hasError ? 'rgba(255, 59, 48, 0.1)' : 'rgba(0, 122, 255, 0.1)'};
  }
  
  /* Mobile keyboard optimization */
  &[type="email"] {
    input-mode: email;
  }
  
  &[type="tel"] {
    input-mode: tel;
  }
`;

const ErrorMessage = styled.span`
  font-size: ${props => props.theme.typography.fontSize.xs};
  color: ${props => props.theme.colors.error};
  margin-top: ${props => props.theme.spacing.xs};
`;

const PaymentInstructions = styled.div`
  padding: ${props => props.theme.spacing.lg};
  background: ${props => props.theme.colors.warning}20;
  border: 1px solid ${props => props.theme.colors.warning};
  border-radius: ${props => props.theme.borderRadius.lg};
  margin-top: ${props => props.theme.spacing.lg};
`;

const InstructionsTitle = styled.h4`
  margin: 0 0 ${props => props.theme.spacing.md} 0;
  font-size: ${props => props.theme.typography.fontSize.md};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: ${props => props.theme.colors.warning};
`;

const InstructionsText = styled.p`
  margin: 0 0 ${props => props.theme.spacing.md} 0;
  font-size: ${props => props.theme.typography.fontSize.sm};
  color: ${props => props.theme.colors.text.primary};
  line-height: ${props => props.theme.typography.lineHeight.normal};
`;

const BankingInfo = styled.div`
  background: ${props => props.theme.colors.background.secondary};
  border-radius: ${props => props.theme.borderRadius.md};
  padding: ${props => props.theme.spacing.md};
  margin-top: ${props => props.theme.spacing.md};
`;

const BankingTitle = styled.h5`
  margin: 0 0 ${props => props.theme.spacing.sm} 0;
  font-size: ${props => props.theme.typography.fontSize.sm};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: ${props => props.theme.colors.primary.main};
  text-transform: uppercase;
  letter-spacing: 0.5px;
`;

const BankingDetails = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.xs};
`;

const BankingRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${props => props.theme.spacing.xs} 0;
  
  @media (max-width: 767px) {
    flex-direction: column;
    align-items: flex-start;
    gap: ${props => props.theme.spacing.xs};
  }
`;

const BankingLabel = styled.span`
  font-size: ${props => props.theme.typography.fontSize.xs};
  color: ${props => props.theme.colors.text.secondary};
  font-weight: ${props => props.theme.typography.fontWeight.medium};
  text-transform: uppercase;
  letter-spacing: 0.5px;
  min-width: 80px;
`;

const BankingValue = styled.span`
  font-size: ${props => props.theme.typography.fontSize.sm};
  color: ${props => props.theme.colors.text.primary};
  font-weight: ${props => props.theme.typography.fontWeight.medium};
  font-family: monospace;
  background: rgba(255, 255, 255, 0.05);
  padding: ${props => props.theme.spacing.xs};
  border-radius: ${props => props.theme.borderRadius.sm};
  border: 1px solid rgba(255, 255, 255, 0.1);
`;

const DateTimeSection = styled.div`
  padding: ${props => props.theme.spacing.lg};
  background: ${props => props.theme.colors.background.secondary};
  border-radius: ${props => props.theme.borderRadius.lg};
`;

const DateTimeSectionTitle = styled.h4`
  margin: 0 0 ${props => props.theme.spacing.md} 0;
  font-size: ${props => props.theme.typography.fontSize.md};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: ${props => props.theme.colors.text.primary};
`;

const ButtonGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.md};
  margin-top: ${props => props.theme.spacing.xl};
  
  @media (min-width: ${props => props.theme.breakpoints.tablet}) {
    flex-direction: row;
    justify-content: flex-end;
  }
`;

const SuccessMessage = styled.div`
  padding: ${props => props.theme.spacing.lg};
  background: rgba(52, 199, 89, 0.1);
  border: 1px solid rgba(52, 199, 89, 0.3);
  border-radius: ${props => props.theme.borderRadius.lg};
  margin-top: ${props => props.theme.spacing.lg};
  text-align: center;
`;

const SuccessTitle = styled.h4`
  margin: 0 0 ${props => props.theme.spacing.sm} 0;
  font-size: ${props => props.theme.typography.fontSize.md};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: rgba(52, 199, 89, 1);
`;

const SuccessText = styled.p`
  margin: 0;
  font-size: ${props => props.theme.typography.fontSize.sm};
  color: ${props => props.theme.colors.text.primary};
  line-height: ${props => props.theme.typography.lineHeight.normal};
`;

const LoadingIndicator = styled.div`
  display: inline-flex;
  align-items: center;
  gap: ${props => props.theme.spacing.sm};
`;

const Spinner = styled.div`
  width: 16px;
  height: 16px;
  border: 2px solid transparent;
  border-top: 2px solid currentColor;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;

interface FormErrors {
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  date?: string;
  time?: string;
}

export const ReservationModal: React.FC<ReservationModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { state: roomState } = useRoom();
  const { state: reservationState, updateFormData, calculatePrice } = useReservation();
  const { submitReservation, isSubmitting } = useReservationSubmit();
  const { activeRoom } = roomState;
  const { formData } = reservationState;
  
  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  // Initialize form data when modal opens
  useEffect(() => {
    if (isOpen && activeRoom) {
      updateFormData({
        roomId: activeRoom.id,
        numPeople: 2,
        totalPrice: calculatePrice(2),
      });
      setShowSuccessMessage(false);
    }
  }, [isOpen, activeRoom]);

  // Reset success message when modal closes
  useEffect(() => {
    if (!isOpen) {
      setShowSuccessMessage(false);
    }
  }, [isOpen]);

  const validateField = (field: string, value: string): string | undefined => {
    switch (field) {
      case 'customerName':
        if (!value.trim()) return 'El nombre es obligatorio';
        if (value.trim().length < 2) return 'El nombre debe tener al menos 2 caracteres';
        return undefined;
      
      case 'customerEmail':
        if (!value.trim()) return 'El email es obligatorio';
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) return 'Ingresa un email válido';
        return undefined;
      
      case 'customerPhone':
        if (!value.trim()) return 'El teléfono es obligatorio';
        const phoneRegex = /^[\d\s\-+()]{8,}$/;
        if (!phoneRegex.test(value)) return 'Ingresa un teléfono válido';
        return undefined;
      
      case 'date':
        if (!value.trim()) return 'Selecciona una fecha';
        return validateDateTime(value, formData.time);
      
      case 'time':
        if (!value.trim()) return 'Selecciona un horario';
        return validateDateTime(formData.date, value);
      
      default:
        return undefined;
    }
  };

  const validateDateTime = (dateValue: string, timeValue: string): string | undefined => {
    if (!dateValue.trim()) return undefined; // Let date validation handle empty date
    if (!timeValue.trim()) return undefined; // Let time validation handle empty time
    
    // Parse the selected date (input format is YYYY-MM-DD)
    const selectedDate = new Date(dateValue + 'T00:00:00');
    const today = new Date();
    
    // Compare dates only (ignore time for date comparison)
    const selectedDateOnly = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate());
    const todayDateOnly = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    
    // If it's a past date, reject
    if (selectedDateOnly < todayDateOnly) {
      return 'La fecha debe ser hoy o posterior';
    }
    
    // If it's today, check if the time is in the future
    const isToday = selectedDateOnly.getTime() === todayDateOnly.getTime();
    if (isToday) {
      const [hours, minutes] = timeValue.split(':').map(Number);
      
      // Create datetime for selected time today
      const selectedDateTime = new Date();
      selectedDateTime.setHours(hours, minutes, 0, 0);
      
      const now = new Date();
      // Add 1 hour buffer for preparation time
      const minimumTime = new Date(now.getTime() + 60 * 60 * 1000);
      
      if (selectedDateTime < minimumTime) {
        return 'Para reservas de hoy, selecciona un horario con al menos 1 hora de anticipación';
      }
    }
    
    return undefined;
  };

  const handleInputChange = (field: string, value: string) => {
    const newFormData = { ...formData, [field]: value };
    updateFormData({ [field]: value });
    
    // Validate field if it has been touched
    if (touched[field]) {
      const error = validateField(field, value);
      setErrors(prev => ({
        ...prev,
        [field]: error,
      }));
      
      // If changing date or time, also revalidate the other field to update combined validation
      if (field === 'date' && touched.time && newFormData.time) {
        const timeError = validateDateTime(value, newFormData.time);
        setErrors(prev => ({
          ...prev,
          time: timeError,
        }));
      } else if (field === 'time' && touched.date && newFormData.date) {
        const dateError = validateDateTime(newFormData.date, value);
        setErrors(prev => ({
          ...prev,
          date: dateError,
        }));
      }
    }
  };

  const handleInputBlur = (field: string, value: string) => {
    setTouched(prev => ({ ...prev, [field]: true }));
    const error = validateField(field, value);
    setErrors(prev => ({
      ...prev,
      [field]: error,
    }));
  };

  const handleQuantityChange = (delta: number) => {
    const newQuantity = Math.max(2, Math.min(7, formData.numPeople + delta));
    const newTotal = calculatePrice(newQuantity);
    updateFormData({ 
      numPeople: newQuantity,
      totalPrice: newTotal
    });
  };

  const handleDateChange = useCallback((date: string) => {
    updateFormData({ date });
    // Clear time when date changes
    updateFormData({ time: '' });
    
    // Validate date if it has been touched
    if (touched.date) {
      const error = validateField('date', date);
      setErrors(prev => ({
        ...prev,
        date: error,
      }));
    }
  }, []); // Remove dependencies to prevent re-creation

  const handleTimeChange = useCallback((time: string) => {
    updateFormData({ time });
    
    // Validate time if it has been touched
    if (touched.time) {
      const error = validateField('time', time);
      setErrors(prev => ({
        ...prev,
        time: error,
      }));
    }
  }, []); // Remove dependencies to prevent re-creation

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate all fields
    const newErrors: FormErrors = {};
    
    // Validate basic fields first
    const basicFields = ['customerName', 'customerEmail', 'customerPhone'];
    basicFields.forEach(field => {
      const value = formData[field as keyof typeof formData] as string;
      const error = validateField(field, value);
      if (error) {
        newErrors[field as keyof FormErrors] = error;
      }
    });

    // Validate date and time separately for individual field errors
    if (!formData.date.trim()) {
      newErrors.date = 'Selecciona una fecha';
    }
    if (!formData.time.trim()) {
      newErrors.time = 'Selecciona un horario';
    }

    // If both date and time are provided, validate them together
    if (formData.date.trim() && formData.time.trim()) {
      const dateTimeError = validateDateTime(formData.date, formData.time);
      if (dateTimeError) {
        // Show the error on the date field since it's more relevant
        newErrors.date = dateTimeError;
      }
    }

    setErrors(newErrors);
    setTouched({
      date: true,
      time: true,
      customerName: true,
      customerEmail: true,
      customerPhone: true,
    });

    // If no errors, proceed with submission
    if (Object.keys(newErrors).length === 0) {
      const success = await submitReservation();
      if (success) {
        setShowSuccessMessage(true);
        // Close modal after showing success message briefly
        setTimeout(() => {
          setShowSuccessMessage(false);
          onClose();
        }, 3000);
      }
    }
  };

  const pricePerPerson = formData.numPeople <= 3 ? 30 : 25;
  const subtotal = formData.numPeople * pricePerPerson;
  const tax = subtotal * 0.07;
  const totalPrice = calculatePrice(formData.numPeople);

  if (!activeRoom) {
    return null;
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Reserva" isReservation={true}>
      <ModalContent>
        {/* Room Information */}
        <RoomInfo>
          <RoomImage 
            src={activeRoom.thumbnail_image || activeRoom.hero_image} 
            alt={activeRoom.name}
          />
          <RoomDetails>
            <RoomName>{activeRoom.name}</RoomName>
            <RoomDescription>{activeRoom.short_description}</RoomDescription>
          </RoomDetails>
        </RoomInfo>

        {/* Pricing Section */}
        <PricingSection>
          <PricingTitle>Selecciona la cantidad de personas</PricingTitle>
          
          <QuantitySelector>
            <QuantityLabel>Cantidad de personas:</QuantityLabel>
            <QuantityControls>
              <QuantityButton
                type="button"
                onClick={() => handleQuantityChange(-1)}
                disabled={formData.numPeople <= 2}
              >
                −
              </QuantityButton>
              <QuantityDisplay>{formData.numPeople}</QuantityDisplay>
              <QuantityButton
                type="button"
                onClick={() => handleQuantityChange(1)}
                disabled={formData.numPeople >= 7}
              >
                +
              </QuantityButton>
            </QuantityControls>
          </QuantitySelector>

          <PriceBreakdown>
            <PriceRow>
              <PriceLabel>{formData.numPeople} persona{formData.numPeople > 1 ? 's' : ''}</PriceLabel>
              <PriceValue>${pricePerPerson} c/u</PriceValue>
            </PriceRow>
            <PriceRow>
              <PriceLabel>Subtotal:</PriceLabel>
              <PriceValue>${subtotal.toFixed(2)}</PriceValue>
            </PriceRow>
            <PriceRow>
              <PriceLabel>Impuesto 7%:</PriceLabel>
              <PriceValue>${tax.toFixed(2)}</PriceValue>
            </PriceRow>
            <TotalPrice>
              <TotalLabel>Total:</TotalLabel>
              <TotalValue>${totalPrice.toFixed(2)}</TotalValue>
            </TotalPrice>
          </PriceBreakdown>
          <TaxNote>* Precios incluyen el ITBMS</TaxNote>
        </PricingSection>

        {/* Date and Time Selection */}
        <DateTimeSection>
          <DateTimeSectionTitle>Selecciona fecha y horario</DateTimeSectionTitle>
          <DateTimePicker
            roomId={formData.roomId}
            selectedDate={formData.date}
            selectedTime={formData.time}
            onDateChange={handleDateChange}
            onTimeChange={handleTimeChange}
            error={errors.date || errors.time}
          />
        </DateTimeSection>

        {/* Contact Form */}
        <FormSection onSubmit={handleSubmit}>
          <FormGroup>
            <FormLabel htmlFor="customerName">Nombre completo *</FormLabel>
            <FormInput
              id="customerName"
              type="text"
              placeholder="Ingresa tu nombre completo"
              value={formData.customerName}
              onChange={(e) => handleInputChange('customerName', e.target.value)}
              onBlur={(e) => handleInputBlur('customerName', e.target.value)}
              $hasError={!!errors.customerName}
            />
            {errors.customerName && <ErrorMessage>{errors.customerName}</ErrorMessage>}
          </FormGroup>

          <FormGroup>
            <FormLabel htmlFor="customerEmail">Email *</FormLabel>
            <FormInput
              id="customerEmail"
              type="email"
              placeholder="tu@email.com"
              value={formData.customerEmail}
              onChange={(e) => handleInputChange('customerEmail', e.target.value)}
              onBlur={(e) => handleInputBlur('customerEmail', e.target.value)}
              $hasError={!!errors.customerEmail}
            />
            {errors.customerEmail && <ErrorMessage>{errors.customerEmail}</ErrorMessage>}
          </FormGroup>

          <FormGroup>
            <FormLabel htmlFor="customerPhone">Teléfono *</FormLabel>
            <FormInput
              id="customerPhone"
              type="tel"
              placeholder="+1 234 567 8900"
              value={formData.customerPhone}
              onChange={(e) => handleInputChange('customerPhone', e.target.value)}
              onBlur={(e) => handleInputBlur('customerPhone', e.target.value)}
              $hasError={!!errors.customerPhone}
            />
            {errors.customerPhone && <ErrorMessage>{errors.customerPhone}</ErrorMessage>}
          </FormGroup>

          {/* Payment Instructions */}
          <PaymentInstructions>
            <InstructionsTitle>Instrucciones de Pago</InstructionsTitle>
            <InstructionsText>
              Debe hacer el depósito/pago de su reserva y enviar el comprobante al email/whatsapp 
              en los próximos 30 minutos de lo contrario el sistema cancelará automáticamente su reserva.
            </InstructionsText>
            
            <BankingInfo>
              <BankingTitle>Información Bancaria</BankingTitle>
              <BankingDetails>
                <BankingRow>
                  <BankingLabel>Banco:</BankingLabel>
                  <BankingValue>Banco General</BankingValue>
                </BankingRow>
                <BankingRow>
                  <BankingLabel>Tipo:</BankingLabel>
                  <BankingValue>Cuenta Corriente</BankingValue>
                </BankingRow>
                <BankingRow>
                  <BankingLabel>Número:</BankingLabel>
                  <BankingValue>03-27-01-150080-4</BankingValue>
                </BankingRow>
                <BankingRow>
                  <BankingLabel>Titular:</BankingLabel>
                  <BankingValue>Kart 21 S.A</BankingValue>
                </BankingRow>
              </BankingDetails>
            </BankingInfo>
          </PaymentInstructions>

          {showSuccessMessage && (
            <SuccessMessage>
              <SuccessTitle>¡Reserva Creada Exitosamente!</SuccessTitle>
              <SuccessText>
                Tu reserva ha sido confirmada. Recuerda enviar el comprobante de pago 
                en los próximos 30 minutos para asegurar tu lugar.
              </SuccessText>
            </SuccessMessage>
          )}

          <ButtonGroup>
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              fullWidth
              disabled={isSubmitting}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              variant="primary"
              fullWidth
              disabled={isSubmitting || showSuccessMessage}
            >
              {isSubmitting ? (
                <LoadingIndicator>
                  <Spinner />
                  Procesando...
                </LoadingIndicator>
              ) : showSuccessMessage ? (
                '¡Reserva Confirmada!'
              ) : (
                'Reservar'
              )}
            </Button>
          </ButtonGroup>
        </FormSection>
      </ModalContent>
    </Modal>
  );
};