import React from 'react';
import { render, screen } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { theme } from '../../../styles';
import { ToastContainer } from './ToastContainer';
import { ToastMessage } from '../../../types';

const renderWithTheme = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('ToastContainer', () => {
  const mockOnRemoveToast = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  const createToast = (overrides: Partial<ToastMessage> = {}): ToastMessage => ({
    id: 'test-toast',
    type: 'info',
    message: 'Test message',
    ...overrides,
  });

  it('renders nothing when no toasts', () => {
    const { container } = renderWithTheme(
      <ToastContainer toasts={[]} onRemoveToast={mockOnRemoveToast} />
    );
    
    expect(container.firstChild).toBeNull();
  });

  it('renders single toast', () => {
    const toast = createToast({ message: 'Single toast' });
    renderWithTheme(
      <ToastContainer toasts={[toast]} onRemoveToast={mockOnRemoveToast} />
    );
    
    expect(screen.getByText('Single toast')).toBeInTheDocument();
  });

  it('renders multiple toasts', () => {
    const toasts = [
      createToast({ id: '1', message: 'First toast' }),
      createToast({ id: '2', message: 'Second toast' }),
      createToast({ id: '3', message: 'Third toast' }),
    ];
    
    renderWithTheme(
      <ToastContainer toasts={toasts} onRemoveToast={mockOnRemoveToast} />
    );
    
    expect(screen.getByText('First toast')).toBeInTheDocument();
    expect(screen.getByText('Second toast')).toBeInTheDocument();
    expect(screen.getByText('Third toast')).toBeInTheDocument();
  });

  it('renders toasts with different types', () => {
    const toasts = [
      createToast({ id: '1', type: 'success', message: 'Success toast' }),
      createToast({ id: '2', type: 'error', message: 'Error toast' }),
      createToast({ id: '3', type: 'warning', message: 'Warning toast' }),
    ];
    
    renderWithTheme(
      <ToastContainer toasts={toasts} onRemoveToast={mockOnRemoveToast} />
    );
    
    expect(screen.getByText('Success toast')).toBeInTheDocument();
    expect(screen.getByText('Error toast')).toBeInTheDocument();
    expect(screen.getByText('Warning toast')).toBeInTheDocument();
  });
});