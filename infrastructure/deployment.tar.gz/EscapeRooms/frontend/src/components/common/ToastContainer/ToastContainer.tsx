import React from 'react';
import styled from 'styled-components';
import { Toast } from '../Toast';
import { ToastMessage } from '../../../types';

interface ToastContainerProps {
  toasts: ToastMessage[];
  onRemoveToast: (id: string) => void;
}

const Container = styled.div`
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: ${props => props.theme.zIndex.toast};
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  pointer-events: none;
  
  @media (max-width: 767px) {
    top: 10px;
    right: 0;
    left: 0;
    align-items: center;
  }
  
  > * {
    pointer-events: auto;
  }
`;

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onRemoveToast }) => {
  if (toasts.length === 0) {
    return null;
  }

  return (
    <Container>
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          toast={toast}
          onRemove={onRemoveToast}
        />
      ))}
    </Container>
  );
};