import React, { useEffect } from 'react';
import styled from 'styled-components';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: string;
  isReservation?: boolean;
}

const ModalOverlay = styled.div.withConfig({
  shouldForwardProp: (prop) => !['isOpen'].includes(prop),
})<{ isOpen: boolean }>`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: ${props => props.isOpen ? 'flex' : 'none'};
  align-items: center;
  justify-content: center;
  z-index: 1000;
  opacity: ${props => props.isOpen ? 1 : 0};
  visibility: ${props => props.isOpen ? 'visible' : 'hidden'};
  transition: all 0.3s ease;
  padding: 0;
  backdrop-filter: blur(4px);
`;

const ModalContent = styled.div.withConfig({
  shouldForwardProp: (prop) => !['isOpen'].includes(prop),
})<{ isOpen: boolean }>`
  background: ${props => props.theme.colors.background.primary};
  border-radius: 16px;
  width: 100%;
  height: 100%;
  max-height: 100vh;
  overflow-y: auto;
  position: relative;
  transform: ${props => props.isOpen ? 'translateY(0)' : 'translateY(100%)'};
  transition: transform 0.3s ease;
  
  /* Hide scrollbar but keep functionality */
  scrollbar-width: none; /* Firefox */
  -ms-overflow-style: none; /* IE and Edge */
  &::-webkit-scrollbar {
    display: none; /* Chrome, Safari, Opera */
  }
  
  /* Mobile: rounded corners on all sides */
  @media (max-width: 767px) {
    border-radius: 16px;
    margin: 16px;
    width: calc(100% - 32px);
    height: calc(100% - 32px);
    max-height: calc(100vh - 32px);
  }
  
  /* Tablet and up: Centered modal */
  @media (min-width: 768px) {
    width: 90%;
    max-width: 600px;
    height: auto;
    max-height: 90vh;
    border-radius: 20px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(20px);
    background: ${props => props.theme.colors.background.primary};
    transform: ${props => props.isOpen ? 'scale(1)' : 'scale(0.9)'};
  }
`;

const ModalHeader = styled.div`
  padding: 20px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 16px 16px 0 0;
  position: relative;
  
  @media (max-width: 767px) {
    padding: 16px;
    border-radius: 16px 16px 0 0;
  }
  
  @media (min-width: 768px) {
    border-radius: 20px 20px 0 0;
  }
`;

const ModalTitle = styled.h2<{ $isReservation?: boolean }>`
  margin: 0;
  font-family: ${props => props.theme.typography.fontFamily.heading};
  font-size: 28px;
  font-weight: 400;
  color: ${props => props.$isReservation ? props.theme.colors.primary.main : props.theme.colors.text.primary};
  text-transform: uppercase;
  letter-spacing: 0.02em;
  
  @media (max-width: 767px) {
    font-size: 24px;
  }
  
  @media (min-width: 768px) {
    font-size: 32px;
  }
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  padding: 4px;
  min-width: 44px;
  min-height: 44px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: background-color 0.2s ease;
  color: ${props => props.theme.colors.text.secondary};
  position: absolute;
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
  
  &:hover {
    background-color: rgba(255, 255, 255, 0.1);
    color: ${props => props.theme.colors.text.primary};
  }
  
  @media (max-width: 767px) {
    right: 16px;
  }
`;

const ModalBody = styled.div`
  padding: 20px;
  
  @media (max-width: 767px) {
    padding: 16px;
  }
`;

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, children, title, isReservation = false }) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen, onClose]);

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen) {
    return null;
  }

  return (
    <ModalOverlay isOpen={isOpen} onClick={handleOverlayClick}>
      <ModalContent isOpen={isOpen}>
        {title && (
          <ModalHeader>
            <ModalTitle $isReservation={isReservation}>{title}</ModalTitle>
            <CloseButton type="button" onClick={onClose}>×</CloseButton>
          </ModalHeader>
        )}
        <ModalBody>{children}</ModalBody>
      </ModalContent>
    </ModalOverlay>
  );
};