import React, { useEffect } from 'react';
import styled, { keyframes } from 'styled-components';
import { ToastMessage } from '../../../types';

interface ToastProps {
  toast: ToastMessage;
  onRemove: (id: string) => void;
}

const slideIn = keyframes`
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
`;

const slideOut = keyframes`
  from {
    transform: translateX(0);
    opacity: 1;
  }
  to {
    transform: translateX(100%);
    opacity: 0;
  }
`;

const ToastContainer = styled.div<{ $type: ToastMessage['type']; $isRemoving?: boolean }>`
  position: relative;
  min-width: 300px;
  max-width: 500px;
  padding: ${props => props.theme.spacing.md} ${props => props.theme.spacing.lg};
  margin-bottom: ${props => props.theme.spacing.sm};
  border-radius: ${props => props.theme.borderRadius.lg};
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(10px);
  animation: ${props => props.$isRemoving ? slideOut : slideIn} 0.3s ease-out;
  
  background: ${props => {
    switch (props.$type) {
      case 'success':
        return 'rgba(52, 199, 89, 0.9)';
      case 'error':
        return 'rgba(255, 59, 48, 0.9)';
      case 'warning':
        return 'rgba(255, 149, 0, 0.9)';
      case 'info':
        return 'rgba(0, 122, 255, 0.9)';
      default:
        return 'rgba(0, 122, 255, 0.9)';
    }
  }};
  
  border: 1px solid ${props => {
    switch (props.$type) {
      case 'success':
        return 'rgba(52, 199, 89, 0.3)';
      case 'error':
        return 'rgba(255, 59, 48, 0.3)';
      case 'warning':
        return 'rgba(255, 149, 0, 0.3)';
      case 'info':
        return 'rgba(0, 122, 255, 0.3)';
      default:
        return 'rgba(0, 122, 255, 0.3)';
    }
  }};
  
  @media (max-width: 767px) {
    min-width: calc(100vw - 32px);
    max-width: calc(100vw - 32px);
    margin: 0 16px ${props => props.theme.spacing.sm} 16px;
  }
`;

const ToastContent = styled.div`
  display: flex;
  align-items: flex-start;
  gap: ${props => props.theme.spacing.sm};
`;

const ToastIcon = styled.div<{ $type: ToastMessage['type'] }>`
  flex-shrink: 0;
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  
  &::before {
    content: ${props => {
      switch (props.$type) {
        case 'success':
          return '"✓"';
        case 'error':
          return '"✕"';
        case 'warning':
          return '"⚠"';
        case 'info':
          return '"ℹ"';
        default:
          return '"ℹ"';
      }
    }};
    color: white;
    font-weight: bold;
  }
`;

const ToastText = styled.div`
  flex: 1;
  color: white;
  font-size: ${props => props.theme.typography.fontSize.sm};
  font-weight: ${props => props.theme.typography.fontWeight.medium};
  line-height: ${props => props.theme.typography.lineHeight.normal};
`;

const CloseButton = styled.button`
  flex-shrink: 0;
  width: 20px;
  height: 20px;
  border: none;
  background: transparent;
  color: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: background-color 0.2s ease;
  
  &:hover {
    background-color: rgba(255, 255, 255, 0.2);
  }
  
  &::before {
    content: "×";
    font-size: 18px;
    font-weight: bold;
  }
`;

export const Toast: React.FC<ToastProps> = ({ toast, onRemove }) => {
  useEffect(() => {
    const duration = toast.duration || 5000;
    const timer = setTimeout(() => {
      onRemove(toast.id);
    }, duration);

    return () => clearTimeout(timer);
  }, [toast.id, toast.duration, onRemove]);

  return (
    <ToastContainer $type={toast.type}>
      <ToastContent>
        <ToastIcon $type={toast.type} />
        <ToastText>{toast.message}</ToastText>
        <CloseButton onClick={() => onRemove(toast.id)} />
      </ToastContent>
    </ToastContainer>
  );
};