import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { theme } from '../../../styles';
import { Toast } from './Toast';
import { ToastMessage } from '../../../types';

const renderWithTheme = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('Toast', () => {
  const mockOnRemove = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  const createToast = (overrides: Partial<ToastMessage> = {}): ToastMessage => ({
    id: 'test-toast',
    type: 'info',
    message: 'Test message',
    duration: 5000,
    ...overrides,
  });

  it('renders toast with correct message', () => {
    const toast = createToast({ message: 'Test notification' });
    renderWithTheme(<Toast toast={toast} onRemove={mockOnRemove} />);
    
    expect(screen.getByText('Test notification')).toBeInTheDocument();
  });

  it('renders correct icon for each toast type', () => {
    const types: ToastMessage['type'][] = ['success', 'error', 'warning', 'info'];
    
    types.forEach((type) => {
      const toast = createToast({ type, id: `test-${type}` });
      const { unmount } = renderWithTheme(<Toast toast={toast} onRemove={mockOnRemove} />);
      
      // Check that the toast container has the correct type styling
      const toastContainer = screen.getByText(toast.message).closest('div');
      expect(toastContainer).toBeInTheDocument();
      
      unmount();
    });
  });

  it('calls onRemove when close button is clicked', () => {
    const toast = createToast();
    renderWithTheme(<Toast toast={toast} onRemove={mockOnRemove} />);
    
    const closeButton = screen.getByRole('button');
    fireEvent.click(closeButton);
    
    expect(mockOnRemove).toHaveBeenCalledWith('test-toast');
  });

  it('auto-removes toast after duration', async () => {
    const toast = createToast({ duration: 1000 });
    renderWithTheme(<Toast toast={toast} onRemove={mockOnRemove} />);
    
    expect(mockOnRemove).not.toHaveBeenCalled();
    
    jest.advanceTimersByTime(1000);
    
    await waitFor(() => {
      expect(mockOnRemove).toHaveBeenCalledWith('test-toast');
    });
  });

  it('uses default duration when not specified', async () => {
    const toast = createToast({ duration: undefined });
    renderWithTheme(<Toast toast={toast} onRemove={mockOnRemove} />);
    
    jest.advanceTimersByTime(4999);
    expect(mockOnRemove).not.toHaveBeenCalled();
    
    jest.advanceTimersByTime(1);
    
    await waitFor(() => {
      expect(mockOnRemove).toHaveBeenCalledWith('test-toast');
    });
  });

  it('clears timeout when component unmounts', () => {
    const toast = createToast({ duration: 1000 });
    const { unmount } = renderWithTheme(<Toast toast={toast} onRemove={mockOnRemove} />);
    
    unmount();
    jest.advanceTimersByTime(1000);
    
    expect(mockOnRemove).not.toHaveBeenCalled();
  });
});