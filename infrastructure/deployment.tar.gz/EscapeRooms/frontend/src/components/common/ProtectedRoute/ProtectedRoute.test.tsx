import React from 'react';
import { render, screen } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { ProtectedRoute } from './ProtectedRoute';
import { AdminProvider } from '../../../contexts/AdminContext';
import { theme } from '../../../styles';

// Mock the LoginForm component
jest.mock('../../admin/LoginForm', () => ({
  LoginForm: () => <div data-testid="login-form">Login Form</div>,
}));

const renderWithProviders = (children: React.ReactNode) => {
  return render(
    <ThemeProvider theme={theme}>
      <AdminProvider>
        <ProtectedRoute>
          {children}
        </ProtectedRoute>
      </AdminProvider>
    </ThemeProvider>
  );
};

describe('ProtectedRoute', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('should show login form when user is not authenticated', () => {
    renderWithProviders(
      <div data-testid="protected-content">Protected Content</div>
    );
    
    expect(screen.getByTestId('login-form')).toBeInTheDocument();
    expect(screen.queryByTestId('protected-content')).not.toBeInTheDocument();
  });

  it('should show protected content when user is authenticated', () => {
    // Set up authenticated state
    localStorage.setItem('authToken', 'fake-token');
    localStorage.setItem('adminUsername', 'admin');
    
    renderWithProviders(
      <div data-testid="protected-content">Protected Content</div>
    );
    
    expect(screen.getByTestId('protected-content')).toBeInTheDocument();
    expect(screen.queryByTestId('login-form')).not.toBeInTheDocument();
  });

  it('should render multiple children when authenticated', () => {
    localStorage.setItem('authToken', 'fake-token');
    localStorage.setItem('adminUsername', 'admin');
    
    renderWithProviders(
      <>
        <div data-testid="child-1">Child 1</div>
        <div data-testid="child-2">Child 2</div>
      </>
    );
    
    expect(screen.getByTestId('child-1')).toBeInTheDocument();
    expect(screen.getByTestId('child-2')).toBeInTheDocument();
  });
});