import React from 'react';
import { useAdmin } from '../../../contexts/AdminContext';
import { LoginForm } from '../../admin/LoginForm';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { state } = useAdmin();

  if (!state.user?.isAuthenticated) {
    return <LoginForm />;
  }

  return <>{children}</>;
};