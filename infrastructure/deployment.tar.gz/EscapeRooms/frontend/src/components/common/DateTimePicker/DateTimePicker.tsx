import React, { useState, useEffect, useRef } from 'react';
import styled from 'styled-components';
import { roomsApi } from '../../../services/api';

interface DateTimePickerProps {
  roomId: number | null;
  selectedDate: string;
  selectedTime: string;
  onDateChange: (date: string) => void;
  onTimeChange: (time: string) => void;
  error?: string;
}

const Container = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.lg};
`;

const Section = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.sm};
`;

const SectionTitle = styled.h4`
  margin: 0;
  font-size: ${props => props.theme.typography.fontSize.md};
  font-weight: ${props => props.theme.typography.fontWeight.semibold};
  color: ${props => props.theme.colors.text.primary};
`;

const DateInput = styled.input<{ $hasError?: boolean }>`
  min-height: 44px;
  padding: 12px 16px;
  border: 2px solid ${props => props.$hasError ? props.theme.colors.error : 'rgba(255, 255, 255, 0.2)'};
  background: ${props => props.theme.colors.background.tertiary};
  color: ${props => props.theme.colors.text.primary};
  border-radius: ${props => props.theme.borderRadius.md};
  font-size: ${props => props.theme.typography.fontSize.md};
  transition: all ${props => props.theme.transitions.normal};
  
  &:focus {
    outline: none;
    border-color: ${props => props.$hasError ? props.theme.colors.error : props.theme.colors.primary.main};
    box-shadow: 0 0 0 3px ${props => props.$hasError ? 'rgba(255, 59, 48, 0.1)' : 'rgba(0, 122, 255, 0.1)'};
  }
  
  /* Style the date picker */
  &::-webkit-calendar-picker-indicator {
    filter: invert(1);
    cursor: pointer;
  }
`;

const TimeSlotGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
  gap: ${props => props.theme.spacing.sm};
  
  @media (max-width: 767px) {
    grid-template-columns: repeat(3, 1fr);
  }
`;

const TimeSlotButton = styled.button<{ $isSelected?: boolean; $isDisabled?: boolean }>`
  min-height: 44px;
  padding: 8px 12px;
  border: 2px solid ${props => {
    if (props.$isSelected) return props.theme.colors.primary.main;
    if (props.$isDisabled) return 'rgba(255, 255, 255, 0.1)';
    return 'rgba(255, 255, 255, 0.2)';
  }};
  background: ${props => {
    if (props.$isSelected) return props.theme.colors.primary.main;
    if (props.$isDisabled) return 'rgba(255, 255, 255, 0.05)';
    return props.theme.colors.background.tertiary;
  }};
  color: ${props => {
    if (props.$isSelected) return 'white';
    if (props.$isDisabled) return props.theme.colors.text.tertiary;
    return props.theme.colors.text.primary;
  }};
  border-radius: ${props => props.theme.borderRadius.md};
  font-size: ${props => props.theme.typography.fontSize.sm};
  font-weight: ${props => props.theme.typography.fontWeight.medium};
  cursor: ${props => props.$isDisabled ? 'not-allowed' : 'pointer'};
  transition: all ${props => props.theme.transitions.normal};
  
  &:hover:not(:disabled) {
    background: ${props => props.$isSelected ? props.theme.colors.primary.main : 'rgba(255, 255, 255, 0.1)'};
    border-color: ${props => props.$isSelected ? props.theme.colors.primary.main : 'rgba(255, 255, 255, 0.3)'};
  }
  
  &:active:not(:disabled) {
    transform: scale(0.95);
  }
`;

const LoadingMessage = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100px;
  color: ${props => props.theme.colors.text.secondary};
  font-size: ${props => props.theme.typography.fontSize.sm};
`;

const ErrorMessage = styled.div`
  color: ${props => props.theme.colors.error};
  font-size: ${props => props.theme.typography.fontSize.sm};
  text-align: center;
  padding: ${props => props.theme.spacing.md};
  background: rgba(255, 59, 48, 0.1);
  border-radius: ${props => props.theme.borderRadius.md};
`;

const NoSlotsMessage = styled.div`
  color: ${props => props.theme.colors.text.secondary};
  font-size: ${props => props.theme.typography.fontSize.sm};
  text-align: center;
  padding: ${props => props.theme.spacing.lg};
  background: ${props => props.theme.colors.background.secondary};
  border-radius: ${props => props.theme.borderRadius.md};
`;

// Helper function to get day of week
const getDayOfWeek = (dateString: string): number => {
  const date = new Date(dateString);
  return date.getDay(); // 0 = Sunday, 1 = Monday, etc.
};

// Helper function to get schedule for a day
const getScheduleForDay = (dayOfWeek: number): string[] => {
  switch (dayOfWeek) {
    case 1: // Monday
    case 2: // Tuesday
    case 3: // Wednesday
    case 4: // Thursday
      return ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00'];
    case 5: // Friday
      return ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00'];
    case 6: // Saturday
      return ['10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00'];
    case 0: // Sunday
      return ['10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00'];
    default:
      return [];
  }
};

// Helper function to format time for display
const formatTimeForDisplay = (time: string): string => {
  const [hours, minutes] = time.split(':');
  const hour = parseInt(hours);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
  return `${displayHour}:${minutes} ${ampm}`;
};

// Helper function to get minimum date (today)
const getMinDate = (): string => {
  const today = new Date();
  return today.toISOString().split('T')[0];
};

export const DateTimePicker: React.FC<DateTimePickerProps> = ({
  roomId,
  selectedDate,
  selectedTime,
  onDateChange,
  onTimeChange,
  error,
}) => {
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const onTimeChangeRef = useRef(onTimeChange);

  // Fetch available slots when date or room changes
  useEffect(() => {
    const fetchAvailability = async () => {
      if (!roomId || !selectedDate) {
        setAvailableSlots([]);
        return;
      }

      setIsLoading(true);
      setFetchError(null);

      try {
        const slots = await roomsApi.getAvailability(roomId, selectedDate);
        setAvailableSlots(slots);
        
        // Clear selected time if it's no longer available
        if (selectedTime && !slots.includes(selectedTime)) {
          onTimeChangeRef.current('');
        }
      } catch (err) {
        console.error('Error fetching availability:', err);
        setFetchError('Error al cargar horarios disponibles');
        setAvailableSlots([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAvailability();
  }, [roomId, selectedDate, selectedTime]); // Include selectedTime but handle clearing inside the effect

  // Update the ref when onTimeChange changes
  useEffect(() => {
    onTimeChangeRef.current = onTimeChange;
  }, [onTimeChange]);

  // Get all possible slots for the selected date based on schedule
  const getAllSlotsForDate = (date: string): string[] => {
    if (!date) return [];
    const dayOfWeek = getDayOfWeek(date);
    return getScheduleForDay(dayOfWeek);
  };

  const allSlots = getAllSlotsForDate(selectedDate);

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newDate = e.target.value;
    onDateChange(newDate);
    // Clear selected time when date changes
    onTimeChange('');
  };

  const handleTimeSelect = (time: string) => {
    if (availableSlots.includes(time)) {
      onTimeChange(time);
    }
  };

  return (
    <Container>
      {/* Date Selection */}
      <Section>
        <SectionTitle>Selecciona la fecha</SectionTitle>
        <DateInput
          type="date"
          value={selectedDate}
          onChange={handleDateChange}
          min={getMinDate()}
          $hasError={!!error}
        />
      </Section>

      {/* Time Selection */}
      <Section>
        <SectionTitle>Selecciona el horario</SectionTitle>
        
        {!selectedDate && (
          <NoSlotsMessage>
            Primero selecciona una fecha para ver los horarios disponibles
          </NoSlotsMessage>
        )}
        
        {selectedDate && isLoading && (
          <LoadingMessage>
            Cargando horarios disponibles...
          </LoadingMessage>
        )}
        
        {selectedDate && fetchError && (
          <ErrorMessage>
            {fetchError}
          </ErrorMessage>
        )}
        
        {selectedDate && !isLoading && !fetchError && allSlots.length === 0 && (
          <NoSlotsMessage>
            No hay horarios disponibles para este día
          </NoSlotsMessage>
        )}
        
        {selectedDate && !isLoading && !fetchError && allSlots.length > 0 && (
          <TimeSlotGrid>
            {allSlots.map((time) => {
              const isAvailable = availableSlots && availableSlots.includes(time);
              const isSelected = selectedTime === time;
              
              return (
                <TimeSlotButton
                  key={time}
                  type="button"
                  onClick={() => handleTimeSelect(time)}
                  $isSelected={isSelected}
                  $isDisabled={!isAvailable}
                  disabled={!isAvailable}
                >
                  {formatTimeForDisplay(time)}
                </TimeSlotButton>
              );
            })}
          </TimeSlotGrid>
        )}
        
        {selectedDate && !isLoading && !fetchError && availableSlots.length === 0 && allSlots.length > 0 && (
          <NoSlotsMessage>
            No hay horarios disponibles para esta fecha
          </NoSlotsMessage>
        )}
      </Section>
      
      {error && (
        <ErrorMessage>
          {error}
        </ErrorMessage>
      )}
    </Container>
  );
};