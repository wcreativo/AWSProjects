import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { DateTimePicker } from './DateTimePicker';
import { theme } from '../../../styles/theme';

// Mock the API module
jest.mock('../../../services/api', () => ({
  roomsApi: {
    getAvailability: jest.fn(),
  },
}));

// Import the mocked API after mocking
import { roomsApi } from '../../../services/api';

const renderWithTheme = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('DateTimePicker', () => {
  const mockProps = {
    roomId: 1,
    selectedDate: '',
    selectedTime: '',
    onDateChange: jest.fn(),
    onTimeChange: jest.fn(),
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders date and time selection sections', () => {
    renderWithTheme(<DateTimePicker {...mockProps} />);
    
    expect(screen.getByText('Selecciona la fecha')).toBeInTheDocument();
    expect(screen.getByText('Selecciona el horario')).toBeInTheDocument();
    expect(screen.getByDisplayValue('')).toBeInTheDocument(); // Date input
  });

  it('shows message when no date is selected', () => {
    renderWithTheme(<DateTimePicker {...mockProps} />);
    
    expect(screen.getByText('Primero selecciona una fecha para ver los horarios disponibles')).toBeInTheDocument();
  });

  it('calls onDateChange when date is selected', () => {
    renderWithTheme(<DateTimePicker {...mockProps} />);
    
    const dateInput = screen.getByDisplayValue('');
    fireEvent.change(dateInput, { target: { value: '2024-12-25' } });
    
    expect(mockProps.onDateChange).toHaveBeenCalledWith('2024-12-25');
  });

  it('fetches and displays available time slots when date is selected', async () => {
    const mockSlots = ['12:00', '13:00', '14:00', '15:00'];
    (roomsApi.getAvailability as jest.Mock).mockResolvedValue(mockSlots);

    renderWithTheme(
      <DateTimePicker 
        {...mockProps} 
        selectedDate="2024-12-25" 
      />
    );

    // Should show loading initially
    expect(screen.getByText('Cargando horarios disponibles...')).toBeInTheDocument();

    // Wait for slots to load
    await waitFor(() => {
      expect(screen.getByText('12:00 PM')).toBeInTheDocument();
    });

    expect(screen.getByText('1:00 PM')).toBeInTheDocument();
    expect(screen.getByText('2:00 PM')).toBeInTheDocument();
    expect(screen.getByText('3:00 PM')).toBeInTheDocument();
  });

  it('calls onTimeChange when time slot is selected', async () => {
    const mockSlots = ['12:00', '13:00'];
    (roomsApi.getAvailability as jest.Mock).mockResolvedValue(mockSlots);

    renderWithTheme(
      <DateTimePicker 
        {...mockProps} 
        selectedDate="2024-12-25" 
      />
    );

    await waitFor(() => {
      expect(screen.getByText('12:00 PM')).toBeInTheDocument();
    });

    const timeButton = screen.getByText('12:00 PM');
    fireEvent.click(timeButton);

    expect(mockProps.onTimeChange).toHaveBeenCalledWith('12:00');
  });

  it('shows selected time slot as active', async () => {
    const mockSlots = ['12:00', '13:00'];
    (roomsApi.getAvailability as jest.Mock).mockResolvedValue(mockSlots);

    renderWithTheme(
      <DateTimePicker 
        {...mockProps} 
        selectedDate="2024-12-25"
        selectedTime="12:00"
      />
    );

    await waitFor(() => {
      const selectedButton = screen.getByText('12:00 PM');
      expect(selectedButton).toHaveStyle('background: rgb(227, 40, 39)'); // Primary color
    });
  });

  it('disables unavailable time slots', async () => {
    // Mock schedule shows all slots for Wednesday, but API returns only some available
    const mockSlots = ['12:00', '15:00']; // Missing 13:00, 14:00
    (roomsApi.getAvailability as jest.Mock).mockResolvedValue(mockSlots);

    renderWithTheme(
      <DateTimePicker 
        {...mockProps} 
        selectedDate="2024-12-25" // Wednesday
      />
    );

    await waitFor(() => {
      expect(screen.getByText('12:00 PM')).toBeInTheDocument();
    });

    // Available slots should be clickable
    const availableButton = screen.getByText('12:00 PM');
    expect(availableButton).not.toBeDisabled();

    // Unavailable slots should be disabled
    const unavailableButton = screen.getByText('1:00 PM');
    expect(unavailableButton).toBeDisabled();
  });

  it('shows error message when API fails', async () => {
    (roomsApi.getAvailability as jest.Mock).mockRejectedValue(new Error('API Error'));

    renderWithTheme(
      <DateTimePicker 
        {...mockProps} 
        selectedDate="2024-12-25" 
      />
    );

    await waitFor(() => {
      expect(screen.getByText('Error al cargar horarios disponibles')).toBeInTheDocument();
    });
  });

  it('shows different schedules for different days of week', async () => {
    // Saturday schedule includes 10:00 AM slot, but we need to mock it as available
    const mockSlots = ['10:00', '11:00', '12:00']; // Saturday schedule starts at 10:00
    (roomsApi.getAvailability as jest.Mock).mockResolvedValue(mockSlots);

    renderWithTheme(
      <DateTimePicker 
        {...mockProps} 
        selectedDate="2024-12-29" // Saturday (Dec 29, 2024)
      />
    );

    await waitFor(() => {
      // Check that Saturday schedule shows 10:00 AM (which is available)
      expect(screen.getByText('10:00 AM')).toBeInTheDocument();
      // Also check that Saturday includes 22:00 (10 PM) slot
      expect(screen.getByText('10:00 PM')).toBeInTheDocument();
    });
  });

  it('displays error prop when provided', () => {
    renderWithTheme(
      <DateTimePicker 
        {...mockProps} 
        error="Selecciona una fecha válida"
      />
    );

    expect(screen.getByText('Selecciona una fecha válida')).toBeInTheDocument();
  });

  it('clears selected time when date changes and time is no longer available', async () => {
    const mockSlots = ['14:00', '15:00']; // Different slots for new date
    (roomsApi.getAvailability as jest.Mock).mockResolvedValue(mockSlots);

    renderWithTheme(
      <DateTimePicker 
        {...mockProps} 
        selectedDate="2024-12-25"
        selectedTime="12:00" // This time won't be available in new date
      />
    );

    await waitFor(() => {
      expect(mockProps.onTimeChange).toHaveBeenCalledWith('');
    });
  });

  it('formats time display correctly', async () => {
    const mockSlots = ['12:00', '15:00', '18:00', '21:00'];
    (roomsApi.getAvailability as jest.Mock).mockResolvedValue(mockSlots);

    renderWithTheme(
      <DateTimePicker 
        {...mockProps} 
        selectedDate="2024-12-25" // Wednesday - schedule starts at 12:00
      />
    );

    await waitFor(() => {
      expect(screen.getByText('12:00 PM')).toBeInTheDocument();
      expect(screen.getByText('3:00 PM')).toBeInTheDocument();
      expect(screen.getByText('6:00 PM')).toBeInTheDocument();
      expect(screen.getByText('9:00 PM')).toBeInTheDocument();
    });
  });

  it('sets minimum date to today', () => {
    renderWithTheme(<DateTimePicker {...mockProps} />);
    
    const dateInput = screen.getByDisplayValue('') as HTMLInputElement;
    const today = new Date().toISOString().split('T')[0];
    
    expect(dateInput.min).toBe(today);
  });
});