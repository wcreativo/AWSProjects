import React from 'react';
import { render, screen } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { 
  Loading, 
  SkeletonText, 
  SkeletonCard, 
  SkeletonButton, 
  SkeletonAvatar 
} from './Loading';
import { theme } from '../../../styles/theme';

const renderWithTheme = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('Loading Component', () => {
  it('renders spinner variant by default', () => {
    const { container } = renderWithTheme(<Loading />);
    expect(container.firstChild).toBeInTheDocument();
  });

  it('renders with loading text when provided', () => {
    renderWithTheme(<Loading text="Loading..." />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('renders dots variant correctly', () => {
    const { container } = renderWithTheme(<Loading variant="dots" text="Please wait" />);
    expect(screen.getByText('Please wait')).toBeInTheDocument();
    expect(container.firstChild).toBeInTheDocument();
  });

  it('renders skeleton variant correctly', () => {
    const { container } = renderWithTheme(<Loading variant="skeleton" />);
    expect(container.firstChild).toBeInTheDocument();
  });

  it('renders different spinner sizes', () => {
    const { container, rerender } = renderWithTheme(<Loading size="small" />);
    expect(container.firstChild).toBeInTheDocument();

    rerender(
      <ThemeProvider theme={theme}>
        <Loading size="large" />
      </ThemeProvider>
    );
    expect(container.firstChild).toBeInTheDocument();
  });
});

describe('SkeletonText Component', () => {
  it('renders with default props', () => {
    const { container } = renderWithTheme(<SkeletonText />);
    expect(container.firstChild).toBeInTheDocument();
  });

  it('renders with custom width and height', () => {
    const { container } = renderWithTheme(<SkeletonText width="200px" height="24px" />);
    expect(container.firstChild).toBeInTheDocument();
  });
});

describe('SkeletonCard Component', () => {
  it('renders skeleton card with multiple elements', () => {
    const { container } = renderWithTheme(<SkeletonCard />);
    expect(container.firstChild).toBeInTheDocument();
  });
});

describe('SkeletonButton Component', () => {
  it('renders skeleton button with correct dimensions', () => {
    const { container } = renderWithTheme(<SkeletonButton />);
    expect(container.firstChild).toBeInTheDocument();
  });
});

describe('SkeletonAvatar Component', () => {
  it('renders with default size', () => {
    const { container } = renderWithTheme(<SkeletonAvatar />);
    expect(container.firstChild).toBeInTheDocument();
  });

  it('renders with custom size', () => {
    const { container } = renderWithTheme(<SkeletonAvatar size={60} />);
    expect(container.firstChild).toBeInTheDocument();
  });
});

describe('Loading Animations', () => {
  it('applies shimmer animation to skeleton elements', () => {
    const { container } = renderWithTheme(<SkeletonText />);
    expect(container.firstChild).toBeInTheDocument();
    // Animation is applied via CSS, so we just verify the element exists
  });

  it('applies spin animation to spinner', () => {
    const { container } = renderWithTheme(<Loading variant="spinner" />);
    expect(container.firstChild).toBeInTheDocument();
    // Animation is applied via CSS, so we just verify the element exists
  });

  it('applies bounce animation to dots', () => {
    const { container } = renderWithTheme(<Loading variant="dots" />);
    expect(container.firstChild).toBeInTheDocument();
  });
});