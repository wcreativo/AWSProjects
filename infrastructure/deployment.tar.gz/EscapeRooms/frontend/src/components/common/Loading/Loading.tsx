import React from 'react';
import styled, { keyframes } from 'styled-components';

interface LoadingProps {
  variant?: 'spinner' | 'skeleton' | 'dots';
  size?: 'small' | 'medium' | 'large';
  text?: string;
}

interface SkeletonProps {
  width?: string;
  height?: string;
  borderRadius?: string;
}

// Animations
const spin = keyframes`
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
`;

const shimmer = keyframes`
  0% { background-position: -200px 0; }
  100% { background-position: calc(200px + 100%) 0; }
`;

const bounce = keyframes`
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
`;

// Spinner Component
const SpinnerContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: ${({ theme }) => theme.spacing.md};
`;

const Spinner = styled.div.withConfig({
  shouldForwardProp: (prop) => !['size'].includes(prop),
})<{ size: string }>`
  border: 3px solid rgba(255, 255, 255, 0.1);
  border-top: 3px solid ${({ theme }) => theme.colors.primary.main};
  border-radius: 50%;
  animation: ${spin} 1s linear infinite;
  
  ${props => props.size === 'small' && `
    width: 20px;
    height: 20px;
    border-width: 2px;
  `}
  
  ${props => props.size === 'medium' && `
    width: 40px;
    height: 40px;
  `}
  
  ${props => props.size === 'large' && `
    width: 60px;
    height: 60px;
    border-width: 4px;
  `}
`;

const LoadingText = styled.p`
  color: ${({ theme }) => theme.colors.text.secondary};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  margin: 0;
`;

// Skeleton Component
const SkeletonElement = styled.div.withConfig({
  shouldForwardProp: (prop) => !['width', 'height', 'borderRadius'].includes(prop),
})<SkeletonProps>`
  background: linear-gradient(
    90deg,
    ${({ theme }) => theme.colors.background.secondary} 0%,
    ${({ theme }) => theme.colors.background.tertiary} 50%,
    ${({ theme }) => theme.colors.background.secondary} 100%
  );
  background-size: 200px 100%;
  animation: ${shimmer} 1.5s ease-in-out infinite;
  border-radius: ${props => props.borderRadius || '4px'};
  width: ${props => props.width || '100%'};
  height: ${props => props.height || '20px'};
`;

// Dots Component
const DotsContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
`;

const Dot = styled.div.withConfig({
  shouldForwardProp: (prop) => !['delay'].includes(prop),
})<{ delay: number }>`
  width: 8px;
  height: 8px;
  background: ${({ theme }) => theme.colors.primary.main};
  border-radius: 50%;
  animation: ${bounce} 1.4s ease-in-out infinite both;
  animation-delay: ${props => props.delay}s;
`;

// Skeleton Variants
export const SkeletonText: React.FC<SkeletonProps> = ({ width = '100%', height = '16px', ...props }) => (
  <SkeletonElement width={width} height={height} borderRadius="4px" {...props} />
);

export const SkeletonCard: React.FC = () => (
  <div style={{ padding: '16px' }}>
    <SkeletonElement width="100%" height="200px" borderRadius="12px" />
    <div style={{ marginTop: '12px' }}>
      <SkeletonText width="80%" height="20px" />
      <div style={{ marginTop: '8px' }}>
        <SkeletonText width="60%" height="16px" />
      </div>
      <div style={{ marginTop: '8px' }}>
        <SkeletonText width="40%" height="16px" />
      </div>
    </div>
  </div>
);

export const SkeletonButton: React.FC = () => (
  <SkeletonElement width="120px" height="44px" borderRadius="8px" />
);

export const SkeletonAvatar: React.FC<{ size?: number }> = ({ size = 40 }) => (
  <SkeletonElement 
    width={`${size}px`} 
    height={`${size}px`} 
    borderRadius="50%" 
  />
);

// Main Loading Component
export const Loading: React.FC<LoadingProps> = ({ 
  variant = 'spinner', 
  size = 'medium', 
  text 
}) => {
  if (variant === 'skeleton') {
    return <SkeletonCard />;
  }
  
  if (variant === 'dots') {
    return (
      <SpinnerContainer>
        <DotsContainer>
          <Dot delay={0} />
          <Dot delay={0.1} />
          <Dot delay={0.2} />
        </DotsContainer>
        {text && <LoadingText>{text}</LoadingText>}
      </SpinnerContainer>
    );
  }
  
  return (
    <SpinnerContainer>
      <Spinner size={size} />
      {text && <LoadingText>{text}</LoadingText>}
    </SpinnerContainer>
  );
};