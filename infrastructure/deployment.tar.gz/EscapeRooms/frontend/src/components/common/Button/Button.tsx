import React from 'react';
import styled from 'styled-components';

interface ButtonProps {
  variant?: 'primary' | 'secondary';
  size?: 'small' | 'medium' | 'large';
  fullWidth?: boolean;
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
}

const StyledButton = styled.button.withConfig({
  shouldForwardProp: (prop) => !['variant', 'size', 'fullWidth'].includes(prop),
})<ButtonProps>`
  /* Ultra-subtle Apple-style sizing with rounded borders */
  min-height: 32px;
  padding: 6px 16px;
  border-radius: 50px;
  font-weight: 400;
  font-size: 14px;
  border: none;
  cursor: pointer;
  transition: all 0.15s ease;
  width: ${props => props.fullWidth ? '100%' : 'auto'};
  font-family: ${props => props.theme.typography.fontFamily.primary};
  letter-spacing: -0.01em;
  font-weight: 500;
  
  /* Primary variant - Minimal red */
  ${props => props.variant === 'primary' && `
    background: #e32827;
    color: white;
    border: 1px solid #e32827;
    
    &:hover:not(:disabled) {
      background: #c41e1d;
      border-color: #c41e1d;
    }
    
    &:active {
      background: #a01817;
    }
  `}
  
  /* Secondary variant - Minimal red border */
  ${props => props.variant === 'secondary' && `
    border: 1px solid #e32827;
    background: transparent;
    color: white;
    
    &:hover:not(:disabled) {
      background: rgba(227, 40, 39, 0.08);
      border-color: #c41e1d;
    }
    
    &:active {
      background: rgba(227, 40, 39, 0.15);
    }
  `}
  
  /* Size variants - Apple-minimal with rounded borders */
  ${props => props.size === 'small' && `
    min-height: 28px;
    padding: 4px 12px;
    font-size: 12px;
    border-radius: 50px;
  `}
  
  ${props => props.size === 'large' && `
    min-height: 36px;
    padding: 8px 20px;
    font-size: 15px;
    border-radius: 50px;
    font-weight: 500;
  `}
  
  &:disabled {
    opacity: 0.3;
    cursor: not-allowed;
  }
  
  /* Focus styles */
  &:focus-visible {
    outline: 2px solid rgba(227, 40, 39, 0.4);
    outline-offset: 1px;
  }
  
  /* Desktop - Keep it minimal */
  @media (min-width: 768px) {
    min-height: ${props => props.size === 'small' ? '30px' : props.size === 'large' ? '40px' : '34px'};
    padding: ${props => props.size === 'small' ? '5px 14px' : props.size === 'large' ? '10px 24px' : '7px 18px'};
    font-size: ${props => props.size === 'small' ? '13px' : props.size === 'large' ? '16px' : '15px'};
  }
`;

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'medium',
  fullWidth = false,
  children,
  onClick,
  disabled = false,
  type = 'button',
  ...props
}) => {
  return (
    <StyledButton
      variant={variant}
      size={size}
      fullWidth={fullWidth}
      onClick={onClick}
      disabled={disabled}
      type={type}
      {...props}
    >
      {children}
    </StyledButton>
  );
};