import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { ThemeProvider } from 'styled-components';
import { Button } from './Button';
import { theme } from '../../../styles/theme';

const renderWithTheme = (component: React.ReactElement) => {
  return render(
    <ThemeProvider theme={theme}>
      {component}
    </ThemeProvider>
  );
};

describe('Button Component', () => {
  it('renders with default props', () => {
    renderWithTheme(<Button>Click me</Button>);
    const button = screen.getByRole('button', { name: /click me/i });
    expect(button).toBeInTheDocument();
  });

  it('renders primary variant by default', () => {
    renderWithTheme(<Button>Primary Button</Button>);
    const button = screen.getByRole('button');
    expect(button).toHaveStyle('background: #e32827');
  });

  it('renders secondary variant correctly', () => {
    renderWithTheme(<Button variant="secondary">Secondary Button</Button>);
    const button = screen.getByRole('button');
    expect(button).toHaveStyle('border: 1px solid #e32827');
  });

  it('handles click events', () => {
    const handleClick = jest.fn();
    renderWithTheme(<Button onClick={handleClick}>Click me</Button>);
    
    const button = screen.getByRole('button');
    fireEvent.click(button);
    
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('is disabled when disabled prop is true', () => {
    const handleClick = jest.fn();
    renderWithTheme(
      <Button disabled onClick={handleClick}>
        Disabled Button
      </Button>
    );
    
    const button = screen.getByRole('button');
    expect(button).toBeDisabled();
    
    fireEvent.click(button);
    expect(handleClick).not.toHaveBeenCalled();
  });

  it('renders full width when fullWidth prop is true', () => {
    renderWithTheme(<Button fullWidth>Full Width Button</Button>);
    const button = screen.getByRole('button');
    expect(button).toHaveStyle('width: 100%');
  });

  it('renders different sizes correctly', () => {
    const { rerender } = renderWithTheme(<Button size="small">Small</Button>);
    let button = screen.getByRole('button');
    expect(button).toHaveStyle('min-height: 28px');

    rerender(
      <ThemeProvider theme={theme}>
        <Button size="large">Large</Button>
      </ThemeProvider>
    );
    button = screen.getByRole('button');
    expect(button).toHaveStyle('min-height: 36px');
  });

  it('has minimum touch target size of 44px', () => {
    renderWithTheme(<Button>Touch Target</Button>);
    const button = screen.getByRole('button');
    expect(button).toHaveStyle('min-height: 32px');
  });

  it('supports different button types', () => {
    renderWithTheme(<Button type="submit">Submit</Button>);
    const button = screen.getByRole('button');
    expect(button).toHaveAttribute('type', 'submit');
  });

  it('applies hover styles on mouse enter', () => {
    renderWithTheme(<Button>Hover me</Button>);
    const button = screen.getByRole('button');
    
    fireEvent.mouseEnter(button);
    // Note: Testing hover styles requires more complex setup with styled-components
    // This test verifies the component renders without errors on hover
    expect(button).toBeInTheDocument();
  });
});