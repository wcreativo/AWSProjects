import React, { createContext, useContext, useReducer, ReactNode } from 'react';

export interface ReservationFormData {
  roomId: number | null;
  date: string;
  time: string;
  numPeople: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  totalPrice: number;
}

interface ReservationState {
  formData: ReservationFormData;
  isSubmitting: boolean;
  error: string | null;
  success: boolean;
}

type ReservationAction =
  | { type: 'UPDATE_FORM_DATA'; payload: Partial<ReservationFormData> }
  | { type: 'SET_SUBMITTING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'SET_SUCCESS'; payload: boolean }
  | { type: 'RESET_FORM' };

interface ReservationContextType {
  state: ReservationState;
  updateFormData: (data: Partial<ReservationFormData>) => void;
  setSubmitting: (submitting: boolean) => void;
  setError: (error: string | null) => void;
  setSuccess: (success: boolean) => void;
  resetForm: () => void;
  calculatePrice: (numPeople: number) => number;
}

const initialFormData: ReservationFormData = {
  roomId: null,
  date: '',
  time: '',
  numPeople: 1,
  customerName: '',
  customerEmail: '',
  customerPhone: '',
  totalPrice: 0,
};

const initialState: ReservationState = {
  formData: initialFormData,
  isSubmitting: false,
  error: null,
  success: false,
};

const reservationReducer = (state: ReservationState, action: ReservationAction): ReservationState => {
  switch (action.type) {
    case 'UPDATE_FORM_DATA':
      return {
        ...state,
        formData: { ...state.formData, ...action.payload },
      };
    case 'SET_SUBMITTING':
      return { ...state, isSubmitting: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload, isSubmitting: false };
    case 'SET_SUCCESS':
      return { ...state, success: action.payload, isSubmitting: false };
    case 'RESET_FORM':
      return { ...initialState };
    default:
      return state;
  }
};

const ReservationContext = createContext<ReservationContextType | undefined>(undefined);

export const ReservationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(reservationReducer, initialState);

  const updateFormData = (data: Partial<ReservationFormData>) => {
    dispatch({ type: 'UPDATE_FORM_DATA', payload: data });
  };

  const setSubmitting = (submitting: boolean) => {
    dispatch({ type: 'SET_SUBMITTING', payload: submitting });
  };

  const setError = (error: string | null) => {
    dispatch({ type: 'SET_ERROR', payload: error });
  };

  const setSuccess = (success: boolean) => {
    dispatch({ type: 'SET_SUCCESS', payload: success });
  };

  const resetForm = () => {
    dispatch({ type: 'RESET_FORM' });
  };

  const calculatePrice = (numPeople: number): number => {
    // Price logic: $30 per person for 1-3 people, $25 per person for 4+
    const pricePerPerson = numPeople <= 3 ? 30 : 25;
    const subtotal = numPeople * pricePerPerson;
    // Add 7% tax
    return Math.round((subtotal * 1.07) * 100) / 100; // Round to 2 decimal places
  };

  return (
    <ReservationContext.Provider
      value={{
        state,
        updateFormData,
        setSubmitting,
        setError,
        setSuccess,
        resetForm,
        calculatePrice,
      }}
    >
      {children}
    </ReservationContext.Provider>
  );
};

export const useReservation = (): ReservationContextType => {
  const context = useContext(ReservationContext);
  if (!context) {
    throw new Error('useReservation must be used within a ReservationProvider');
  }
  return context;
};