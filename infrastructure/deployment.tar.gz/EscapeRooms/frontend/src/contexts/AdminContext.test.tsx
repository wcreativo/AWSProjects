import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { AdminProvider, useAdmin } from './AdminContext';
import { adminApi } from '../services/api';

// Mock the API
jest.mock('../services/api', () => ({
  adminApi: {
    login: jest.fn(),
    getReservations: jest.fn(),
    updateReservationStatus: jest.fn(),
  },
}));

const mockAdminApi = adminApi as jest.Mocked<typeof adminApi>;

// Test component that uses the admin context
const TestComponent: React.FC = () => {
  const { state, login, logout, loadReservations, updateReservationStatus, clearError } = useAdmin();

  const handleLogin = async () => {
    try {
      await login('admin', 'password');
    } catch (error) {
      // Error is handled by context
    }
  };

  const handleUpdateStatus = async () => {
    try {
      await updateReservationStatus(1, 'paid');
    } catch (error) {
      // Error is handled by context
    }
  };

  return (
    <div>
      <div data-testid="loading">{state.loading ? 'loading' : 'not-loading'}</div>
      <div data-testid="error">{state.error || 'no-error'}</div>
      <div data-testid="user">{state.user?.username || 'no-user'}</div>
      <div data-testid="authenticated">{state.user?.isAuthenticated ? 'authenticated' : 'not-authenticated'}</div>
      <div data-testid="reservations-count">{state.reservations.length}</div>
      
      <button onClick={handleLogin}>Login</button>
      <button onClick={logout}>Logout</button>
      <button onClick={loadReservations}>Load Reservations</button>
      <button onClick={handleUpdateStatus}>Update Status</button>
      <button onClick={clearError}>Clear Error</button>
    </div>
  );
};

const renderWithProvider = () => {
  return render(
    <AdminProvider>
      <TestComponent />
    </AdminProvider>
  );
};

describe('AdminContext', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  it('should initialize with default state', () => {
    renderWithProvider();
    
    expect(screen.getByTestId('loading')).toHaveTextContent('not-loading');
    expect(screen.getByTestId('error')).toHaveTextContent('no-error');
    expect(screen.getByTestId('user')).toHaveTextContent('no-user');
    expect(screen.getByTestId('authenticated')).toHaveTextContent('not-authenticated');
    expect(screen.getByTestId('reservations-count')).toHaveTextContent('0');
  });

  it('should restore user from localStorage on mount', () => {
    localStorage.setItem('authToken', 'fake-token');
    localStorage.setItem('adminUsername', 'admin');
    
    renderWithProvider();
    
    expect(screen.getByTestId('user')).toHaveTextContent('admin');
    expect(screen.getByTestId('authenticated')).toHaveTextContent('authenticated');
  });

  it('should handle successful login', async () => {
    mockAdminApi.login.mockResolvedValue({
      access_token: 'access-token',
      refresh_token: 'refresh-token',
    });

    renderWithProvider();
    
    fireEvent.click(screen.getByText('Login'));
    
    expect(screen.getByTestId('loading')).toHaveTextContent('loading');
    
    await waitFor(() => {
      expect(screen.getByTestId('loading')).toHaveTextContent('not-loading');
      expect(screen.getByTestId('user')).toHaveTextContent('admin');
      expect(screen.getByTestId('authenticated')).toHaveTextContent('authenticated');
    });

    expect(localStorage.getItem('authToken')).toBe('access-token');
    expect(localStorage.getItem('refreshToken')).toBe('refresh-token');
    expect(localStorage.getItem('adminUsername')).toBe('admin');
  });

  it('should handle login failure', async () => {
    const loginError = {
      response: { status: 401 },
    };
    mockAdminApi.login.mockRejectedValue(loginError);

    renderWithProvider();
    
    fireEvent.click(screen.getByText('Login'));
    
    await waitFor(() => {
      expect(screen.getByTestId('loading')).toHaveTextContent('not-loading');
      expect(screen.getByTestId('error')).toHaveTextContent('Usuario o contraseña incorrectos');
      expect(screen.getByTestId('authenticated')).toHaveTextContent('not-authenticated');
    });
  });

  it('should handle logout', () => {
    localStorage.setItem('authToken', 'fake-token');
    localStorage.setItem('refreshToken', 'fake-refresh');
    localStorage.setItem('adminUsername', 'admin');
    
    renderWithProvider();
    
    expect(screen.getByTestId('authenticated')).toHaveTextContent('authenticated');
    
    fireEvent.click(screen.getByText('Logout'));
    
    expect(screen.getByTestId('authenticated')).toHaveTextContent('not-authenticated');
    expect(screen.getByTestId('user')).toHaveTextContent('no-user');
    expect(localStorage.getItem('authToken')).toBeNull();
    expect(localStorage.getItem('refreshToken')).toBeNull();
    expect(localStorage.getItem('adminUsername')).toBeNull();
  });

  it('should load reservations successfully', async () => {
    const mockReservations = [
      {
        id: 1,
        room_name: 'Test Room',
        customer_name: 'John Doe',
        customer_email: 'john@example.com',
        customer_phone: '123456789',
        date: '2024-01-01',
        time: '14:00',
        num_people: 2,
        total_price: 60,
        status: 'pending' as const,
        created_at: '2024-01-01T12:00:00Z',
      },
    ];

    mockAdminApi.getReservations.mockResolvedValue(mockReservations);

    renderWithProvider();
    
    fireEvent.click(screen.getByText('Load Reservations'));
    
    await waitFor(() => {
      expect(screen.getByTestId('reservations-count')).toHaveTextContent('1');
    });
  });

  it('should handle reservations loading failure', async () => {
    mockAdminApi.getReservations.mockRejectedValue({
      response: { data: { detail: 'Failed to load' } },
    });

    renderWithProvider();
    
    fireEvent.click(screen.getByText('Load Reservations'));
    
    await waitFor(() => {
      expect(screen.getByTestId('error')).toHaveTextContent('No se pudieron cargar las reservas');
    });
  });

  it('should update reservation status', async () => {
    const mockReservations = [
      {
        id: 1,
        room_name: 'Test Room',
        customer_name: 'John Doe',
        customer_email: 'john@example.com',
        customer_phone: '123456789',
        date: '2024-01-01',
        time: '14:00',
        num_people: 2,
        total_price: 60,
        status: 'pending' as const,
        created_at: '2024-01-01T12:00:00Z',
      },
    ];

    mockAdminApi.getReservations.mockResolvedValue(mockReservations);
    mockAdminApi.updateReservationStatus.mockResolvedValue({});

    renderWithProvider();
    
    // First load reservations
    fireEvent.click(screen.getByText('Load Reservations'));
    
    await waitFor(() => {
      expect(screen.getByTestId('reservations-count')).toHaveTextContent('1');
    });

    // Then update status
    fireEvent.click(screen.getByText('Update Status'));
    
    await waitFor(() => {
      expect(mockAdminApi.updateReservationStatus).toHaveBeenCalledWith(1, 'paid');
    });
  });

  it('should clear error', async () => {
    mockAdminApi.login.mockRejectedValue({
      response: { status: 401 },
    });

    renderWithProvider();
    
    fireEvent.click(screen.getByText('Login'));
    
    await waitFor(() => {
      expect(screen.getByTestId('error')).toHaveTextContent('Usuario o contraseña incorrectos');
    });

    fireEvent.click(screen.getByText('Clear Error'));
    
    expect(screen.getByTestId('error')).toHaveTextContent('no-error');
  });
});