import React, { createContext, useContext, useReducer, ReactNode } from 'react';

export interface Room {
  id: number;
  name: string;
  slug: string;
  short_description: string;
  full_description: string;
  hero_image: string;
  thumbnail_image: string;
  video_url?: string;
  base_price: number;
  is_active: boolean;
}

interface RoomState {
  rooms: Room[];
  activeRoom: Room | null;
  loading: boolean;
  error: string | null;
  isInitialized: boolean;
}

type RoomAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ROOMS'; payload: Room[] }
  | { type: 'SET_ACTIVE_ROOM'; payload: Room }
  | { type: 'SET_ERROR'; payload: string | null };

interface RoomContextType {
  state: RoomState;
  setRooms: (rooms: Room[]) => void;
  setActiveRoom: (room: Room) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
}

const initialState: RoomState = {
  rooms: [],
  activeRoom: null,
  loading: false,
  error: null,
  isInitialized: false,
};

const roomReducer = (state: RoomState, action: RoomAction): RoomState => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'SET_ROOMS':
      return { 
        ...state, 
        rooms: action.payload,
        activeRoom: state.activeRoom || action.payload[0] || null,
        isInitialized: true
      };
    case 'SET_ACTIVE_ROOM':
      return { ...state, activeRoom: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload, loading: false };
    default:
      return state;
  }
};

const RoomContext = createContext<RoomContextType | undefined>(undefined);

export const RoomProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(roomReducer, initialState);

  const setRooms = (rooms: Room[]) => {
    dispatch({ type: 'SET_ROOMS', payload: rooms });
  };

  const setActiveRoom = (room: Room) => {
    dispatch({ type: 'SET_ACTIVE_ROOM', payload: room });
  };

  const setLoading = (loading: boolean) => {
    dispatch({ type: 'SET_LOADING', payload: loading });
  };

  const setError = (error: string | null) => {
    dispatch({ type: 'SET_ERROR', payload: error });
  };

  return (
    <RoomContext.Provider
      value={{
        state,
        setRooms,
        setActiveRoom,
        setLoading,
        setError,
      }}
    >
      {children}
    </RoomContext.Provider>
  );
};

export const useRoom = (): RoomContextType => {
  const context = useContext(RoomContext);
  if (!context) {
    throw new Error('useRoom must be used within a RoomProvider');
  }
  return context;
};