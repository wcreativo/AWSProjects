import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { adminApi } from '../services/api';

// Helper function to get user-friendly error messages
const getErrorMessage = (error: any, defaultMessage: string): string => {
  // Check for backend error messages first
  if (error?.response?.data?.message) {
    return error.response.data.message;
  }
  
  // Check for HTTP status codes and provide friendly messages
  if (error?.response?.status) {
    switch (error.response.status) {
      case 401:
        return 'Usuario o contraseña incorrectos';
      case 403:
        return 'No tienes permisos para acceder';
      case 404:
        return 'Servicio no disponible. Inténtalo más tarde';
      case 500:
        return 'Error del servidor. Inténtalo más tarde';
      case 503:
        return 'Servicio temporalmente no disponible';
      default:
        return defaultMessage;
    }
  }
  
  // Network errors
  if (error?.code === 'NETWORK_ERROR' || error?.message?.includes('Network Error')) {
    return 'Error de conexión. Verifica tu conexión a internet';
  }
  
  // Timeout errors
  if (error?.code === 'ECONNABORTED' || error?.message?.includes('timeout')) {
    return 'La conexión tardó demasiado. Inténtalo de nuevo';
  }
  
  return defaultMessage;
};

// Types
export interface AdminUser {
  username: string;
  isAuthenticated: boolean;
}

export interface Reservation {
  id: number;
  room_name: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  date: string;
  time: string;
  num_people: number;
  total_price: number;
  status: 'pending' | 'paid' | 'cancelled';
  created_at: string;
}

interface AdminState {
  user: AdminUser | null;
  reservations: Reservation[];
  loading: boolean;
  error: string | null;
}

type AdminAction =
  | { type: 'LOGIN_START' }
  | { type: 'LOGIN_SUCCESS'; payload: AdminUser }
  | { type: 'LOGIN_FAILURE'; payload: string }
  | { type: 'LOGOUT' }
  | { type: 'LOAD_RESERVATIONS_START' }
  | { type: 'LOAD_RESERVATIONS_SUCCESS'; payload: Reservation[] }
  | { type: 'LOAD_RESERVATIONS_FAILURE'; payload: string }
  | { type: 'UPDATE_RESERVATION_STATUS'; payload: { id: number; status: string } }
  | { type: 'CLEAR_ERROR' };

const initialState: AdminState = {
  user: null,
  reservations: [],
  loading: false,
  error: null,
};

function adminReducer(state: AdminState, action: AdminAction): AdminState {
  switch (action.type) {
    case 'LOGIN_START':
      return { ...state, loading: true, error: null };
    case 'LOGIN_SUCCESS':
      return { ...state, loading: false, user: action.payload, error: null };
    case 'LOGIN_FAILURE':
      return { ...state, loading: false, error: action.payload };
    case 'LOGOUT':
      return { ...state, user: null, reservations: [] };
    case 'LOAD_RESERVATIONS_START':
      return { ...state, loading: true, error: null };
    case 'LOAD_RESERVATIONS_SUCCESS':
      return { ...state, loading: false, reservations: action.payload, error: null };
    case 'LOAD_RESERVATIONS_FAILURE':
      return { ...state, loading: false, error: action.payload, reservations: [] };
    case 'UPDATE_RESERVATION_STATUS':
      return {
        ...state,
        reservations: state.reservations.map(reservation =>
          reservation.id === action.payload.id
            ? { ...reservation, status: action.payload.status as any }
            : reservation
        ),
      };
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    default:
      return state;
  }
}

interface AdminContextType {
  state: AdminState;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  loadReservations: () => Promise<void>;
  updateReservationStatus: (id: number, status: string) => Promise<void>;
  clearError: () => void;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export const AdminProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(adminReducer, initialState);

  // Check for existing token on mount
  useEffect(() => {
    const token = localStorage.getItem('authToken');
    const username = localStorage.getItem('adminUsername');
    if (token && username) {
      dispatch({
        type: 'LOGIN_SUCCESS',
        payload: { username, isAuthenticated: true },
      });
    }
  }, []);

  const login = async (username: string, password: string): Promise<void> => {
    dispatch({ type: 'LOGIN_START' });
    try {
      const response = await adminApi.login(username, password);
      localStorage.setItem('authToken', response.access_token);
      localStorage.setItem('refreshToken', response.refresh_token);
      localStorage.setItem('adminUsername', username);
      
      dispatch({
        type: 'LOGIN_SUCCESS',
        payload: { username, isAuthenticated: true },
      });
    } catch (error: any) {
      const errorMessage = getErrorMessage(error, 'Error de autenticación. Inténtalo de nuevo');
      dispatch({ type: 'LOGIN_FAILURE', payload: errorMessage });
      throw error;
    }
  };

  const logout = (): void => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('adminUsername');
    dispatch({ type: 'LOGOUT' });
  };

  const loadReservations = useCallback(async (): Promise<void> => {
    dispatch({ type: 'LOAD_RESERVATIONS_START' });
    try {
      const reservations = await adminApi.getReservations();
      dispatch({ type: 'LOAD_RESERVATIONS_SUCCESS', payload: reservations });
    } catch (error: any) {
      const errorMessage = getErrorMessage(error, 'No se pudieron cargar las reservas');
      dispatch({ type: 'LOAD_RESERVATIONS_FAILURE', payload: errorMessage });
    }
  }, []);

  const updateReservationStatus = async (id: number, status: string): Promise<void> => {
    try {
      await adminApi.updateReservationStatus(id, status);
      dispatch({ type: 'UPDATE_RESERVATION_STATUS', payload: { id, status } });
    } catch (error: any) {
      const errorMessage = getErrorMessage(error, 'No se pudo actualizar la reserva');
      dispatch({ type: 'LOAD_RESERVATIONS_FAILURE', payload: errorMessage });
      throw error;
    }
  };

  const clearError = (): void => {
    dispatch({ type: 'CLEAR_ERROR' });
  };

  return (
    <AdminContext.Provider
      value={{
        state,
        login,
        logout,
        loadReservations,
        updateReservationStatus,
        clearError,
      }}
    >
      {children}
    </AdminContext.Provider>
  );
};

export const useAdmin = (): AdminContextType => {
  const context = useContext(AdminContext);
  if (context === undefined) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};