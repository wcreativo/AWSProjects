import './styled.d.ts';

export { theme } from './theme';
export { GlobalStyles } from './GlobalStyles';
export type { Theme } from './theme';