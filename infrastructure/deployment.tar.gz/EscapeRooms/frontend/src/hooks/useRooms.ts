import { useEffect, useCallback, useRef } from 'react';
import { useRoom } from '../contexts/RoomContext';
import { roomsApi } from '../services/api';

export const useRooms = () => {
  const { state, setRooms, setLoading, setError } = useRoom();
  const isLoadingRef = useRef(false);

  const fetchRooms = useCallback(async () => {
    // Prevent multiple simultaneous calls
    if (isLoadingRef.current || state.isInitialized || state.loading) {
      return;
    }

    try {
      isLoadingRef.current = true;
      setLoading(true);
      setError(null);
      const rooms = await roomsApi.getRooms();
      console.log('DEBUG - Rooms fetched from API:', rooms);
      setRooms(rooms);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Error al cargar los escape rooms';
      setError(errorMessage);
    } finally {
      setLoading(false);
      isLoadingRef.current = false;
    }
  }, [setRooms, setLoading, setError, state.isInitialized, state.loading]);

  useEffect(() => {
    fetchRooms();
  }, [fetchRooms]);

  return {
    ...state,
    refetch: fetchRooms,
  };
};