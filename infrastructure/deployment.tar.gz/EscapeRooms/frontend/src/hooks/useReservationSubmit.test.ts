import { renderHook, act } from '@testing-library/react';
import { useReservationSubmit } from './useReservationSubmit';
import { reservationsApi } from '../services/api';
import { useReservation } from '../contexts/ReservationContext';
import { useToast } from '../contexts/ToastContext';

// Mock the dependencies
jest.mock('../services/api');
jest.mock('../contexts/ReservationContext');
jest.mock('../contexts/ToastContext');

const mockReservationsApi = reservationsApi as jest.Mocked<typeof reservationsApi>;
const mockUseReservation = useReservation as jest.MockedFunction<typeof useReservation>;
const mockUseToast = useToast as jest.MockedFunction<typeof useToast>;

describe('useReservationSubmit', () => {
  const mockSetSubmitting = jest.fn();
  const mockSetError = jest.fn();
  const mockSetSuccess = jest.fn();
  const mockResetForm = jest.fn();
  const mockShowSuccess = jest.fn();
  const mockShowError = jest.fn();

  const mockFormData = {
    roomId: 1,
    date: '2024-12-25',
    time: '14:00',
    numPeople: 2,
    customerName: 'John Doe',
    customerEmail: 'john@example.com',
    customerPhone: '+1234567890',
    totalPrice: 60,
  };

  beforeEach(() => {
    jest.clearAllMocks();
    jest.clearAllTimers();
    jest.useFakeTimers();

    mockUseReservation.mockReturnValue({
      state: {
        formData: mockFormData,
        isSubmitting: false,
        error: null,
        success: false,
      },
      updateFormData: jest.fn(),
      setSubmitting: mockSetSubmitting,
      setError: mockSetError,
      setSuccess: mockSetSuccess,
      resetForm: mockResetForm,
      calculatePrice: jest.fn(),
    });

    mockUseToast.mockReturnValue({
      toasts: [],
      addToast: jest.fn(),
      removeToast: jest.fn(),
      showSuccess: mockShowSuccess,
      showError: mockShowError,
      showWarning: jest.fn(),
      showInfo: jest.fn(),
    });
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  it('successfully submits reservation', async () => {
    const mockResponse = { id: 1, status: 'pending' };
    mockReservationsApi.createReservation.mockResolvedValue(mockResponse);

    const { result } = renderHook(() => useReservationSubmit());

    let submitResult: boolean;
    await act(async () => {
      submitResult = await result.current.submitReservation();
    });

    expect(submitResult!).toBe(true);
    expect(mockSetSubmitting).toHaveBeenCalledWith(true);
    expect(mockSetSubmitting).toHaveBeenCalledWith(false);
    expect(mockSetError).toHaveBeenCalledWith(null);
    expect(mockSetSuccess).toHaveBeenCalledWith(true);
    expect(mockShowSuccess).toHaveBeenCalledWith(
      '¡Reserva creada exitosamente! Recuerda enviar el comprobante de pago en los próximos 30 minutos.',
      8000
    );

    // Check that form is reset after delay
    act(() => {
      jest.advanceTimersByTime(1000);
    });
    expect(mockResetForm).toHaveBeenCalled();
  });

  it('handles validation errors for missing fields', async () => {
    const incompleteFormData = {
      ...mockFormData,
      customerName: '',
      customerEmail: '',
    };

    mockUseReservation.mockReturnValue({
      state: {
        formData: incompleteFormData,
        isSubmitting: false,
        error: null,
        success: false,
      },
      updateFormData: jest.fn(),
      setSubmitting: mockSetSubmitting,
      setError: mockSetError,
      setSuccess: mockSetSuccess,
      resetForm: mockResetForm,
      calculatePrice: jest.fn(),
    });

    const { result } = renderHook(() => useReservationSubmit());

    let submitResult: boolean;
    await act(async () => {
      submitResult = await result.current.submitReservation();
    });

    expect(submitResult!).toBe(false);
    expect(mockSetSubmitting).toHaveBeenCalledWith(true);
    expect(mockSetSubmitting).toHaveBeenCalledWith(false);
    expect(mockSetError).toHaveBeenCalledWith('Todos los campos son obligatorios');
    expect(mockShowError).toHaveBeenCalledWith('Todos los campos son obligatorios', 7000);
    expect(mockReservationsApi.createReservation).not.toHaveBeenCalled();
  });

  it('handles API errors with specific messages', async () => {
    const apiError = {
      response: {
        status: 400,
        data: {
          detail: 'This time slot is already reserved'
        }
      }
    };
    mockReservationsApi.createReservation.mockRejectedValue(apiError);

    const { result } = renderHook(() => useReservationSubmit());

    let submitResult: boolean;
    await act(async () => {
      submitResult = await result.current.submitReservation();
    });

    expect(submitResult!).toBe(false);
    expect(mockSetError).toHaveBeenCalledWith('Este horario ya no está disponible. Por favor selecciona otro horario.');
    expect(mockShowError).toHaveBeenCalledWith('Este horario ya no está disponible. Por favor selecciona otro horario.', 7000);
  });

  it('handles network errors', async () => {
    const networkError = {
      code: 'NETWORK_ERROR',
      message: 'Network Error'
    };
    mockReservationsApi.createReservation.mockRejectedValue(networkError);

    const { result } = renderHook(() => useReservationSubmit());

    let submitResult: boolean;
    await act(async () => {
      submitResult = await result.current.submitReservation();
    });

    expect(submitResult!).toBe(false);
    expect(mockSetError).toHaveBeenCalledWith('Error de conexión. Verifica tu internet e intenta nuevamente.');
    expect(mockShowError).toHaveBeenCalledWith('Error de conexión. Verifica tu internet e intenta nuevamente.', 7000);
  });

  it('handles server errors (5xx)', async () => {
    const serverError = {
      response: {
        status: 500,
        data: {}
      }
    };
    mockReservationsApi.createReservation.mockRejectedValue(serverError);

    const { result } = renderHook(() => useReservationSubmit());

    let submitResult: boolean;
    await act(async () => {
      submitResult = await result.current.submitReservation();
    });

    expect(submitResult!).toBe(false);
    expect(mockSetError).toHaveBeenCalledWith('Error del servidor. Por favor intenta más tarde.');
    expect(mockShowError).toHaveBeenCalledWith('Error del servidor. Por favor intenta más tarde.', 7000);
  });

  it('handles 404 errors', async () => {
    const notFoundError = {
      response: {
        status: 404,
        data: {}
      }
    };
    mockReservationsApi.createReservation.mockRejectedValue(notFoundError);

    const { result } = renderHook(() => useReservationSubmit());

    let submitResult: boolean;
    await act(async () => {
      submitResult = await result.current.submitReservation();
    });

    expect(submitResult!).toBe(false);
    expect(mockSetError).toHaveBeenCalledWith('La sala seleccionada no existe.');
    expect(mockShowError).toHaveBeenCalledWith('La sala seleccionada no existe.', 7000);
  });

  it('returns correct loading state', () => {
    mockUseReservation.mockReturnValue({
      state: {
        formData: mockFormData,
        isSubmitting: true,
        error: null,
        success: false,
      },
      updateFormData: jest.fn(),
      setSubmitting: mockSetSubmitting,
      setError: mockSetError,
      setSuccess: mockSetSuccess,
      resetForm: mockResetForm,
      calculatePrice: jest.fn(),
    });

    const { result } = renderHook(() => useReservationSubmit());

    expect(result.current.isSubmitting).toBe(true);
  });

  it('calls API with correct data format', async () => {
    const mockResponse = { id: 1, status: 'pending' };
    mockReservationsApi.createReservation.mockResolvedValue(mockResponse);

    const { result } = renderHook(() => useReservationSubmit());

    await act(async () => {
      await result.current.submitReservation();
    });

    expect(mockReservationsApi.createReservation).toHaveBeenCalledWith({
      roomId: 1,
      date: '2024-12-25',
      time: '14:00',
      numPeople: 2,
      customerName: 'John Doe',
      customerEmail: 'john@example.com',
      customerPhone: '+1234567890',
    });
  });
});