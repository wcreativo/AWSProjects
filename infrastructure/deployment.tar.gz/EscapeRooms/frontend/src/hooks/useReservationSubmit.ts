import { useState } from 'react';
import { reservationsApi } from '../services/api';
import { useReservation } from '../contexts/ReservationContext';
import { useToast } from '../contexts/ToastContext';
import { ReservationFormData } from '../contexts/ReservationContext';

interface UseReservationSubmitReturn {
  submitReservation: () => Promise<boolean>;
  isSubmitting: boolean;
  error: string | null;
}

export const useReservationSubmit = (): UseReservationSubmitReturn => {
  const { state, setSubmitting, setError, setSuccess, resetForm } = useReservation();
  const { showSuccess, showError } = useToast();
  const [localError, setLocalError] = useState<string | null>(null);

  const submitReservation = async (): Promise<boolean> => {
    try {
      setSubmitting(true);
      setError(null);
      setLocalError(null);

      // Validate required fields
      const { formData } = state;
      if (!formData.roomId || !formData.date || !formData.time || 
          !formData.customerName.trim() || !formData.customerEmail.trim() || !formData.customerPhone.trim()) {
        const errorMessage = 'Todos los campos son obligatorios';
        setError(errorMessage);
        setLocalError(errorMessage);
        showError(errorMessage, 7000);
        return false;
      }

      // Prepare data for API (exclude totalPrice as it's calculated on backend)
      const reservationData: Omit<ReservationFormData, 'totalPrice'> = {
        roomId: formData.roomId,
        date: formData.date,
        time: formData.time,
        numPeople: formData.numPeople,
        customerName: formData.customerName.trim(),
        customerEmail: formData.customerEmail.trim(),
        customerPhone: formData.customerPhone.trim(),
      };

      // Submit to API
      await reservationsApi.createReservation(reservationData);

      // Handle success
      setSuccess(true);
      showSuccess(
        '¡Reserva creada exitosamente! Recuerda enviar el comprobante de pago en los próximos 30 minutos.',
        8000
      );

      // Reset form after successful submission
      setTimeout(() => {
        resetForm();
      }, 1000);

      return true;

    } catch (error: any) {
      console.error('Error submitting reservation:', error);
      
      let errorMessage = 'Error al crear la reserva. Por favor intenta nuevamente.';
      
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.data?.detail) {
        errorMessage = error.response.data.detail;
      } else if (error.message) {
        errorMessage = error.message;
      }

      // Handle specific error cases
      if (error.response?.status === 400) {
        if (error.response.data?.detail?.includes('already reserved')) {
          errorMessage = 'Este horario ya no está disponible. Por favor selecciona otro horario.';
        } else if (error.response.data?.detail?.includes('invalid date')) {
          errorMessage = 'La fecha seleccionada no es válida.';
        } else if (error.response.data?.detail?.includes('invalid time')) {
          errorMessage = 'El horario seleccionado no es válido.';
        }
      } else if (error.response?.status === 404) {
        errorMessage = 'La sala seleccionada no existe.';
      } else if (error.response?.status >= 500) {
        errorMessage = 'Error del servidor. Por favor intenta más tarde.';
      } else if (error.code === 'NETWORK_ERROR' || !error.response) {
        errorMessage = 'Error de conexión. Verifica tu internet e intenta nuevamente.';
      }

      setError(errorMessage);
      setLocalError(errorMessage);
      showError(errorMessage, 7000);

      return false;

    } finally {
      setSubmitting(false);
    }
  };

  return {
    submitReservation,
    isSubmitting: state.isSubmitting,
    error: localError || state.error,
  };
};