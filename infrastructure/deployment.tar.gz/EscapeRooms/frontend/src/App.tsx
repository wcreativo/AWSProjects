import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from 'styled-components';
import { GlobalStyles, theme } from './styles';
import { RoomProvider, ReservationProvider, ToastProvider, AdminProvider, useToast } from './contexts';
import { Layout } from './components/layout';
import { HomePage } from './components/HomePage';
import { AdminPage } from './components/AdminPage';
import { ToastContainer } from './components/common';

const AppContent: React.FC = () => {
  const { toasts, removeToast } = useToast();

  return (
    <>
      <Routes>
        <Route 
          path="/" 
          element={
            <Layout>
              <HomePage />
            </Layout>
          } 
        />
        <Route path="/admin" element={<AdminPage />} />
      </Routes>
      <ToastContainer toasts={toasts} onRemoveToast={removeToast} />
    </>
  );
};

function App() {
  return (
    <ThemeProvider theme={theme}>
      <GlobalStyles />
      <Router>
        <ToastProvider>
          <AdminProvider>
            <RoomProvider>
              <ReservationProvider>
                <AppContent />
              </ReservationProvider>
            </RoomProvider>
          </AdminProvider>
        </ToastProvider>
      </Router>
    </ThemeProvider>
  );
}

export default App;
